import crypto from 'node:crypto';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import readline from 'node:readline';

export const PAIR_HASH_ENCODING = 'sha256-canonical-pair/v2';
export const PAIR_HASH_MANIFEST_SCHEMA_VERSION = 'clash.pair-hash-manifest/1.0';

const DEFAULT_MAX_HASHES_IN_MEMORY = 100_000;
const DEFAULT_MAX_HASHES_PER_CHUNK = 50_000;
const HASH_PATTERN = /^[a-f0-9]{64}$/;

function cleanText(value) {
  return String(value ?? '').trim();
}

function compareText(left, right) {
  if (left < right) return -1;
  if (left > right) return 1;
  return 0;
}

function encodeLengthPrefixedUtf8(value) {
  return `${Buffer.byteLength(value, 'utf8')}:${value}`;
}

function encodeEndpoint(endpoint) {
  return `${encodeLengthPrefixedUtf8(endpoint.modelId)}${encodeLengthPrefixedUtf8(endpoint.globalId)}`;
}

function compareEndpoints(left, right) {
  return Buffer.compare(
    Buffer.from(encodeEndpoint(left), 'utf8'),
    Buffer.from(encodeEndpoint(right), 'utf8'),
  );
}

function normalizePositiveInteger(value, fallback) {
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback;
}

export function canonicalPairKey({
  sourceModelId,
  sourceGlobalId,
  targetModelId,
  targetGlobalId,
}) {
  const sourceModel = cleanText(sourceModelId);
  const sourceGuid = cleanText(sourceGlobalId);
  const targetModel = cleanText(targetModelId);
  const targetGuid = cleanText(targetGlobalId);
  if (!sourceModel || !sourceGuid || !targetModel || !targetGuid) {
    return null;
  }
  const endpoints = [
    { modelId: sourceModel, globalId: sourceGuid },
    { modelId: targetModel, globalId: targetGuid },
  ].sort(compareEndpoints);
  return `${PAIR_HASH_ENCODING}|${endpoints.map(encodeEndpoint).join('')}`;
}

export function hashCanonicalPairKey(pairKey) {
  const value = String(pairKey ?? '');
  if (!value) return null;
  if (!value.startsWith(`${PAIR_HASH_ENCODING}|`)) {
    throw new Error(`Pair key must use ${PAIR_HASH_ENCODING}.`);
  }
  return crypto.createHash('sha256').update(value, 'utf8').digest('hex');
}

export function canonicalPairHash(pair) {
  const pairKey = canonicalPairKey(pair);
  return pairKey ? hashCanonicalPairKey(pairKey) : null;
}

function digestSortedHashes(hashes) {
  const digest = crypto.createHash('sha256');
  for (const hash of hashes) {
    digest.update(`${hash}\n`, 'utf8');
  }
  return digest.digest('hex');
}

export function buildPairHashDigestEvidence(pairKeys) {
  const hashes = [...new Set(
    pairKeys
      .map(hashCanonicalPairKey)
      .filter(Boolean),
  )].sort(compareText);
  return {
    encoding: PAIR_HASH_ENCODING,
    count: hashes.length,
    digest: digestSortedHashes(hashes),
  };
}

class HashCursor {
  constructor(filePath) {
    this.stream = fs.createReadStream(filePath, { encoding: 'utf8' });
    this.lines = readline.createInterface({
      input: this.stream,
      crlfDelay: Infinity,
    });
    this.iterator = this.lines[Symbol.asyncIterator]();
    this.value = null;
  }

  async advance() {
    const next = await this.iterator.next();
    this.value = next.done ? null : next.value;
    return this.value;
  }

  close() {
    this.lines.close();
    this.stream.destroy();
  }
}

class CursorHeap {
  constructor() {
    this.values = [];
  }

  get size() {
    return this.values.length;
  }

  push(cursor) {
    this.values.push(cursor);
    let index = this.values.length - 1;
    while (index > 0) {
      const parent = Math.floor((index - 1) / 2);
      if (compareText(this.values[parent].value, cursor.value) <= 0) break;
      this.values[index] = this.values[parent];
      index = parent;
    }
    this.values[index] = cursor;
  }

  pop() {
    const first = this.values[0];
    const last = this.values.pop();
    if (this.values.length > 0 && last) {
      let index = 0;
      while (true) {
        const left = index * 2 + 1;
        const right = left + 1;
        if (left >= this.values.length) break;
        const smaller = (
          right < this.values.length
          && compareText(this.values[right].value, this.values[left].value) < 0
        ) ? right : left;
        if (compareText(last.value, this.values[smaller].value) <= 0) break;
        this.values[index] = this.values[smaller];
        index = smaller;
      }
      this.values[index] = last;
    }
    return first;
  }
}

class PairHashEvidenceAccumulator {
  constructor({ maxHashesInMemory = DEFAULT_MAX_HASHES_IN_MEMORY } = {}) {
    this.maxHashesInMemory = normalizePositiveInteger(
      maxHashesInMemory,
      DEFAULT_MAX_HASHES_IN_MEMORY,
    );
    this.pendingHashes = new Set();
    this.runPaths = [];
    this.tempDirectory = null;
    this.finalized = false;
  }

  addPair(pair) {
    if (this.finalized) {
      throw new Error('Pair-hash evidence is already finalized.');
    }
    const hash = canonicalPairHash(pair);
    if (!hash) return false;
    this.pendingHashes.add(hash);
    if (this.pendingHashes.size >= this.maxHashesInMemory) {
      this.flushRun();
    }
    return true;
  }

  ensureTempDirectory() {
    if (!this.tempDirectory) {
      this.tempDirectory = fs.mkdtempSync(
        path.join(os.tmpdir(), 'clash-pair-evidence-'),
      );
    }
    return this.tempDirectory;
  }

  flushRun() {
    if (this.pendingHashes.size === 0) return;
    const hashes = [...this.pendingHashes].sort(compareText);
    this.pendingHashes.clear();
    const runPath = path.join(
      this.ensureTempDirectory(),
      `run-${String(this.runPaths.length).padStart(6, '0')}.sha256`,
    );
    fs.writeFileSync(runPath, `${hashes.join('\n')}\n`, 'utf8');
    this.runPaths.push(runPath);
  }

  async *uniqueHashes() {
    this.flushRun();
    const cursors = [];
    const heap = new CursorHeap();
    try {
      for (const runPath of this.runPaths) {
        const cursor = new HashCursor(runPath);
        cursors.push(cursor);
        if (await cursor.advance()) heap.push(cursor);
      }

      let previous = null;
      while (heap.size > 0) {
        const cursor = heap.pop();
        const value = cursor.value;
        if (!HASH_PATTERN.test(value)) {
          throw new Error('Pair-hash evidence run contains an invalid hash.');
        }
        if (value !== previous) {
          previous = value;
          yield value;
        }
        if (await cursor.advance()) heap.push(cursor);
      }
    } finally {
      for (const cursor of cursors) cursor.close();
    }
  }

  async finalize({ writeChunk = null, maxHashesPerChunk } = {}) {
    if (this.finalized) {
      throw new Error('Pair-hash evidence is already finalized.');
    }
    this.finalized = true;
    const chunkLimit = normalizePositiveInteger(
      maxHashesPerChunk,
      DEFAULT_MAX_HASHES_PER_CHUNK,
    );
    const overallDigest = crypto.createHash('sha256');
    const chunks = [];
    let chunkHashes = [];
    let totalCount = 0;

    const flushChunk = async () => {
      if (chunkHashes.length === 0) return;
      const bytes = Buffer.from(`${chunkHashes.join('\n')}\n`, 'utf8');
      const chunk = {
        index: chunks.length,
        bytes,
        digest: crypto.createHash('sha256').update(bytes).digest('hex'),
        sizeBytes: bytes.length,
        pairCount: chunkHashes.length,
        firstHash: chunkHashes[0],
        lastHash: chunkHashes.at(-1),
      };
      const pointer = writeChunk ? await writeChunk(chunk) : null;
      if (writeChunk) {
        const uri = cleanText(pointer?.uri);
        if (!uri) {
          throw new Error('Pair-hash evidence writer must return a chunk URI.');
        }
        chunks.push({
          index: chunk.index,
          uri,
          digest: chunk.digest,
          sizeBytes: chunk.sizeBytes,
          pairCount: chunk.pairCount,
          firstHash: chunk.firstHash,
          lastHash: chunk.lastHash,
        });
      }
      chunkHashes = [];
    };

    for await (const hash of this.uniqueHashes()) {
      overallDigest.update(`${hash}\n`, 'utf8');
      totalCount += 1;
      if (writeChunk) {
        chunkHashes.push(hash);
        if (chunkHashes.length >= chunkLimit) await flushChunk();
      }
    }
    await flushChunk();

    return {
      encoding: PAIR_HASH_ENCODING,
      count: totalCount,
      digest: overallDigest.digest('hex'),
      chunks,
    };
  }

  async finalizeDigest() {
    const result = await this.finalize();
    return {
      encoding: result.encoding,
      count: result.count,
      digest: result.digest,
    };
  }

  async finalizeManifest({ writeChunk, maxHashesPerChunk } = {}) {
    if (typeof writeChunk !== 'function') {
      throw new Error('Pair-hash evidence chunk writer is required.');
    }
    const result = await this.finalize({ writeChunk, maxHashesPerChunk });
    return {
      schemaVersion: PAIR_HASH_MANIFEST_SCHEMA_VERSION,
      encoding: result.encoding,
      totalCount: result.count,
      digest: result.digest,
      chunks: result.chunks,
    };
  }

  async dispose() {
    if (this.tempDirectory) {
      await fsp.rm(this.tempDirectory, { recursive: true, force: true });
      this.tempDirectory = null;
    }
  }
}

export function createPairHashEvidenceAccumulator(options) {
  return new PairHashEvidenceAccumulator(options);
}
