/**
 * @typedef {Object} CandidateEndpoint
 * @property {string} modelId
 * @property {string} folderName
 * @property {string} discipline
 * @property {string} globalId
 * @property {string} entityType
 * @property {string} [ifcType]
 * @property {string | null} [geometryId]
 * @property {Object} [geometrySource]
 * @property {Object} [bbox]
 */

/**
 * @typedef {Object} CandidatePair
 * @property {string} pairId
 * @property {CandidateEndpoint} source
 * @property {CandidateEndpoint} target
 * @property {string | Object} [rule]
 * @property {Object} [toleranceMm]
 * @property {Object} [broadPhase]
 */

function cleanString(value) {
  return String(value ?? '').trim();
}

function normalizeNullableString(value) {
  const cleaned = cleanString(value);
  return cleaned || null;
}

/**
 * Normalizes one endpoint in a broad-phase candidate pair.
 *
 * @param {Partial<CandidateEndpoint>} endpoint
 * @returns {CandidateEndpoint}
 */
export function normalizeCandidateEndpoint(endpoint = {}) {
  const entityType = cleanString(endpoint.entityType || endpoint.ifcType || endpoint.type || 'NA') || 'NA';

  return {
    index: endpoint.index,
    modelId: cleanString(endpoint.modelId),
    folderName: cleanString(endpoint.folderName),
    discipline: cleanString(endpoint.discipline),
    entityId: endpoint.entityId,
    globalId: cleanString(endpoint.globalId || endpoint.GlobalId),
    occurrenceType: endpoint.occurrenceType,
    entityType,
    ifcType: entityType,
    geometryId: normalizeNullableString(endpoint.geometryId || endpoint.geometry_id),
    geometrySource: endpoint.geometrySource,
    bbox: endpoint.bbox || endpoint.aabb,
    transform: endpoint.transform,
  };
}

/**
 * Returns a stable object key for dedupe, cache, and debug output.
 *
 * @param {CandidateEndpoint} endpoint
 * @returns {string}
 */
export function getCandidateEndpointKey(endpoint) {
  const normalized = normalizeCandidateEndpoint(endpoint);
  if (!normalized.modelId) {
    throw new Error('CandidateEndpoint.modelId is required.');
  }
  if (!normalized.globalId) {
    throw new Error('CandidateEndpoint.globalId is required.');
  }

  return `${normalized.modelId}::${normalized.globalId}`;
}

/**
 * Returns a stable pair key independent of source/target ordering.
 *
 * @param {CandidatePair} pair
 * @returns {string}
 */
export function getCandidatePairKey(pair) {
  return [
    getCandidateEndpointKey(pair.source),
    getCandidateEndpointKey(pair.target),
  ].sort((a, b) => a.localeCompare(b)).join('||');
}

/**
 * Creates the core candidate-pair contract from two broad-phase objects.
 *
 * @param {Partial<CandidateEndpoint>} source
 * @param {Partial<CandidateEndpoint>} target
 * @param {Object} [options]
 * @returns {CandidatePair}
 */
export function createCandidatePair(source, target, options = {}) {
  const normalizedSource = normalizeCandidateEndpoint(source);
  const normalizedTarget = normalizeCandidateEndpoint(target);
  const pair = {
    pairId: cleanString(options.pairId) || getCandidatePairKey({
      source: normalizedSource,
      target: normalizedTarget,
    }),
    rule: options.rule,
    toleranceMm: options.toleranceMm,
    sourceIndex: options.sourceIndex,
    targetIndex: options.targetIndex,
    source: normalizedSource,
    target: normalizedTarget,
    broadPhase: options.broadPhase,
  };

  return pair;
}

/**
 * Normalizes an existing pair-like value into the core candidate-pair contract.
 *
 * @param {Partial<CandidatePair>} pair
 * @returns {CandidatePair}
 */
export function normalizeCandidatePair(pair = {}) {
  return createCandidatePair(
    pair.source || pair.first || pair.object1,
    pair.target || pair.second || pair.object2,
    {
      pairId: pair.pairId,
      rule: pair.rule,
      toleranceMm: pair.toleranceMm,
      sourceIndex: pair.sourceIndex,
      targetIndex: pair.targetIndex,
      broadPhase: pair.broadPhase,
    },
  );
}
