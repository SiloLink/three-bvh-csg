import { MAX_CLASH_BATCH_SIZE } from '../core/runtime-limits.js';

function parseCsv(value) {
  return String(value || '')
    .split(',')
    .map(item => item.trim())
    .filter(Boolean);
}

function parseOptionalInt(value) {
  if (value === undefined || value === null || value === '') {
    return null;
  }

  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : null;
}

function parseOptionalNonnegativeInt(value) {
  if (value === undefined || value === null || value === '') {
    return null;
  }

  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : null;
}

function parseBool(value, fallback = false) {
  if (value === undefined || value === null || value === '') {
    return fallback;
  }

  return ['1', 'true', 'yes', 'on'].includes(String(value).toLowerCase());
}

function resolveCloudRunJobName(env, projectId, region) {
  const rawName = env.CLASH_CLOUD_RUN_JOB_NAME || '';
  if (!rawName) {
    return '';
  }
  if (rawName.startsWith('projects/')) {
    return rawName;
  }
  if (!projectId || !region) {
    return rawName;
  }

  return `projects/${projectId}/locations/${region}/jobs/${rawName}`;
}

export function getClashConfig(env = process.env) {
  const projectId = env.GOOGLE_CLOUD_PROJECT || env.GCLOUD_PROJECT || env.GCP_PROJECT || env.CLASH_GCP_PROJECT || '';
  const region = env.CLASH_CLOUD_RUN_REGION || env.GOOGLE_CLOUD_REGION || env.GCP_REGION || env.CLOUD_RUN_REGION || '';
  const nodeEnv = env.NODE_ENV || 'development';
  const maxGlobalRunningJobs = parseOptionalInt(env.MAX_GLOBAL_RUNNING_JOBS || env.CLASH_MAX_GLOBAL_RUNNING_JOBS);
  const stateBackend = env.CLASH_STATE_BACKEND || (projectId ? 'firestore' : 'memory');
  const startLeaseMs = parseOptionalInt(env.CLASH_START_LEASE_MS) || 5 * 60 * 1000;

  const config = {
    nodeEnv,
    projectId,
    region,
    stateBackend,
    firestoreDatabaseId: env.CLASH_FIRESTORE_DATABASE_ID || undefined,
    serviceBaseUrl: (env.CLASH_API_BASE_URL || '').replace(/\/$/, ''),
    requireAuth: parseBool(env.CLASH_REQUIRE_AUTH, nodeEnv === 'production'),
    allowDevAuth: parseBool(env.CLASH_ALLOW_DEV_AUTH, nodeEnv !== 'production'),
    callerTokenSecret: env.CLASH_CALLER_TOKEN_SECRET || '',
    callerTokenIssuer: env.CLASH_CALLER_TOKEN_ISSUER || '',
    callerTokenAudience: env.CLASH_CALLER_TOKEN_AUDIENCE || '',
    callerTokenMaxTtlSeconds: parseOptionalInt(env.CLASH_CALLER_TOKEN_MAX_TTL_SECONDS) || 300,
    callerTokenClockSkewSeconds:
      parseOptionalNonnegativeInt(env.CLASH_CALLER_TOKEN_CLOCK_SKEW_SECONDS) ?? 30,
    internalToken: env.CLASH_INTERNAL_TOKEN || '',
    allowedInputBuckets: parseCsv(env.CLASH_ALLOWED_INPUT_BUCKETS),
    allowedOutputBuckets: parseCsv(env.CLASH_ALLOWED_OUTPUT_BUCKETS),
    allowedInputPrefixes: parseCsv(env.CLASH_ALLOWED_INPUT_PREFIXES),
    allowedOutputPrefixes: parseCsv(env.CLASH_ALLOWED_OUTPUT_PREFIXES),
    enforceGcsAllowlists: parseBool(env.CLASH_ENFORCE_GCS_ALLOWLISTS, nodeEnv === 'production'),
    requireProjectPrefix: parseBool(env.CLASH_REQUIRE_PROJECT_PREFIX, false),
    startLeaseMs,
    heartbeatStaleMs: parseOptionalInt(env.CLASH_HEARTBEAT_STALE_MS) || 5 * 60 * 1000,
    cancelSettleTimeoutMs: parseOptionalInt(env.CLASH_CANCEL_SETTLE_TIMEOUT_MS) || 15 * 1000,
    cancelPollIntervalMs: parseOptionalInt(env.CLASH_CANCEL_POLL_INTERVAL_MS) || 500,
    cancelPollMaxIntervalMs: parseOptionalInt(env.CLASH_CANCEL_POLL_MAX_INTERVAL_MS) || 4 * 1000,
    cancelRetryInitialMs: parseOptionalInt(env.CLASH_CANCEL_RETRY_INITIAL_MS) || 30 * 1000,
    cancelRetryMaxMs: parseOptionalInt(env.CLASH_CANCEL_RETRY_MAX_MS) || 15 * 60 * 1000,
    executionLookupRetryInitialMs: 30 * 1000,
    executionLookupRetryMaxMs: 15 * 60 * 1000,
    executionLookupFailureLimit: 5,
    matrixStagingRetentionMs: Math.max(startLeaseMs, 15 * 60 * 1000),
    idempotencyRetentionMs: parseOptionalInt(env.CLASH_IDEMPOTENCY_RETENTION_MS) || 24 * 60 * 60 * 1000,
    maxGlobalRunningJobs,
    maxBatchSize: parseOptionalInt(env.CLASH_MAX_BATCH_SIZE) || MAX_CLASH_BATCH_SIZE,
    globalCapacityEnabled: maxGlobalRunningJobs !== null,
    cloudRunJobName: resolveCloudRunJobName(env, projectId, region),
    tempOutputPrefix: env.CLASH_TEMP_OUTPUT_PREFIX || '',
    allowNoopCloudRunStart: parseBool(env.CLASH_ALLOW_NOOP_CLOUD_RUN, stateBackend === 'memory'),
    runReportsInline: parseBool(env.CLASH_RUN_REPORTS_INLINE, false),
    reconcileLimit: parseOptionalInt(env.CLASH_RECONCILE_LIMIT) || 100,
    progressFlushIntervalMs: parseOptionalNonnegativeInt(env.CLASH_PROGRESS_FLUSH_INTERVAL_MS) ?? 2000,
    progressPublishEnabled: parseBool(env.CLASH_PROGRESS_PUBLISH_ENABLED, false),
    progressTopic: env.CLASH_PROGRESS_TOPIC || '',
  };

  if (config.requireAuth) {
    if (!config.callerTokenSecret) {
      throw new Error('CLASH_CALLER_TOKEN_SECRET is required when caller authentication is enabled.');
    }
    if (Buffer.byteLength(config.callerTokenSecret, 'utf8') < 32) {
      throw new Error('CLASH_CALLER_TOKEN_SECRET must be at least 32 bytes.');
    }
    if (!config.callerTokenIssuer) {
      throw new Error('CLASH_CALLER_TOKEN_ISSUER is required when caller authentication is enabled.');
    }
    if (!config.callerTokenAudience) {
      throw new Error('CLASH_CALLER_TOKEN_AUDIENCE is required when caller authentication is enabled.');
    }
  }

  return config;
}
