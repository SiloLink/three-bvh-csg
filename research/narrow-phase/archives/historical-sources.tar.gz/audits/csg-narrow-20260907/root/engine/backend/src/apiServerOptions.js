export const DEFAULT_API_BODY_LIMIT_BYTES = 4 * 1024 * 1024;

export function resolveApiBodyLimitBytes(env = process.env) {
  const rawLimit = env.CLASH_API_BODY_LIMIT_BYTES;
  if (rawLimit === undefined || rawLimit === '') {
    return DEFAULT_API_BODY_LIMIT_BYTES;
  }

  const bodyLimit = Number(rawLimit);
  if (!Number.isFinite(bodyLimit) || bodyLimit <= 0) {
    throw new Error('CLASH_API_BODY_LIMIT_BYTES must be a positive number of bytes.');
  }

  return Math.floor(bodyLimit);
}
