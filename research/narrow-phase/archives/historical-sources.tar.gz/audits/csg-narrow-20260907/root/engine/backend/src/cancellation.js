export const CANCELLATION_CODE = 'CLASH_REPORT_CANCELED';

export class CancellationError extends Error {
  constructor(message = 'Clash report cancellation was requested.', details = {}) {
    super(message);
    this.name = 'CancellationError';
    this.code = CANCELLATION_CODE;
    this.phase = details.phase || 'compute';
    this.retryable = false;
  }
}

export function isCancellationError(error) {
  return (
    error?.code === CANCELLATION_CODE
    || error?.name === 'CancellationError'
  );
}

export async function throwIfCanceled(shouldCancel, phase = 'compute') {
  if (typeof shouldCancel !== 'function') {
    return;
  }

  if (await shouldCancel()) {
    throw new CancellationError(`Clash report canceled during ${phase}.`, { phase });
  }
}
