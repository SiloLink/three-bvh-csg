import path from 'node:path';
import { createProjectDescriptor } from '../core/project-descriptor.js';
import { MODEL_FILE_SPECS } from '../core/model/model-files.js';
import { requireFolderName } from './validation.js';

export function createCloudProjectDescriptor({ projectGuid, basePath, models }) {
  return createProjectDescriptor({
    projectId: projectGuid || basePath,
    models: models.map(model => {
      const folderName = requireFolderName(model);
      const folderPath = path.join(basePath, folderName);

      return {
        modelId: model.modelGuid,
        folderName,
        discipline: model.discipline,
        files: Object.fromEntries(MODEL_FILE_SPECS.map(({ key, fileName }) => (
          [key, path.join(folderPath, fileName)]
        ))),
      };
    }),
  });
}
