import { PubSub } from '@google-cloud/pubsub';

function compactProgress(progressPatch = {}) {
  const progressValues = progressPatch.progress && typeof progressPatch.progress === 'object'
    ? progressPatch.progress
    : {};
  const stage = progressPatch.stage || progressValues.stage || null;
  const message = progressPatch.message || progressValues.message || null;
  const percent = progressValues.percent ?? progressPatch.percent ?? null;

  return {
    stage,
    message,
    percent,
  };
}

export function createProgressEvent({ job, progressPatch }) {
  const progress = compactProgress(progressPatch);
  return {
    backendJobId: job.progressCorrelationId,
    externalJobId: job.jobId,
    projectGuid: job.projectGuid,
    stage: progress.stage,
    message: progress.message,
    percent: progress.percent,
    progress,
    updatedAt: progressPatch.heartbeatAt || new Date().toISOString(),
  };
}

export function createProgressPublisher({ config, job, pubSub } = {}) {
  if (!config?.progressPublishEnabled) {
    return {
      publish: async () => null,
    };
  }

  if (!config.progressTopic) {
    throw new Error('CLASH_PROGRESS_TOPIC is required when CLASH_PROGRESS_PUBLISH_ENABLED=true.');
  }
  if (!job?.progressCorrelationId) {
    throw new Error('progressCorrelationId is required when progress publishing is enabled.');
  }

  const client = pubSub || new PubSub({
    projectId: config.projectId || undefined,
  });
  const topic = client.topic(config.progressTopic);

  return {
    async publish(progressPatch = {}) {
      const event = createProgressEvent({ job, progressPatch });
      await topic.publishMessage({ json: event });
      return event;
    },
  };
}
