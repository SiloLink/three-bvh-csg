// Runtime tracing helpers for the evaluation harness; not part of normal clash report generation.
import process from 'node:process';
import {
  buildBroadPhaseDataset,
  isSpaceOrOpeningObject,
  shouldFilterByObbRefinement,
} from '../core/broad/broad-phase.js';
import { createCandidatePair } from '../core/candidate-pair.js';
import { normalizeToleranceMm } from '../core/tolerance.js';
import { decideSameSystemIgnore } from '../core/broad/same-system-filter.js';
import {
  decideConnectsPathElementIgnore,
  decideCoversBldgElementIgnore,
  decideHostOpeningFillIgnore,
  decidePortConnectedIgnore,
} from '../core/broad/semantic-filters.js';
import { createNarrowPhaseRuntime } from '../core/narrow/narrow-phase.js';
import { shouldWriteReportRow } from '../io/reportCsv.js';
import { createLocalProjectDescriptor } from '../local/projectDescriptor.js';

function cleanGuid(value, fieldName) {
  const cleaned = String(value || '').trim();
  if (!cleaned) {
    throw new Error(`${fieldName} is required.`);
  }
  return cleaned;
}

function serializeTraceObject(object) {
  if (!object) {
    return null;
  }

  return {
    index: object.index,
    modelId: object.modelId,
    folderName: object.folderName,
    discipline: object.discipline,
    globalId: object.globalId,
    entityType: object.entityType,
    geometryId: object.geometryId,
    geometrySource: object.geometrySource,
    aggregateTreeId: object.aggregateTreeId || null,
    bbox: object.bbox,
  };
}

export function findObjectsForEndpoint(dataset, globalId, modelId = '') {
  const normalizedModelId = String(modelId || '').trim();
  return dataset.objects.filter(object => (
    object.globalId === globalId
    && (!normalizedModelId || object.modelId === normalizedModelId)
  ));
}

function findEndpointException(dataset, globalId, modelId = '') {
  const normalizedModelId = String(modelId || '').trim();
  return dataset.exceptions.find(exception => (
    exception.globalId === globalId
    && (!normalizedModelId || exception.modelId === normalizedModelId)
  )) || null;
}

export function describeEndpointAvailability(dataset, objects, globalId, modelId) {
  if (objects.length > 0) {
    return { status: 'AVAILABLE', exception: null };
  }
  const exception = findEndpointException(dataset, globalId, modelId);
  if (exception?.reason === 'bad-aggregate-geometry') {
    return {
      status: 'BAD_AGGREGATE_GEOMETRY_EXCLUDED',
      exception: {
        reason: exception.reason,
        message: exception.message,
        geometryId: exception.geometryId,
        pattern: exception.badAggregateGeometryPattern,
      },
    };
  }
  return { status: 'OBJECT_NOT_IN_BROAD_DATASET', exception: null };
}

function compareDefaultMatrixAxes(first, second, projectDescriptor) {
  const modelRanks = new Map(
    projectDescriptor.models.map((model, index) => [model.modelId, index]),
  );
  const firstModelRank = modelRanks.get(first.modelId) ?? Number.MAX_SAFE_INTEGER;
  const secondModelRank = modelRanks.get(second.modelId) ?? Number.MAX_SAFE_INTEGER;
  if (firstModelRank !== secondModelRank) {
    return firstModelRank - secondModelRank;
  }
  return first.entityType.localeCompare(second.entityType);
}

// The default matrix uses the later model/type axis as source and the earlier
// axis as target. Within one model/type group production enumerates the lower
// dataset index as source. Narrow filtering is direction-sensitive, so the
// evaluation tracer must reproduce this ordering instead of GUID sort order.
export function orientObjectsByDefaultMatrix(first, second, projectDescriptor) {
  if (first.modelId === second.modelId && first.entityType === second.entityType) {
    return first.index <= second.index
      ? { sourceObject: first, targetObject: second }
      : { sourceObject: second, targetObject: first };
  }
  return compareDefaultMatrixAxes(first, second, projectDescriptor) >= 0
    ? { sourceObject: first, targetObject: second }
    : { sourceObject: second, targetObject: first };
}

function traceAabbForObjects(sourceObject, targetObject) {
  const intersects = intersectsAabb(sourceObject.bbox, targetObject.bbox);

  return {
    source: serializeTraceObject(sourceObject),
    target: serializeTraceObject(targetObject),
    aabbIntersects: intersects,
    aabbFiltered: !intersects,
  };
}

// Matches intersectsAabb in broad-phase.js: matrix tolerance is a narrow-phase
// report filter and never expands the broad candidate search.
function intersectsAabb(a, b) {
  return (
    a.minX <= b.maxX
    && a.maxX >= b.minX
    && a.minY <= b.maxY
    && a.maxY >= b.minY
    && a.minZ <= b.maxZ
    && a.maxZ >= b.minZ
  );
}

function createFilteredBroadTrace(sourceObject, targetObject, status, reason) {
  return {
    source: serializeTraceObject(sourceObject),
    target: serializeTraceObject(targetObject),
    status,
    reason,
    aabbIntersects: true,
    candidateEmitted: false,
  };
}

// Mirrors the production candidate pipeline in runBroadPhaseCandidateBatches
// (broad-phase.js) with default options: same-tree skip, AABB, same-GlobalId
// self-pair skip, OBB refinement, object-level space/opening skip, same-system,
// then semantic filters. Checks must stay in production order so the reported
// filter reason matches what the runtime would actually do. The spatial level
// filter is not simulated because evaluation runs use the default matrix, which
// has no spatial level filter.
export function traceBroadPhaseForObjects(sourceObject, targetObject, dataset) {
  if (
    sourceObject.aggregateTreeId
    && sourceObject.aggregateTreeId === targetObject.aggregateTreeId
  ) {
    return {
      source: serializeTraceObject(sourceObject),
      target: serializeTraceObject(targetObject),
      status: 'SAME_TREE_FILTERED',
      reason: 'Both objects belong to the same model-local IfcRelAggregates tree.',
      aabbIntersects: null,
      candidateEmitted: false,
    };
  }

  const aabbIntersects = intersectsAabb(sourceObject.bbox, targetObject.bbox);
  if (!aabbIntersects) {
    return {
      source: serializeTraceObject(sourceObject),
      target: serializeTraceObject(targetObject),
      status: 'AABB_FILTERED',
      reason: 'The pair bounding boxes do not intersect.',
      aabbIntersects: false,
      candidateEmitted: false,
    };
  }

  if (sourceObject.globalId && sourceObject.globalId === targetObject.globalId) {
    return createFilteredBroadTrace(
      sourceObject,
      targetObject,
      'SELF_PAIR_FILTERED',
      'Both endpoints carry the same GlobalId, so the pair is a duplicate-load self-pair.',
    );
  }

  if (shouldFilterByObbRefinement(sourceObject, targetObject, true)) {
    return createFilteredBroadTrace(
      sourceObject,
      targetObject,
      'OBB_FILTERED',
      'The pair passed AABB but the horizontal OBB refinement found no overlap.',
    );
  }

  if (isSpaceOrOpeningObject(sourceObject) || isSpaceOrOpeningObject(targetObject)) {
    return createFilteredBroadTrace(
      sourceObject,
      targetObject,
      'SPACE_OR_OPENING_FILTERED',
      'One endpoint is IfcSpace or IfcOpeningElement and ignoreSpacesAndOpenings is enabled by default.',
    );
  }

  const sameSystemDecision = decideSameSystemIgnore(sourceObject, targetObject);
  if (sameSystemDecision.ignore) {
    return createFilteredBroadTrace(
      sourceObject,
      targetObject,
      'SAME_SYSTEM',
      sameSystemDecision.reason,
    );
  }

  const coversBldgElementDecision = decideCoversBldgElementIgnore(sourceObject, targetObject, dataset);
  if (coversBldgElementDecision.ignore) {
    return createFilteredBroadTrace(
      sourceObject,
      targetObject,
      'COVERS_BLDG_ELEMENTS',
      coversBldgElementDecision.reason,
    );
  }

  const connectsPathElementDecision = decideConnectsPathElementIgnore(sourceObject, targetObject, dataset);
  if (connectsPathElementDecision.ignore) {
    return createFilteredBroadTrace(
      sourceObject,
      targetObject,
      'CONNECTS_PATH_ELEMENTS',
      connectsPathElementDecision.reason,
    );
  }

  const hostOpeningFillDecision = decideHostOpeningFillIgnore(sourceObject, targetObject, dataset);
  if (hostOpeningFillDecision.ignore) {
    return createFilteredBroadTrace(
      sourceObject,
      targetObject,
      'HOST_OPENING_FILL',
      hostOpeningFillDecision.reason,
    );
  }

  const portConnectedDecision = decidePortConnectedIgnore(sourceObject, targetObject, dataset);
  if (portConnectedDecision.ignore) {
    return createFilteredBroadTrace(
      sourceObject,
      targetObject,
      'PORT_CONNECTED',
      portConnectedDecision.reason,
    );
  }

  return {
    source: serializeTraceObject(sourceObject),
    target: serializeTraceObject(targetObject),
    status: 'CANDIDATE_EMITTED',
    reason: 'The pair passed AABB and broad-phase semantic filters.',
    aabbIntersects: true,
    candidateEmitted: true,
  };
}

function summarizeBroadChecks(checks) {
  if (checks.length === 0) {
    return {
      status: 'OBJECT_NOT_IN_BROAD_DATASET',
      aabbPassed: false,
      aabbFiltered: false,
      semanticFiltered: false,
      candidateEmitted: false,
    };
  }

  if (checks.some(check => check.status === 'CANDIDATE_EMITTED')) {
    return {
      status: 'CANDIDATE_EMITTED',
      aabbPassed: true,
      aabbFiltered: false,
      semanticFiltered: false,
      candidateEmitted: true,
    };
  }

  const semanticStatuses = new Set([
    'SAME_SYSTEM',
    'COVERS_BLDG_ELEMENTS',
    'CONNECTS_PATH_ELEMENTS',
    'HOST_OPENING_FILL',
    'PORT_CONNECTED',
  ]);
  const semanticCheck = checks.find(check => semanticStatuses.has(check.status));
  if (semanticCheck) {
    return {
      status: semanticCheck.status,
      aabbPassed: true,
      aabbFiltered: false,
      semanticFiltered: true,
      candidateEmitted: false,
    };
  }

  if (checks.every(check => check.status === 'AABB_FILTERED')) {
    return {
      status: 'AABB_FILTERED',
      aabbPassed: false,
      aabbFiltered: true,
      semanticFiltered: false,
      candidateEmitted: false,
    };
  }

  // Prefer a non-AABB filter status when checks are mixed.
  // over AABB_FILTERED when the checks are mixed.
  const fallbackStatus = (
    checks.find(check => check.status !== 'AABB_FILTERED')?.status
    || checks[0]?.status
    || 'UNKNOWN'
  );
  return {
    status: fallbackStatus,
    aabbPassed: checks.some(check => check.aabbIntersects === true),
    aabbFiltered: fallbackStatus === 'AABB_FILTERED',
    semanticFiltered: semanticStatuses.has(fallbackStatus),
    candidateEmitted: false,
  };
}

function createNarrowPhasePair(sourceObject, targetObject, toleranceMm) {
  return createCandidatePair({
    modelId: sourceObject.modelId,
    discipline: sourceObject.discipline,
    folderName: sourceObject.folderName,
    globalId: sourceObject.globalId,
    entityType: sourceObject.entityType,
  }, {
    modelId: targetObject.modelId,
    discipline: targetObject.discipline,
    folderName: targetObject.folderName,
    globalId: targetObject.globalId,
    entityType: targetObject.entityType,
  }, {
    toleranceMm,
  });
}

function serializeNarrowResult(result) {
  return {
    sourceModelId: result['Object 1 Model ID'],
    sourceGuid: result['Object 1 GlobalID'],
    targetModelId: result['Object 2 Model ID'],
    targetGuid: result['Object 2 GlobalID'],
    sourceType: result['Object 1 Type'],
    targetType: result['Object 2 Type'],
    collision: result.Collision,
    clashType: result['Clash Type'],
    volumeMm3: result['Volume (mm3)'],
    boxXMm: result['Box X (mm)'],
    boxYMm: result['Box Y (mm)'],
    boxZMm: result['Box Z (mm)'],
    error: result.Error,
    wouldWriteReportRow: shouldWriteReportRow(result),
    trace: result.Trace || null,
  };
}

export async function traceAabbForGuidPair({
  projectDescriptor,
  dataset = null,
  sourceGuid,
  targetGuid,
  sourceModelId = '',
  targetModelId = '',
} = {}) {
  const normalizedSourceGuid = cleanGuid(sourceGuid, 'sourceGuid');
  const normalizedTargetGuid = cleanGuid(targetGuid, 'targetGuid');
  const broadPhaseDataset = dataset || await buildBroadPhaseDataset(projectDescriptor);
  const sourceObjects = findObjectsForEndpoint(
    broadPhaseDataset,
    normalizedSourceGuid,
    sourceModelId,
  );
  const targetObjects = findObjectsForEndpoint(
    broadPhaseDataset,
    normalizedTargetGuid,
    targetModelId,
  );
  const checks = [];

  for (const sourceObject of sourceObjects) {
    for (const targetObject of targetObjects) {
      if (sourceObject.index === targetObject.index) {
        continue;
      }
      checks.push(traceAabbForObjects(sourceObject, targetObject));
    }
  }

  const anyAabbIntersect = checks.some(check => check.aabbIntersects);

  return {
    sourceGuid: normalizedSourceGuid,
    targetGuid: normalizedTargetGuid,
    sourceModelId: String(sourceModelId || '').trim(),
    targetModelId: String(targetModelId || '').trim(),
    sourceObjectCount: sourceObjects.length,
    targetObjectCount: targetObjects.length,
    sourceFound: sourceObjects.length > 0,
    targetFound: targetObjects.length > 0,
    aabbIntersects: anyAabbIntersect,
    aabbFiltered: checks.length > 0 ? !anyAabbIntersect : null,
    checks,
  };
}

export async function traceNarrowPhaseForGuidPairs({
  projectDescriptor,
  parquetDir,
  pairs = [],
  toleranceMm = {},
} = {}) {
  const descriptor = projectDescriptor || await createLocalProjectDescriptor(parquetDir);
  const dataset = await buildBroadPhaseDataset(descriptor);
  const normalizedToleranceMm = normalizeToleranceMm(toleranceMm);
  const narrowPairs = [];
  const traceRequests = [];

  for (const pair of pairs) {
    const sourceGuid = cleanGuid(pair.sourceGuid, 'sourceGuid');
    const targetGuid = cleanGuid(pair.targetGuid, 'targetGuid');
    const requestedSourceModelId = String(pair.sourceModelId || '').trim();
    const requestedTargetModelId = String(pair.targetModelId || '').trim();
    const firstObjects = findObjectsForEndpoint(dataset, sourceGuid, requestedSourceModelId);
    const secondObjects = findObjectsForEndpoint(dataset, targetGuid, requestedTargetModelId);
    const firstAvailability = describeEndpointAvailability(
      dataset,
      firstObjects,
      sourceGuid,
      requestedSourceModelId,
    );
    const secondAvailability = describeEndpointAvailability(
      dataset,
      secondObjects,
      targetGuid,
      requestedTargetModelId,
    );
    const request = {
      requestedSourceGuid: sourceGuid,
      requestedTargetGuid: targetGuid,
      requestedSourceModelId,
      requestedTargetModelId,
      sourceFound: firstObjects.length > 0,
      targetFound: secondObjects.length > 0,
      sourceAvailability: firstAvailability,
      targetAvailability: secondAvailability,
      checkStartIndex: narrowPairs.length,
      checkCount: 0,
      directions: [],
    };

    for (const firstObject of firstObjects) {
      for (const secondObject of secondObjects) {
        if (firstObject.index === secondObject.index) {
          continue;
        }
        const { sourceObject, targetObject } = orientObjectsByDefaultMatrix(
          firstObject,
          secondObject,
          descriptor,
        );
        narrowPairs.push(createNarrowPhasePair(
          sourceObject,
          targetObject,
          normalizedToleranceMm,
        ));
        request.directions.push({
          sourceModelId: sourceObject.modelId,
          sourceGuid: sourceObject.globalId,
          targetModelId: targetObject.modelId,
          targetGuid: targetObject.globalId,
        });
        request.checkCount += 1;
      }
    }

    traceRequests.push(request);
  }

  const runtime = await createNarrowPhaseRuntime({
    projectDescriptor: descriptor,
    cacheObjects: true,
  });
  let narrowResult;
  try {
    narrowResult = await runtime.runPairs({
      pairs: narrowPairs,
      cacheObjects: true,
      includeTraceFields: true,
    });
  } finally {
    runtime.dispose();
  }

  return traceRequests.map(request => {
    const checks = narrowResult.results
      .slice(request.checkStartIndex, request.checkStartIndex + request.checkCount)
      .map(serializeNarrowResult);
    return {
      sourceGuid: request.requestedSourceGuid,
      targetGuid: request.requestedTargetGuid,
      sourceModelId: request.requestedSourceModelId,
      targetModelId: request.requestedTargetModelId,
      toleranceMm: normalizedToleranceMm,
      sourceFound: request.sourceFound,
      targetFound: request.targetFound,
      checkCount: request.checkCount,
      finalCollision: checks.some(check => check.collision === 'TRUE'),
      wouldWriteReportRow: checks.some(check => check.wouldWriteReportRow),
      rawCollision: checks.some(check => check.trace?.rawCollision === true),
      filteredByTolerance: checks.some(check => check.trace?.filteredByTolerance === true),
      filteredByFillRatio: checks.some(check => check.trace?.filteredByFillRatio === true),
      errors: checks
        .map(check => check.error)
        .filter(error => error && error !== 'NA'),
      sourceAvailability: request.sourceAvailability,
      targetAvailability: request.targetAvailability,
      productionDirections: request.directions,
      checks,
    };
  });
}

export async function traceBroadPhaseForGuidPairs({
  projectDescriptor,
  parquetDir,
  pairs = [],
} = {}) {
  const descriptor = projectDescriptor || await createLocalProjectDescriptor(parquetDir);
  const dataset = await buildBroadPhaseDataset(descriptor);

  return pairs.map(pair => {
    const sourceGuid = cleanGuid(pair.sourceGuid, 'sourceGuid');
    const targetGuid = cleanGuid(pair.targetGuid, 'targetGuid');
    const requestedSourceModelId = String(pair.sourceModelId || '').trim();
    const requestedTargetModelId = String(pair.targetModelId || '').trim();
    const firstObjects = findObjectsForEndpoint(dataset, sourceGuid, requestedSourceModelId);
    const secondObjects = findObjectsForEndpoint(dataset, targetGuid, requestedTargetModelId);
    const checks = [];

    for (const firstObject of firstObjects) {
      for (const secondObject of secondObjects) {
        if (firstObject.index === secondObject.index) {
          continue;
        }
        const { sourceObject, targetObject } = orientObjectsByDefaultMatrix(
          firstObject,
          secondObject,
          descriptor,
        );
        checks.push(traceBroadPhaseForObjects(sourceObject, targetObject, dataset));
      }
    }

    const summary = summarizeBroadChecks(checks);
    return {
      sourceGuid,
      targetGuid,
      sourceModelId: requestedSourceModelId,
      targetModelId: requestedTargetModelId,
      sourceFound: firstObjects.length > 0,
      targetFound: secondObjects.length > 0,
      sourceAvailability: describeEndpointAvailability(
        dataset,
        firstObjects,
        sourceGuid,
        requestedSourceModelId,
      ),
      targetAvailability: describeEndpointAvailability(
        dataset,
        secondObjects,
        targetGuid,
        requestedTargetModelId,
      ),
      checkCount: checks.length,
      ...summary,
      checks,
    };
  });
}

export async function traceAabbForGuidPairs({
  projectDescriptor,
  parquetDir,
  pairs = [],
} = {}) {
  const descriptor = projectDescriptor || await createLocalProjectDescriptor(parquetDir);
  const dataset = await buildBroadPhaseDataset(descriptor);

  return Promise.all(
    pairs.map(pair => traceAabbForGuidPair({
      projectDescriptor: descriptor,
      dataset,
      sourceGuid: pair.sourceGuid,
      targetGuid: pair.targetGuid,
      sourceModelId: pair.sourceModelId,
      targetModelId: pair.targetModelId,
    })),
  );
}

async function readStdinJson() {
  const chunks = [];
  for await (const chunk of process.stdin) {
    chunks.push(chunk);
  }

  const text = Buffer.concat(chunks).toString('utf8').trim();
  if (!text) {
    throw new Error('Expected JSON input on stdin.');
  }
  return JSON.parse(text);
}

async function main() {
  const input = await readStdinJson();
  let traces;
  if (input.mode === 'narrow-phase') {
    traces = await traceNarrowPhaseForGuidPairs(input);
  } else if (input.mode === 'broad-phase') {
    traces = await traceBroadPhaseForGuidPairs(input);
  } else {
    traces = await traceAabbForGuidPairs(input);
  }
  process.stdout.write(`${JSON.stringify({ traces }, null, 2)}\n`);
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch(error => {
    console.error(error);
    process.exitCode = 1;
  });
}
