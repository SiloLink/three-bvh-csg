import { performance } from 'node:perf_hooks';

const NARROW_PROGRESS_INTERVAL_MS = 500;

export function createNarrowPhaseProgressEmitter({
  onProgress,
  now = () => performance.now(),
}) {
  let lastEmittedAtMs = Number.NEGATIVE_INFINITY;

  return {
    async emit(update, { force = false } = {}) {
      const currentTimeMs = now();
      if (!force && currentTimeMs - lastEmittedAtMs < NARROW_PROGRESS_INTERVAL_MS) {
        return false;
      }

      await onProgress(update);
      lastEmittedAtMs = now();
      return true;
    },
  };
}
