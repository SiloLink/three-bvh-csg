import fs from 'node:fs/promises';
import path from 'node:path';
import { createProjectDescriptor } from '../core/project-descriptor.js';
import {
  MODEL_FILE_SPECS,
  REQUIRED_MODEL_FILES,
} from '../core/model/model-files.js';

export { REQUIRED_MODEL_FILES };

function cleanPath(value, fieldName) {
  const cleaned = String(value || '').trim().replace(/^["']|["']$/g, '');
  if (!cleaned) {
    throw new Error(`${fieldName} is required.`);
  }

  return path.resolve(cleaned);
}

export async function listValidModelFolders(basePath) {
  const resolvedBasePath = cleanPath(basePath, 'Base folder path');
  const entries = await fs.readdir(resolvedBasePath, { withFileTypes: true });
  const folders = [];

  for (const entry of entries) {
    if (!entry.isDirectory()) {
      continue;
    }

    const folderPath = path.join(resolvedBasePath, entry.name);
    const fileChecks = await Promise.all(REQUIRED_MODEL_FILES.map(async fileName => {
      try {
        await fs.access(path.join(folderPath, fileName));
        return true;
      } catch {
        return false;
      }
    }));

    if (fileChecks.every(Boolean)) {
      folders.push({
        folderName: entry.name,
        folderPath,
      });
    }
  }

  return folders.sort((a, b) => a.folderName.localeCompare(b.folderName));
}

export async function resolveLocalModelFolders(basePath) {
  const validFolders = await listValidModelFolders(basePath);

  return validFolders.map(folder => ({
    ...folder,
    discipline: folder.folderName,
  }));
}

export async function createLocalProjectDescriptor(basePath) {
  const resolvedBasePath = cleanPath(basePath, 'Base folder path');
  const folders = await resolveLocalModelFolders(resolvedBasePath);

  return createProjectDescriptor({
    projectId: resolvedBasePath,
    models: folders.map(({ folderName, folderPath, discipline }) => ({
      modelId: folderName,
      folderName,
      discipline,
      files: Object.fromEntries(MODEL_FILE_SPECS.map(({ key, fileName }) => (
        [key, path.join(folderPath, fileName)]
      ))),
    })),
  });
}
