import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { ensureTrailingSlash, parseGcsUri } from '../io/gcsUri.js';
import { readModelCatalog } from '../core/model/model-catalog.js';
import { MODEL_FILE_SPECS } from '../core/model/model-files.js';
import { badRequest } from './httpErrors.js';
import { requireFolderName } from './validation.js';

let storagePromise = null;

async function getStorage() {
  if (!storagePromise) {
    const { Storage } = await import('@google-cloud/storage');
    storagePromise = Promise.resolve(new Storage());
  }

  return storagePromise;
}

function isNotFound(error) {
  return error?.code === 404 || error?.statusCode === 404;
}

async function getObjectMetadata(storage, bucket, object) {
  try {
    const [metadata] = await storage.bucket(bucket).file(object).getMetadata();
    return metadata || null;
  } catch (error) {
    if (isNotFound(error)) {
      return null;
    }
    throw error;
  }
}

export async function loadModelSourceSnapshot(model, dependencies = {}) {
  const storage = dependencies.storage || await getStorage();
  const parsed = parseGcsUri(model.sourceUri, 'sourceUri');
  const prefix = ensureTrailingSlash(parsed.object);
  const snapshots = await Promise.all(MODEL_FILE_SPECS.map(async ({ key, fileName }) => {
    const object = `${prefix}${fileName}`;
    const metadata = await getObjectMetadata(storage, parsed.bucket, object);
    return { key, fileName, object, metadata };
  }));
  const missing = snapshots
    .filter(snapshot => !snapshot.metadata)
    .map(snapshot => snapshot.fileName);

  if (missing.length > 0) {
    throw badRequest('MODEL_FOLDER_INCOMPLETE', 'Model sourceUri is missing required files.', {
      sourceUri: model.sourceUri,
      missing,
    });
  }

  return Object.fromEntries(snapshots.map(({ key, object, metadata }) => {
    const generation = String(metadata.generation ?? '').trim();
    if (!generation) {
      throw badRequest(
        'MODEL_OBJECT_GENERATION_MISSING',
        'A required model object is missing its GCS generation.',
        { sourceUri: model.sourceUri, object },
      );
    }
    return [key, {
      bucket: parsed.bucket,
      object,
      generation,
    }];
  }));
}

async function downloadSnapshotObject(storage, sourceObject, destination) {
  await storage
    .bucket(sourceObject.bucket)
    .file(sourceObject.object, { generation: sourceObject.generation })
    .download({ destination });
}

export async function loadTypeCatalogFromModels(models, dependencies = {}) {
  const storage = dependencies.storage || await getStorage();
  return Promise.all(models.map(async model => {
    const sourceObjects = await loadModelSourceSnapshot(model, { storage });

    const tempRoot = await fs.mkdtemp(path.join(os.tmpdir(), 'clash-catalog-'));
    try {
      const modelPath = path.join(tempRoot, path.basename(sourceObjects.model.object));
      const relationshipsPath = path.join(
        tempRoot,
        path.basename(sourceObjects.relationships.object),
      );
      await Promise.all([
        downloadSnapshotObject(storage, sourceObjects.model, modelPath),
        downloadSnapshotObject(storage, sourceObjects.relationships, relationshipsPath),
      ]);
      const folderName = requireFolderName(model);
      const catalogModel = {
        modelId: model.modelGuid,
        folderName,
        discipline: model.discipline,
        files: {
          model: modelPath,
          geometry: `gs://${sourceObjects.geometry.bucket}/${sourceObjects.geometry.object}`,
          relationships: relationshipsPath,
        },
      };
      const catalog = await readModelCatalog(catalogModel);

      return {
        discipline: model.discipline,
        modelGuid: model.modelGuid,
        modelName: model.modelName,
        folderName,
        sourceUri: model.sourceUri,
        modelUri: `gs://${sourceObjects.model.bucket}/${sourceObjects.model.object}`,
        ifcUri: null,
        types: catalog.types,
        typedObjectCount: catalog.typedObjectCount,
        relationCount: catalog.relationCount,
        spatialLevels: catalog.spatialLevels,
        sourceObjects,
      };
    } finally {
      await fs.rm(tempRoot, { recursive: true, force: true });
    }
  }));
}
