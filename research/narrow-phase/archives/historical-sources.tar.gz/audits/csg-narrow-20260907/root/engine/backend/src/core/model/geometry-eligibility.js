export function hasDirectGeometryId(value) {
  return (
    value !== null
    && value !== undefined
    && String(value).trim() !== ''
    && String(value).trim().toLowerCase() !== 'null'
  );
}
