function routeUrl(baseUrl, path) {
  return baseUrl ? `${baseUrl}${path}` : path;
}

export function toJobResponse(job, config) {
  if (!job) {
    return null;
  }

  const status = job.executionCleanupPending ? 'canceling' : job.status;

  return {
    jobId: job.jobId,
    projectGuid: job.projectGuid,
    status,
    progress: job.progress || {
      percent: null,
      stage: job.stage,
      message: job.message,
    },
    resultUri: job.resultUri || null,
    detectedPairs: job.detectedPairs || null,
    evaluatedCoverageUri: job.evaluatedCoverageUri || null,
    evaluatedCoverageDigest: job.evaluatedCoverageDigest || null,
    evaluatedCoverageSchemaVersion: job.evaluatedCoverageSchemaVersion || null,
    evaluatedCoverageSizeBytes: job.evaluatedCoverageSizeBytes ?? null,
    evaluatedCoverageError: job.evaluatedCoverageError || null,
    broadPhase: job.broadPhase || null,
    narrowPhase: job.narrowPhase || null,
    error: job.error || null,
    createdAt: job.createdAt,
    startedAt: job.startedAt || null,
    finishedAt: job.finishedAt || null,
    statusUrl: routeUrl(config.serviceBaseUrl, `/api/clash-reports/${job.jobId}`),
    cancelUrl: routeUrl(config.serviceBaseUrl, `/api/clash-reports/${job.jobId}/cancel`),
  };
}

export function toAcceptedJobResponse(job, config) {
  const base = toJobResponse(job, config);
  return {
    jobId: base.jobId,
    status: base.status,
    statusUrl: base.statusUrl,
    cancelUrl: base.cancelUrl,
    resultUri: base.resultUri,
  };
}
