import {
  prepareLocalClashDetection,
  runLocalClashDetection,
} from './clashDetectionService.js';

export async function registerLocalClashRoutes(app) {
  app.post('/api/clash-detection/prepare', async (request, reply) => {
    try {
      return await prepareLocalClashDetection(request.body || {});
    } catch (error) {
      return reply.code(400).send({ error: error.message });
    }
  });

  app.post('/api/clash-detection/run', async (request, reply) => {
    try {
      return await runLocalClashDetection(request.body || {});
    } catch (error) {
      return reply.code(400).send({ error: error.message });
    }
  });
}
