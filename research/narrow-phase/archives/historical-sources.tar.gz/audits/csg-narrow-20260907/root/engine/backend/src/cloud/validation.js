import crypto from 'node:crypto';
import { parseGcsUri } from '../io/gcsUri.js';
import { normalizeSpatialLevelName } from '../core/model/spatial-levels.js';
import { normalizeToleranceMm as normalizeCoreToleranceMm } from '../core/tolerance.js';
import {
  MAX_CLASH_BATCH_SIZE,
  normalizeClashBatchSize,
} from '../core/runtime-limits.js';
import { badRequest, forbidden } from './httpErrors.js';

const MAX_MATRIX_PAIR_COUNT = 100_000;

function normalizeString(value, fieldName) {
  const text = String(value || '').trim();
  if (!text) {
    throw badRequest('INVALID_REQUEST', `${fieldName} is required.`);
  }

  return text;
}

function normalizeOptionalString(value) {
  return String(value ?? '').trim();
}

function normalizeDetectionIdentity(value) {
  const identity = normalizeOptionalString(value);
  if (!identity) return null;
  if (!/^[a-f0-9]{32,64}$/u.test(identity)) {
    throw badRequest(
      'INVALID_DETECTION_IDENTITY',
      'detectionIdentity must be a lowercase hexadecimal digest.',
    );
  }
  return identity;
}

export function requireFolderName(model) {
  const folderName = normalizeOptionalString(model?.folderName);
  if (!folderName) {
    throw new Error('Normalized cloud model is missing folderName.');
  }
  return folderName;
}

export function normalizeProjectGuid(value) {
  return normalizeString(value, 'projectGuid');
}

export function normalizeDisciplineName(value) {
  const normalized = String(value || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, '-')
    .replace(/^-+|-+$/g, '');

  if (!normalized) {
    throw badRequest('INVALID_DISCIPLINE', 'Model discipline is required.');
  }

  return normalized;
}

function normalizeAllowedPrefix(prefix) {
  if (prefix.startsWith('gs://')) {
    const parsed = parseGcsUri(prefix);
    return {
      bucket: parsed.bucket,
      object: parsed.object.replace(/^\/+|\/+$/g, ''),
    };
  }

  const [bucket, ...objectParts] = prefix.split('/');
  return {
    bucket,
    object: objectParts.join('/').replace(/^\/+|\/+$/g, ''),
  };
}

function parseUserGcsUri(uri, fieldName) {
  try {
    return parseGcsUri(uri, fieldName);
  } catch (error) {
    throw badRequest('INVALID_GCS_URI', error.message || String(error));
  }
}

function objectMatchesAllowedPrefix(object, allowedObject) {
  const normalizedObject = String(object || '').replace(/^\/+|\/+$/g, '');
  if (!allowedObject) {
    return true;
  }

  return normalizedObject === allowedObject || normalizedObject.startsWith(`${allowedObject}/`);
}

function isPrefixAllowed(parsedUri, allowedPrefixes) {
  if (allowedPrefixes.length === 0) {
    return true;
  }

  return allowedPrefixes.some(prefix => {
    const allowed = normalizeAllowedPrefix(prefix);
    return (
      parsedUri.bucket === allowed.bucket
      && objectMatchesAllowedPrefix(parsedUri.object, allowed.object)
    );
  });
}

function assertProjectPrefix(parsedUri, projectGuid, config) {
  if (!config.requireProjectPrefix) {
    return;
  }

  const normalizedProject = encodeURIComponent(projectGuid).toLowerCase();
  const object = parsedUri.object.toLowerCase();
  if (!object.includes(normalizedProject) && !object.includes(projectGuid.toLowerCase())) {
    throw forbidden(
      'GCS_PROJECT_PREFIX_DENIED',
      'The GCS prefix is not associated with the requested projectGuid.',
    );
  }
}

export function assertAllowedGcsUri(uri, { kind, projectGuid, config }) {
  const parsed = parseUserGcsUri(uri, kind);
  const bucketAllowlist = kind === 'input' ? config.allowedInputBuckets : config.allowedOutputBuckets;
  const prefixAllowlist = kind === 'input' ? config.allowedInputPrefixes : config.allowedOutputPrefixes;

  if (config.enforceGcsAllowlists && bucketAllowlist.length === 0 && prefixAllowlist.length === 0) {
    throw forbidden(
      'GCS_ALLOWLIST_NOT_CONFIGURED',
      `${kind} GCS allowlist is required before accepting cloud clash requests.`,
    );
  }

  if (bucketAllowlist.length > 0 && !bucketAllowlist.includes(parsed.bucket)) {
    throw forbidden('GCS_BUCKET_DENIED', `${kind} bucket is not allowlisted.`);
  }
  if (!isPrefixAllowed(parsed, prefixAllowlist)) {
    throw forbidden('GCS_PREFIX_DENIED', `${kind} prefix is not allowlisted.`);
  }

  assertProjectPrefix(parsed, projectGuid, config);
  return parsed;
}

export function normalizeModelsInput({ projectGuid, models, config }) {
  const normalizedProjectGuid = normalizeProjectGuid(projectGuid);
  if (!Array.isArray(models) || models.length === 0) {
    throw badRequest('INVALID_MODELS', 'models must be a non-empty array.');
  }

  const seenModelGuids = new Map();
  const normalizedModels = models.map((model, index) => {
    const discipline = normalizeDisciplineName(model?.discipline);
    const modelGuid = normalizeString(model?.modelGuid, `models[${index}].modelGuid`);
    if (modelGuid.includes('/') || modelGuid.includes('\\')) {
      throw badRequest(
        'INVALID_MODEL_GUID',
        `models[${index}].modelGuid must be a path-safe model lane id.`,
      );
    }
    if (seenModelGuids.has(modelGuid)) {
      throw badRequest(
        'DUPLICATE_MODEL_GUID',
        'models must have unique modelGuid lanes.',
        { modelGuid, firstIndex: seenModelGuids.get(modelGuid), duplicateIndex: index },
      );
    }
    seenModelGuids.set(modelGuid, index);

    const sourceUri = normalizeString(model?.sourceUri, `models[${index}].sourceUri`);
    assertAllowedGcsUri(sourceUri, {
      kind: 'input',
      projectGuid: normalizedProjectGuid,
      config,
    });

    const modelName = normalizeOptionalString(model?.modelName);
    return {
      discipline,
      modelGuid,
      ...(modelName ? { modelName } : {}),
      folderName: modelGuid,
      version: normalizeString(model?.version, `models[${index}].version`),
      sourceUri,
    };
  });

  return {
    projectGuid: normalizedProjectGuid,
    models: normalizedModels,
  };
}

function normalizeToleranceMm(toleranceMm = {}) {
  try {
    return normalizeCoreToleranceMm(toleranceMm);
  } catch (error) {
    throw badRequest('INVALID_TOLERANCE', error.message);
  }
}

function normalizeEndpointType(endpoint, fieldName) {
  return normalizeString(endpoint?.entityType, fieldName);
}

export function normalizeSpatialLevelFilter(value) {
  if (value === null || value === undefined) {
    return null;
  }

  const mode = value?.mode || 'anySide';
  if (mode !== 'anySide') {
    throw badRequest(
      'INVALID_SPATIAL_LEVEL_FILTER',
      'spatialLevelFilter.mode must be "anySide".',
    );
  }

  const names = [];
  const seen = new Set();
  for (const rawName of value?.names || value?.levelNames || []) {
    const name = String(rawName ?? '').trim().replace(/\s+/g, ' ');
    const normalizedName = normalizeSpatialLevelName(name);
    if (!normalizedName || seen.has(normalizedName)) {
      continue;
    }

    seen.add(normalizedName);
    names.push(name);
  }

  if (names.length === 0) {
    return null;
  }

  names.sort((left, right) => left.localeCompare(right, undefined, {
    numeric: true,
    sensitivity: 'base',
  }));

  return {
    mode: 'anySide',
    names,
  };
}

export function createTypeCatalog(disciplines) {
  const byModelGuid = new Map();
  for (const discipline of disciplines) {
    const modelGuid = normalizeString(discipline.modelGuid, 'disciplines[].modelGuid');
    byModelGuid.set(modelGuid, {
      discipline: normalizeDisciplineName(discipline.discipline),
      types: new Set((discipline.types || []).map(type => String(type).trim()).filter(Boolean)),
    });
  }

  return byModelGuid;
}

function normalizeEndpointRef(endpoint, fieldName) {
  const discipline = normalizeDisciplineName(endpoint?.discipline);
  const modelGuid = normalizeString(endpoint?.modelGuid, `${fieldName}.modelGuid`);
  const entityType = normalizeEndpointType(endpoint, `${fieldName}.entityType`);

  return {
    modelGuid,
    discipline,
    entityType,
  };
}

function normalizeMatrixRule(rule = {}) {
  return {
    marker: String(rule?.marker || rule?.name || 'G').trim() || 'G',
    toleranceMm: normalizeToleranceMm(rule?.toleranceMm || rule || {}),
  };
}

function normalizeMatrixIndex(value, fieldName, length, label) {
  if (!Number.isInteger(value) || value < 0 || value >= length) {
    throw badRequest(
      'INVALID_MATRIX',
      `${fieldName} must be a valid ${label} index.`,
      { index: value, count: length },
    );
  }

  return value;
}

function normalizeCompactMatrixPair(pair, index, axes, rules, matrix) {
  if (!Array.isArray(matrix?.axes) || axes.length === 0) {
    throw badRequest(
      'INVALID_MATRIX',
      'matrix.axes must contain endpoint definitions when enabledPairs use compact indexes.',
    );
  }
  if (pair.length !== 2 && pair.length !== 3) {
    throw badRequest(
      'INVALID_MATRIX',
      `matrix.enabledPairs[${index}] must be [sourceAxisIndex, targetAxisIndex] or [sourceAxisIndex, targetAxisIndex, ruleIndex].`,
    );
  }

  const sourceIndex = normalizeMatrixIndex(
    pair[0],
    `matrix.enabledPairs[${index}][0]`,
    axes.length,
    'axis',
  );
  const targetIndex = normalizeMatrixIndex(
    pair[1],
    `matrix.enabledPairs[${index}][1]`,
    axes.length,
    'axis',
  );
  let rule = rules[0] || normalizeMatrixRule(matrix?.rule || {});
  if (pair.length === 3) {
    const ruleIndex = normalizeMatrixIndex(
      pair[2],
      `matrix.enabledPairs[${index}][2]`,
      rules.length,
      'rule',
    );
    rule = rules[ruleIndex];
  }

  return {
    source: axes[sourceIndex],
    target: axes[targetIndex],
    ...rule,
  };
}

function matrixPairIdentity(pair) {
  const endpointIdentity = endpoint => JSON.stringify([
    endpoint.modelGuid,
    endpoint.discipline,
    endpoint.entityType,
  ]);
  const endpoints = [
    endpointIdentity(pair.source),
    endpointIdentity(pair.target),
  ].sort();
  return JSON.stringify([
    endpoints,
    pair.marker,
    pair.toleranceMm.horizontal,
    pair.toleranceMm.vertical,
  ]);
}

export function normalizeMatrixRequest(matrix) {
  const enabledPairs = Array.isArray(matrix?.enabledPairs) ? matrix.enabledPairs : [];
  if (enabledPairs.length === 0) {
    throw badRequest('INVALID_MATRIX', 'matrix.enabledPairs must contain at least one enabled pair.');
  }
  if (enabledPairs.length > MAX_MATRIX_PAIR_COUNT) {
    throw badRequest(
      'MATRIX_TOO_COMPLEX',
      `matrix.enabledPairs must contain at most ${MAX_MATRIX_PAIR_COUNT} pairs.`,
      {
        pairCount: enabledPairs.length,
        maxPairCount: MAX_MATRIX_PAIR_COUNT,
      },
    );
  }

  const axes = Array.isArray(matrix?.axes)
    ? matrix.axes.map((axis, index) => normalizeEndpointRef(axis, `matrix.axes[${index}]`))
    : [];
  const rules = Array.isArray(matrix?.rules)
    ? matrix.rules.map(rule => normalizeMatrixRule(rule))
    : [];

  const seenPairs = new Map();
  const normalizedPairs = enabledPairs.map((pair, index) => {
    if (!Array.isArray(pair)) {
      throw badRequest(
        'INVALID_MATRIX',
        `matrix.enabledPairs[${index}] must be a compact axis-index tuple.`,
      );
    }
    const normalizedPair = normalizeCompactMatrixPair(pair, index, axes, rules, matrix);
    const identity = matrixPairIdentity(normalizedPair);
    if (seenPairs.has(identity)) {
      throw badRequest(
        'DUPLICATE_MATRIX_PAIR',
        'matrix.enabledPairs must not repeat the same clash rule in either direction.',
        { firstIndex: seenPairs.get(identity), duplicateIndex: index },
      );
    }
    seenPairs.set(identity, index);
    return normalizedPair;
  });

  return {
    enabledPairs: normalizedPairs,
    options: {
      ignoreSameSystem: matrix?.options?.ignoreSameSystem !== false,
      ignoreSpacesAndOpenings: matrix?.options?.ignoreSpacesAndOpenings !== false,
    },
  };
}

function getCatalogEntryForEndpoint(catalog, endpoint, index, side) {
  const entry = catalog.get(endpoint.modelGuid);
  if (!entry || entry.discipline !== endpoint.discipline) {
    throw badRequest(
      'UNKNOWN_MATRIX_MODEL',
      'Matrix endpoint modelGuid/discipline is not in the model catalog.',
      { index, side, modelGuid: endpoint.modelGuid, discipline: endpoint.discipline },
    );
  }

  return entry;
}

export function validateMatrixAgainstCatalog(matrix, disciplines) {
  const catalog = createTypeCatalog(disciplines);
  const normalizedMatrix = normalizeMatrixRequest(matrix);

  for (const [index, pair] of normalizedMatrix.enabledPairs.entries()) {
    const sourceEntry = getCatalogEntryForEndpoint(catalog, pair.source, index, 'source');
    const targetEntry = getCatalogEntryForEndpoint(catalog, pair.target, index, 'target');
    if (!sourceEntry.types.has(pair.source.entityType)) {
      throw badRequest('UNKNOWN_MATRIX_TYPE', 'Matrix source discipline/type is not in the type catalog.', {
        index,
        discipline: pair.source.discipline,
        modelGuid: pair.source.modelGuid,
        entityType: pair.source.entityType,
      });
    }
    if (!targetEntry.types.has(pair.target.entityType)) {
      throw badRequest('UNKNOWN_MATRIX_TYPE', 'Matrix target discipline/type is not in the type catalog.', {
        index,
        discipline: pair.target.discipline,
        modelGuid: pair.target.modelGuid,
        entityType: pair.target.entityType,
      });
    }
  }

  return normalizedMatrix;
}

export function normalizeReportRequest(body, config) {
  const { projectGuid, models } = normalizeModelsInput({
    projectGuid: body?.projectGuid,
    models: body?.models,
    config,
  });
  const outputUri = body?.outputUri ? String(body.outputUri).trim() : '';
  const outputPrefix = body?.outputPrefix ? String(body.outputPrefix).trim() : '';

  if (!outputUri && !outputPrefix) {
    throw badRequest('INVALID_OUTPUT', 'Either outputUri or outputPrefix is required.');
  }

  assertAllowedGcsUri(outputUri || outputPrefix, {
    kind: 'output',
    projectGuid,
    config,
  });

  const maxBatchSize = config?.maxBatchSize ?? MAX_CLASH_BATCH_SIZE;
  let batchSize;
  try {
    batchSize = normalizeClashBatchSize(body?.batchSize, { maxBatchSize });
  } catch {
    throw badRequest(
      'INVALID_BATCH_SIZE',
      `batchSize must be an integer between 1 and ${maxBatchSize}.`,
    );
  }
  const progressCorrelationId = normalizeOptionalString(body?.progressCorrelationId) || null;
  if (config?.progressPublishEnabled && !progressCorrelationId) {
    throw badRequest(
      'INVALID_PROGRESS_CORRELATION_ID',
      'progressCorrelationId is required when progress publishing is enabled.',
    );
  }
  if (Object.hasOwn(body || {}, 'progressTopic')) {
    throw badRequest(
      'INVALID_PROGRESS_TOPIC',
      'progressTopic is configured by the clash service and cannot be selected per request.',
    );
  }

  return {
    projectGuid,
    detectionIdentity: normalizeDetectionIdentity(body?.detectionIdentity),
    models,
    matrix: body?.matrix,
    spatialLevelFilter: normalizeSpatialLevelFilter(body?.spatialLevelFilter),
    outputUri,
    outputPrefix,
    batchSize,
    batchSizeLimit: maxBatchSize,
    clientRequestId: String(body?.clientRequestId || '').trim() || null,
    progressCorrelationId,
  };
}

export function createMatrixDraft(disciplines, options = {}) {
  const axes = disciplines.flatMap((group, groupIndex) => (
    (group.types || []).map((entityType, typeIndex) => ({
      id: `${group.modelGuid}-${typeIndex}`,
      modelGuid: group.modelGuid,
      ...(group.modelName ? { modelName: group.modelName } : {}),
      folderName: group.modelGuid,
      discipline: group.discipline,
      entityType,
    }))
  ));
  const enabledPairs = [];
  const toEndpoint = axis => ({
    modelGuid: axis.modelGuid,
    discipline: axis.discipline,
    entityType: axis.entityType,
  });

  for (const [rowIndex, rowAxis] of axes.entries()) {
    for (const [columnIndex, columnAxis] of axes.entries()) {
      if (columnIndex > rowIndex) {
        continue;
      }

      enabledPairs.push({
        source: toEndpoint(rowAxis),
        target: toEndpoint(columnAxis),
        marker: options.marker || 'G',
        toleranceMm: {
          horizontal: 0,
          vertical: 0,
        },
      });
    }
  }

  return {
    rule: {
      marker: options.marker || 'G',
      horizontalToleranceMm: 0,
      verticalToleranceMm: 0,
    },
    options: {
      ignoreSameSystem: true,
      ignoreSpacesAndOpenings: true,
    },
    axes,
    enabledPairs,
  };
}

export function stableRequestHash(value) {
  const normalize = input => {
    if (Array.isArray(input)) {
      return input.map(item => normalize(item));
    }
    if (input && typeof input === 'object') {
      return Object.fromEntries(
        Object.keys(input)
          .sort()
          .map(key => [key, normalize(input[key])]),
      );
    }

    return input;
  };
  const json = JSON.stringify(normalize(value));
  return crypto.createHash('sha256').update(json).digest('hex');
}
