import { isActiveStatus, isTerminalStatus } from './jobStore.js';
import {
  didCloudRunExecutionSucceed,
  isCloudRunExecutionTerminal,
  isLocalInlineExecution,
} from './cloudRunClient.js';

function isExpired(value) {
  const timestamp = Date.parse(value || '');
  return Number.isFinite(timestamp) && timestamp < Date.now();
}

function isHeartbeatStale(job, config) {
  const timestamp = Date.parse(job.heartbeatAt || job.updatedAt || '');
  if (!Number.isFinite(timestamp)) {
    return true;
  }

  return Date.now() - timestamp > config.heartbeatStaleMs;
}

function isExternalExecution(job) {
  return Boolean(job.executionName && !isLocalInlineExecution(job.executionName));
}

function isCleanupDue(job) {
  const timestamp = Date.parse(job.executionCleanupNextAttemptAt || '');
  return !Number.isFinite(timestamp) || timestamp <= Date.now();
}

function isExecutionLookupDue(job) {
  const timestamp = Date.parse(job.executionLookupNextAttemptAt || '');
  return !Number.isFinite(timestamp) || timestamp <= Date.now();
}

function executionLookupErrorDetails(error) {
  const rawStatus = error?.response?.status ?? error?.code ?? null;
  const numericStatus = (
    typeof rawStatus === 'number'
    || (typeof rawStatus === 'string' && rawStatus.trim() !== '')
  )
    ? Number(rawStatus)
    : Number.NaN;
  const httpStatus = Number.isInteger(numericStatus) ? numericStatus : null;
  const canonicalCode = String(
    error?.response?.data?.error?.status
    || error?.response?.data?.error?.code
    || error?.code
    || 'UNKNOWN',
  );
  let kind = 'unknown';
  let retryable = true;
  if (httpStatus === 404 || canonicalCode === 'NOT_FOUND') {
    kind = 'not_found';
    retryable = false;
  } else if (
    httpStatus === 401
    || httpStatus === 403
    || canonicalCode === 'UNAUTHENTICATED'
    || canonicalCode === 'PERMISSION_DENIED'
  ) {
    kind = 'permission';
    retryable = false;
  } else if (httpStatus === 429 || (httpStatus !== null && httpStatus >= 500)) {
    kind = 'transient';
  }

  return {
    kind,
    code: canonicalCode,
    httpStatus,
    message: String(error?.message || error).slice(0, 2_000),
    retryable,
  };
}

function executionLookupFailureError(details) {
  const notFound = details.kind === 'not_found';
  return {
    code: notFound
      ? 'CLOUD_RUN_EXECUTION_NOT_FOUND'
      : 'CLOUD_RUN_EXECUTION_LOOKUP_FAILED',
    message: notFound
      ? 'The stale Cloud Run execution no longer exists.'
      : 'Cloud Run execution status remained unreadable after bounded reconciliation attempts.',
    phase: 'compute',
    retryable: details.retryable,
  };
}

function mergeJobs(...jobLists) {
  const jobsById = new Map();
  for (const job of jobLists.flat()) {
    if (job?.jobId) {
      jobsById.set(job.jobId, job);
    }
  }
  return [...jobsById.values()];
}

function executionFailureError(job, execution) {
  const completedCondition = (execution?.conditions || []).find(condition => condition.type === 'Completed');
  return {
    code: 'CLOUD_RUN_EXECUTION_FAILED',
    message: completedCondition?.message || 'Cloud Run execution ended before the worker reported success.',
    phase: job.status === 'starting' ? 'start' : 'compute',
    retryable: true,
  };
}

async function reconcileExecutionCleanup({ store, cloudRunClient, job }) {
  let cancelError = null;
  if (cloudRunClient?.cancelExecution) {
    try {
      await cloudRunClient.cancelExecution(job.executionName);
    } catch (error) {
      cancelError = error;
    }
  }

  let execution = null;
  let readError = null;
  if (cloudRunClient?.getExecution) {
    try {
      execution = await cloudRunClient.getExecution(job.executionName);
    } catch (error) {
      readError = error;
    }
  } else {
    readError = new Error('Cloud Run execution status client is unavailable.');
  }

  let currentJob = await store.recordExecutionCleanupAttempt({
    jobId: job.jobId,
    error: readError || cancelError,
  });
  if (!currentJob || !isCloudRunExecutionTerminal(execution)) {
    return { job: currentJob, completed: false, canceled: false };
  }

  if (isTerminalStatus(currentJob.status)) {
    currentJob = await store.completeExecutionCleanup({ jobId: currentJob.jobId });
    return { job: currentJob, completed: true, canceled: false };
  }

  const terminal = await store.markTerminal({
    jobId: currentJob.jobId,
    startToken: currentJob.startToken,
    status: 'canceled',
    updatedBy: 'reconciler',
    executionTerminalConfirmed: true,
  });
  if (terminal.type === 'stale' && isTerminalStatus(terminal.job?.status)) {
    currentJob = await store.completeExecutionCleanup({ jobId: terminal.job.jobId });
    return { job: currentJob, completed: true, canceled: false };
  }

  return {
    job: terminal.job,
    completed: terminal.type !== 'stale',
    canceled: terminal.type === 'updated',
  };
}

export async function reconcileClashJobs({ store, cloudRunClient, config }) {
  const [activeJobs, cleanupJobs] = await Promise.all([
    store.listActiveJobs(config.reconcileLimit),
    store.listExecutionCleanupJobs(config.reconcileLimit),
  ]);
  const jobs = mergeJobs(activeJobs, cleanupJobs);
  const summary = {
    inspected: jobs.length,
    failedStarting: 0,
    canceled: 0,
    failedStale: 0,
    cleanupAttempted: 0,
    cleanupCompleted: 0,
    cleanupDeferred: 0,
    executionLookupFailed: 0,
    executionLookupDeferred: 0,
    executionLookupEscalated: 0,
    repairedStagedJobs: 0,
    repairedLocks: 0,
    repairedGlobalCapacity: null,
  };

  const reconcilePendingCleanup = async job => {
    if (!job?.executionCleanupPending) {
      return job;
    }
    if (!isCleanupDue(job)) {
      summary.cleanupDeferred += 1;
      return job;
    }
    summary.cleanupAttempted += 1;
    const cleanup = await reconcileExecutionCleanup({ store, cloudRunClient, job });
    if (cleanup.completed) {
      summary.cleanupCompleted += 1;
    }
    if (cleanup.canceled) {
      summary.canceled += 1;
    }
    return cleanup.job;
  };

  for (const observedJob of jobs) {
    let job = observedJob;

    if (job.status === 'starting' && isExpired(job.leaseExpiresAt)) {
      job = await store.markStartFailed({
        jobId: job.jobId,
        error: {
          code: 'START_LEASE_EXPIRED',
          message: job.executionName
            ? 'The start lease expired before a worker heartbeat was recorded.'
            : 'The start lease expired before a worker heartbeat or execution name was recorded.',
          phase: 'start',
          retryable: true,
        },
      });
      summary.failedStarting += 1;
      await reconcilePendingCleanup(job);
      continue;
    }

    if (job.status === 'canceling') {
      if (isExternalExecution(job)) {
        if (!job.executionCleanupPending) {
          job = await store.ensureExecutionCleanupPending({ jobId: job.jobId });
        }
        await reconcilePendingCleanup(job);
      } else if (isExpired(job.leaseExpiresAt)) {
        await store.markTerminal({
          jobId: job.jobId,
          startToken: job.startToken,
          status: 'canceled',
          updatedBy: 'reconciler',
        });
        summary.canceled += 1;
      }
      continue;
    }

    if (job.executionCleanupPending) {
      job = await reconcilePendingCleanup(job);
      if (!job || isTerminalStatus(job.status)) {
        continue;
      }
    }

    if (!isActiveStatus(job.status)) {
      continue;
    }

    if (job.status === 'running' && isHeartbeatStale(job, config)) {
      if (!isExecutionLookupDue(job)) {
        summary.executionLookupDeferred += 1;
        continue;
      }
      let execution = null;
      let lookupError = null;
      if (job.executionName && cloudRunClient?.getExecution) {
        try {
          execution = await cloudRunClient.getExecution(job.executionName);
          if (!execution) {
            lookupError = new Error('Cloud Run returned no execution resource.');
          }
        } catch (error) {
          lookupError = error;
        }
      } else {
        lookupError = new Error('Cloud Run execution status client is unavailable.');
      }

      if (lookupError) {
        const details = executionLookupErrorDetails(lookupError);
        job = await store.recordExecutionLookupFailure({
          jobId: job.jobId,
          error: details,
        });
        summary.executionLookupFailed += 1;
        if (!job || !isActiveStatus(job.status)) {
          continue;
        }
        const failureLimit = config.executionLookupFailureLimit;
        if (details.kind === 'not_found' || job.executionLookupFailureCount >= failureLimit) {
          if (details.kind !== 'not_found' && isExternalExecution(job)) {
            job = await store.ensureExecutionCleanupPending({ jobId: job.jobId });
            if (!job || !isActiveStatus(job.status)) {
              continue;
            }
          }
          await store.markTerminal({
            jobId: job.jobId,
            startToken: job.startToken,
            status: 'failed',
            error: executionLookupFailureError(details),
            updatedBy: 'reconciler',
            executionTerminalConfirmed: details.kind === 'not_found',
          });
          summary.failedStale += 1;
          summary.executionLookupEscalated += 1;
        }
        continue;
      }

      if (job.executionLookupFailureCount > 0) {
        job = await store.recordExecutionLookupSuccess({ jobId: job.jobId });
        if (!job || !isActiveStatus(job.status)) {
          continue;
        }
      }

      if (execution && isCloudRunExecutionTerminal(execution)) {
        if (didCloudRunExecutionSucceed(execution)) {
          await store.markTerminal({
            jobId: job.jobId,
            startToken: job.startToken,
            status: 'failed',
            error: {
              code: 'WORKER_EXITED_WITHOUT_TERMINAL_UPDATE',
              message: 'Cloud Run execution completed without a terminal Firestore update.',
              phase: 'compute',
              retryable: true,
            },
            updatedBy: 'reconciler',
          });
          summary.failedStale += 1;
        } else {
          await store.markTerminal({
            jobId: job.jobId,
            startToken: job.startToken,
            status: 'failed',
            error: executionFailureError(job, execution),
            updatedBy: 'reconciler',
          });
          summary.failedStale += 1;
        }
      }
    }
  }

  summary.repairedStagedJobs = await store.repairStagedJobs();
  summary.repairedLocks = await store.repairProjectLocks();
  summary.repairedGlobalCapacity = await store.repairGlobalCapacity();
  return summary;
}
