/**
 * @typedef {Object} ModelFiles
 * @property {string} model
 * @property {string} geometry
 * @property {string} relationships
 */

/**
 * Describes one parquet-backed discipline model for the core algorithm.
 *
 * This object is intentionally lightweight. It points to runtime-readable
 * parquet files but does not contain parquet rows, vertices, faces, or meshes.
 *
 * @typedef {Object} ModelDescriptor
 * @property {string} modelId
 * @property {string} discipline
 * @property {string} folderName
 * @property {ModelFiles} files
 */

/**
 * Describes all models that participate in one clash detection project.
 *
 * @typedef {Object} ProjectDescriptor
 * @property {string} [projectId]
 * @property {ModelDescriptor[]} models
 */

function cleanString(value) {
  return String(value ?? '').trim();
}

/**
 * Normalizes one model descriptor without touching the filesystem.
 *
 * @param {Partial<ModelDescriptor>} model
 * @returns {ModelDescriptor}
 */
export function normalizeModelDescriptor(model) {
  const files = model?.files || {};

  return {
    modelId: cleanString(model?.modelId),
    discipline: cleanString(model?.discipline),
    folderName: cleanString(model?.folderName),
    files: {
      model: cleanString(files.model),
      geometry: cleanString(files.geometry),
      relationships: cleanString(files.relationships),
    },
  };
}

/**
 * Normalizes a project descriptor into the core input contract.
 *
 * @param {Partial<ProjectDescriptor>} input
 * @returns {ProjectDescriptor}
 */
export function normalizeProjectDescriptor(input = {}) {
  const models = Array.isArray(input.models) ? input.models : [];

  return {
    projectId: cleanString(input.projectId) || undefined,
    models: models.map(model => normalizeModelDescriptor(model)),
  };
}

/**
 * Validates the core project descriptor contract.
 *
 * @param {ProjectDescriptor} project
 * @returns {void}
 */
export function validateProjectDescriptor(project) {
  if (!project || !Array.isArray(project.models) || project.models.length === 0) {
    throw new Error('ProjectDescriptor.models must contain at least one model.');
  }

  const modelIds = new Set();
  for (const model of project.models) {
    if (!model.modelId) {
      throw new Error('ModelDescriptor.modelId is required.');
    }
    if (!model.folderName) {
      throw new Error(`ModelDescriptor.folderName is required for model "${model.modelId}".`);
    }
    if (modelIds.has(model.modelId)) {
      throw new Error(`Duplicate ModelDescriptor.modelId "${model.modelId}".`);
    }
    modelIds.add(model.modelId);

    if (!model.discipline) {
      throw new Error(`ModelDescriptor.discipline is required for model "${model.modelId}".`);
    }
    if (!model.files?.model) {
      throw new Error(`ModelDescriptor.files.model is required for model "${model.modelId}".`);
    }
    if (!model.files?.geometry) {
      throw new Error(`ModelDescriptor.files.geometry is required for model "${model.modelId}".`);
    }
    if (!model.files?.relationships) {
      throw new Error(`ModelDescriptor.files.relationships is required for model "${model.modelId}".`);
    }
  }
}

/**
 * Returns a validated, normalized project descriptor.
 *
 * @param {Partial<ProjectDescriptor>} input
 * @returns {ProjectDescriptor}
 */
export function createProjectDescriptor(input = {}) {
  const project = normalizeProjectDescriptor(input);
  validateProjectDescriptor(project);
  return project;
}

/**
 * Finds one model by modelId.
 *
 * @param {ProjectDescriptor} project
 * @param {string} modelId
 * @returns {ModelDescriptor}
 */
export function getModelDescriptor(project, modelId) {
  const normalizedModelId = cleanString(modelId);
  const model = project?.models?.find(candidate => candidate.modelId === normalizedModelId);
  if (!model) {
    throw new Error(`ModelDescriptor "${normalizedModelId}" was not found.`);
  }

  return model;
}

/**
 * Returns one required parquet file reference from a model descriptor.
 *
 * @param {ModelDescriptor} model
 * @param {'model' | 'geometry' | 'relationships'} fileKey
 * @returns {string}
 */
export function getModelFile(model, fileKey) {
  const filePath = cleanString(model?.files?.[fileKey]);
  if (!filePath) {
    throw new Error(`ModelDescriptor.files.${fileKey} is required.`);
  }

  return filePath;
}
