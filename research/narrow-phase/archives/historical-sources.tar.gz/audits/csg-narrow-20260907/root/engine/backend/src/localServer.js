import Fastify from 'fastify';
import cors from '@fastify/cors';
import { resolveApiBodyLimitBytes } from './apiServerOptions.js';
import { registerLocalClashRoutes } from './local/routes.js';

const DEFAULT_HOST = process.env.HOST || '127.0.0.1';
const DEFAULT_PORT = Number(process.env.PORT || 3000);
const CORS_ORIGIN = process.env.CORS_ORIGIN || true;

const app = Fastify({
  logger: true,
  bodyLimit: resolveApiBodyLimitBytes(),
});

await app.register(cors, {
  origin: CORS_ORIGIN,
});

app.get('/api/health', async () => ({ ok: true }));

await registerLocalClashRoutes(app);

await app.listen({
  host: DEFAULT_HOST,
  port: DEFAULT_PORT,
});
