function cleanId(value) {
  return String(value ?? '').trim();
}

function addSetValue(map, key, value) {
  if (!map.has(key)) {
    map.set(key, new Set());
  }
  map.get(key).add(value);
}

/**
 * Builds model-local IfcRelAggregates connected components. Valid components
 * are trees; every member receives the same stable model-qualified tree id.
 * Invalid components deliberately receive no tree id so they cannot cause a
 * false-negative same-tree filter.
 */
export function createAggregateForest(modelRows = [], relationshipRows = [], { modelId } = {}) {
  const normalizedModelId = cleanId(modelId);
  if (!normalizedModelId) {
    throw new Error('modelId is required to build an aggregate forest.');
  }

  const modelObjectIds = new Set(
    modelRows.map(row => cleanId(row?.GlobalId)).filter(Boolean),
  );
  const adjacency = new Map();
  const parentCandidatesByChild = new Map();
  const childrenByParent = new Map();
  const invalidSeeds = new Set();
  const uniqueEdges = new Set();
  let duplicateEdgeCount = 0;
  let missingModelObjectEdgeCount = 0;
  let selfReferenceCount = 0;

  for (const row of relationshipRows) {
    if (cleanId(row?.Relationship_Type) !== 'IfcRelAggregates') {
      continue;
    }

    const parentId = cleanId(row?.Relating_Object_GUID);
    const childId = cleanId(row?.Related_Object_GUID);
    if (!parentId || !childId) {
      continue;
    }
    if (!modelObjectIds.has(parentId) || !modelObjectIds.has(childId)) {
      missingModelObjectEdgeCount += 1;
      if (modelObjectIds.has(parentId)) invalidSeeds.add(parentId);
      if (modelObjectIds.has(childId)) invalidSeeds.add(childId);
      continue;
    }
    if (parentId === childId) {
      selfReferenceCount += 1;
      invalidSeeds.add(parentId);
      addSetValue(adjacency, parentId, childId);
      continue;
    }

    const edgeKey = `${parentId}\u0000${childId}`;
    if (uniqueEdges.has(edgeKey)) {
      duplicateEdgeCount += 1;
      invalidSeeds.add(parentId);
      invalidSeeds.add(childId);
      continue;
    }
    uniqueEdges.add(edgeKey);
    addSetValue(adjacency, parentId, childId);
    addSetValue(adjacency, childId, parentId);
    addSetValue(parentCandidatesByChild, childId, parentId);
    addSetValue(childrenByParent, parentId, childId);
  }

  for (const [childId, parentIds] of parentCandidatesByChild) {
    if (parentIds.size > 1) {
      invalidSeeds.add(childId);
      for (const parentId of parentIds) invalidSeeds.add(parentId);
    }
  }

  const treeIdByObject = new Map();
  const membersByTreeId = new Map();
  const parentByChild = new Map();
  const invalidObjectIds = new Set();
  const visited = new Set();
  let validTreeCount = 0;
  let invalidComponentCount = 0;

  for (const startId of adjacency.keys()) {
    if (visited.has(startId)) continue;

    const members = [];
    const stack = [startId];
    let componentHasInvalidSeed = false;
    let componentDegreeSum = 0;
    while (stack.length > 0) {
      const objectId = stack.pop();
      if (visited.has(objectId)) continue;
      visited.add(objectId);
      members.push(objectId);
      componentHasInvalidSeed ||= invalidSeeds.has(objectId);
      const neighbors = adjacency.get(objectId) || new Set();
      componentDegreeSum += neighbors.size;
      for (const neighborId of neighbors) {
        if (!visited.has(neighborId)) stack.push(neighborId);
      }
    }

    const roots = members.filter(objectId => !parentCandidatesByChild.has(objectId));
    const edgeCount = componentDegreeSum / 2;
    const valid = (
      !componentHasInvalidSeed
      && roots.length === 1
      && edgeCount === members.length - 1
    );
    if (!valid) {
      invalidComponentCount += 1;
      for (const objectId of members) invalidObjectIds.add(objectId);
      continue;
    }

    const rootId = roots[0];
    const treeId = `${normalizedModelId}::${rootId}`;
    const memberSet = new Set(members);
    membersByTreeId.set(treeId, memberSet);
    for (const objectId of members) {
      treeIdByObject.set(objectId, treeId);
      const parents = parentCandidatesByChild.get(objectId);
      if (parents?.size === 1) {
        parentByChild.set(objectId, [...parents][0]);
      }
    }
    validTreeCount += 1;
  }

  return {
    treeIdByObject,
    membersByTreeId,
    parentByChild,
    childrenByParent,
    invalidObjectIds,
    stats: {
      validTreeCount,
      invalidComponentCount,
      treeMemberCount: treeIdByObject.size,
      invalidObjectCount: invalidObjectIds.size,
      duplicateEdgeCount,
      missingModelObjectEdgeCount,
      selfReferenceCount,
    },
  };
}
