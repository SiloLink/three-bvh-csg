import crypto from 'node:crypto';
import {
  createCloudRunClient,
  isCloudRunExecutionTerminal,
  isLocalInlineExecution,
} from './cloudRunClient.js';
import { getClashConfig } from './config.js';
import { authenticateInternalRequest, authenticatePublicRequest, assertJobAccess } from './auth.js';
import {
  createJobDocument,
  createJobStore,
  createLease,
  isTerminalStatus,
  matchesIdempotencyRequest,
} from './jobStore.js';
import { loadTypeCatalogFromModels } from './gcsModelCatalog.js';
import { reconcileClashJobs } from './reconciler.js';
import { toAcceptedJobResponse, toJobResponse } from './responses.js';
import { serializeHttpError, conflict, serviceUnavailable, tooManyRequests } from './httpErrors.js';
import {
  createMatrixDraft,
  normalizeMatrixRequest,
  normalizeModelsInput,
  normalizeReportRequest,
  stableRequestHash,
  validateMatrixAgainstCatalog,
} from './validation.js';
import { mergeSpatialLevelCatalogs } from '../core/model/spatial-levels.js';
import { resolveCloudReportTarget } from '../io/reportWriters.js';
import { runClashReportJob } from '../jobs/runClashReportJob.js';

function getIdempotencyKey(request, body) {
  const headerValue = request.headers['idempotency-key'];
  const rawValue = Array.isArray(headerValue) ? headerValue[0] : headerValue;
  return String(rawValue || body?.clientRequestId || '').trim() || null;
}

function stripCatalogSnapshot(entry) {
  const { sourceObjects: _sourceObjects, ...publicEntry } = entry;
  return publicEntry;
}

function pinModelsToCatalog(models, catalog) {
  const catalogByModelGuid = new Map(catalog.map(entry => [entry.modelGuid, entry]));
  return models.map(model => {
    const sourceObjects = catalogByModelGuid.get(model.modelGuid)?.sourceObjects;
    if (!sourceObjects) {
      throw new Error(`Catalog snapshot is missing source objects for model ${model.modelGuid}.`);
    }
    return { ...model, sourceObjects };
  });
}

function sendError(reply, error) {
  const { statusCode, payload } = serializeHttpError(error);
  return reply.code(statusCode).send(payload);
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function cancelAndSettleExecution({
  store,
  cloudRunClient,
  config,
  job,
  logger,
}) {
  let currentJob = job;
  if (
    !currentJob
    || !currentJob.executionName
    || isLocalInlineExecution(currentJob.executionName)
  ) {
    return currentJob;
  }
  if (isTerminalStatus(currentJob.status) && !currentJob.executionCleanupPending) {
    return currentJob;
  }

  let cancelError = null;
  if (cloudRunClient?.cancelExecution) {
    try {
      await cloudRunClient.cancelExecution(currentJob.executionName);
    } catch (error) {
      cancelError = error;
    }
  }
  await store.recordExecutionCleanupAttempt({
    jobId: currentJob.jobId,
    error: cancelError,
  });
  if (cancelError) {
    logger.warn(
      { err: cancelError, jobId: currentJob.jobId },
      'Cloud Run execution cancel failed; durable cleanup will retry.',
    );
  }

  const deadline = Date.now() + config.cancelSettleTimeoutMs;
  let pollIntervalMs = config.cancelPollIntervalMs;
  const maxPollIntervalMs = Math.max(
    config.cancelPollIntervalMs,
    config.cancelPollMaxIntervalMs,
  );
  while (currentJob?.executionCleanupPending !== false) {
    let execution = null;
    if (cloudRunClient?.getExecution) {
      execution = await cloudRunClient.getExecution(currentJob.executionName).catch(error => {
        logger.warn(
          { err: error, jobId: currentJob.jobId },
          'Could not read Cloud Run execution while settling cancellation.',
        );
        return null;
      });
    }
    if (isCloudRunExecutionTerminal(execution)) {
      const latestJob = await store.getJob(currentJob.jobId);
      if (!latestJob) {
        return null;
      }
      if (isTerminalStatus(latestJob.status)) {
        return store.completeExecutionCleanup({ jobId: latestJob.jobId });
      }
      const terminal = await store.markTerminal({
        jobId: latestJob.jobId,
        startToken: latestJob.startToken,
        status: 'canceled',
        updatedBy: 'api',
        executionTerminalConfirmed: true,
      });
      if (terminal.type !== 'stale') {
        return terminal.job;
      }
      currentJob = terminal.job;
      continue;
    }

    currentJob = await store.getJob(currentJob.jobId);
    if (!currentJob || !currentJob.executionCleanupPending || Date.now() >= deadline) {
      return currentJob;
    }
    await wait(Math.min(pollIntervalMs, Math.max(0, deadline - Date.now())));
    pollIntervalMs = Math.min(
      maxPollIntervalMs,
      Math.max(config.cancelPollIntervalMs, pollIntervalMs * 2),
    );
  }

  return currentJob;
}

function mapClaimFailureToHttp(result, config) {
  if (result.type === 'project-conflict') {
    return conflict(
      'PROJECT_CLASH_REPORT_ACTIVE',
      'The project already has an active clash report.',
      {
        activeJobId: result.activeJob?.jobId || null,
        statusUrl: result.activeJob
          ? toJobResponse(result.activeJob, config).statusUrl
          : null,
      },
    );
  }

  if (result.type === 'capacity-exceeded') {
    return tooManyRequests(
      'CLASH_CAPACITY_EXCEEDED',
      'The clash report global capacity limit is full.',
      { retryAfterSeconds: 30 },
    );
  }

  if (result.type === 'idempotency-conflict') {
    return conflict(
      'IDEMPOTENCY_KEY_REUSED',
      'The same idempotency key was already used with a different request.',
      {},
    );
  }

  return serviceUnavailable('CLASH_JOB_NOT_ACCEPTED', 'The clash report job could not be accepted.');
}

export async function registerCloudClashRoutes(app, dependencies = {}) {
  const config = dependencies.config || getClashConfig();
  const store = dependencies.store || createJobStore(config);
  const cloudRunClient = dependencies.cloudRunClient || createCloudRunClient(config);
  const loadTypeCatalog = dependencies.loadTypeCatalogFromModels || loadTypeCatalogFromModels;
  const runInlineReportJob = dependencies.runInlineReportJob || runClashReportJob;

  const readStateBackendReadiness = async () => {
    try {
      await store.getJob('__clash_readiness_probe__');
    } catch {
      throw serviceUnavailable(
        'CLASH_STATE_UNAVAILABLE',
        'The clash state backend is unavailable.',
      );
    }
    return {
      ok: true,
      stateBackend: config.stateBackend,
    };
  };

  app.get('/api/ready', async (request, reply) => {
    try {
      authenticatePublicRequest(request, config);
      return await readStateBackendReadiness();
    } catch (error) {
      return sendError(reply, error);
    }
  });

  app.get('/internal/clash/ready', async (request, reply) => {
    try {
      authenticateInternalRequest(request, config);
      return await readStateBackendReadiness();
    } catch (error) {
      return sendError(reply, error);
    }
  });

  app.post('/api/matrix/init', async (request, reply) => {
    try {
      authenticatePublicRequest(request, config);
      const { projectGuid, models } = normalizeModelsInput({
        projectGuid: request.body?.projectGuid,
        models: request.body?.models,
        config,
      });
      const catalog = await loadTypeCatalog(models);
      const disciplines = catalog.map(stripCatalogSnapshot);

      return {
        projectGuid,
        models,
        disciplines,
        spatialLevels: mergeSpatialLevelCatalogs(disciplines),
        matrixDraft: createMatrixDraft(disciplines),
      };
    } catch (error) {
      return sendError(reply, error);
    }
  });

  app.post('/api/clash-reports', async (request, reply) => {
    try {
      const caller = authenticatePublicRequest(request, config);
      const earlyClientRequestId = getIdempotencyKey(request, request.body || {});
      let existingIdempotency = null;
      if (earlyClientRequestId) {
        existingIdempotency = await store.getIdempotentJob({
          ownerId: caller.ownerId,
          tenantId: caller.tenantId,
          clientRequestId: earlyClientRequestId,
        });
      }

      if (existingIdempotency?.job) {
        assertJobAccess(caller, existingIdempotency.job);
      }

      const normalizedRequest = normalizeReportRequest(request.body || {}, config);
      const matrixForHash = normalizeMatrixRequest(normalizedRequest.matrix);
      const clientRequestId = earlyClientRequestId || getIdempotencyKey(request, normalizedRequest);
      const requestHashInput = {
        projectGuid: normalizedRequest.projectGuid,
        detectionIdentity: normalizedRequest.detectionIdentity,
        models: normalizedRequest.models,
        matrix: matrixForHash,
        spatialLevelFilter: normalizedRequest.spatialLevelFilter,
        outputUri: normalizedRequest.outputUri,
        outputPrefix: normalizedRequest.outputPrefix,
        batchSize: normalizedRequest.batchSize,
      };
      const legacyRequestHash = stableRequestHash(requestHashInput);
      const requestHash = stableRequestHash({
        ...requestHashInput,
        progressCorrelationId: normalizedRequest.progressCorrelationId,
      });

      if (existingIdempotency?.record) {
        if (!matchesIdempotencyRequest(existingIdempotency, {
          requestHash,
          legacyRequestHash,
        })) {
          throw conflict(
            'IDEMPOTENCY_KEY_REUSED',
            'The same idempotency key was already used with a different request.',
            {},
          );
        }
        if (!existingIdempotency.job) {
          throw serviceUnavailable(
            'IDEMPOTENCY_JOB_MISSING',
            'The idempotency record exists, but the original job could not be found.',
          );
        }

        return reply.code(202).send(toAcceptedJobResponse(existingIdempotency.job, config));
      }

      const catalog = await loadTypeCatalog(normalizedRequest.models);
      const disciplines = catalog.map(stripCatalogSnapshot);
      const matrix = validateMatrixAgainstCatalog(normalizedRequest.matrix, disciplines);
      const pinnedModels = pinModelsToCatalog(normalizedRequest.models, catalog);
      const jobId = crypto.randomUUID();
      const cloudTarget = resolveCloudReportTarget({
        outputUri: normalizedRequest.outputUri,
        outputPrefix: normalizedRequest.outputPrefix,
        tempOutputPrefix: config.tempOutputPrefix,
        jobId,
        projectGuid: normalizedRequest.projectGuid,
      });
      const requestForJob = {
        ...normalizedRequest,
        models: pinnedModels,
        matrix,
        clientRequestId,
      };
      const lease = createLease(config);
      const job = createJobDocument({
        jobId,
        caller,
        request: requestForJob,
        requestHash,
        lease,
        config,
        resultUri: cloudTarget.resultUri,
        tempResultUri: cloudTarget.tempResultUri,
        cloudRunJobName: config.cloudRunJobName,
      });
      const claim = await store.claimJob({
        job,
        clientRequestId,
        requestHash,
        legacyRequestHash,
      });

      if (
        claim.job
        && (claim.type === 'idempotent' || claim.type === 'idempotency-conflict')
      ) {
        assertJobAccess(caller, claim.job);
      }

      if (claim.type === 'idempotent') {
        if (!claim.job) {
          throw serviceUnavailable(
            'IDEMPOTENCY_JOB_MISSING',
            'The idempotency record exists, but the original job could not be found.',
          );
        }
        return reply.code(202).send(toAcceptedJobResponse(claim.job, config));
      }
      if (claim.type !== 'created') {
        throw mapClaimFailureToHttp(claim, config);
      }

      try {
        const started = config.runReportsInline
          ? {
            jobName: null,
            executionName: `local-inline:${jobId}`,
            inline: true,
          }
          : await cloudRunClient.runReportJob({
            jobId,
            startToken: lease.startToken,
          });
        const startedJob = await store.recordCloudRunStarted({
          jobId,
          executionName: started.executionName,
          jobName: started.jobName,
        });
        if (startedJob?.executionCleanupPending) {
          await cancelAndSettleExecution({
            store,
            cloudRunClient,
            config,
            job: {
              ...startedJob,
              executionName: startedJob.executionName || started.executionName,
            },
            logger: request.log,
          });
        }
        if (config.runReportsInline) {
          void runInlineReportJob({
            config,
            store,
            jobId,
            startToken: lease.startToken,
            executionName: started.executionName,
          }).catch(error => {
            app.log.error({ err: error, jobId }, 'Inline clash report job failed.');
          });
        }
      } catch (error) {
        const failedJob = await store.markStartFailed({
          jobId,
          error: {
            code: 'CLASH_JOB_START_FAILED',
            message: error.message || String(error),
            stack: error.stack || null,
            phase: 'start',
            retryable: true,
          },
        });

        return reply.code(503).send({
          error: 'CLASH_JOB_START_FAILED',
          jobId,
          message: error.message || String(error),
          statusUrl: toJobResponse(failedJob, config)?.statusUrl,
        });
      }

      return reply.code(202).send(toAcceptedJobResponse(await store.getJob(jobId), config));
    } catch (error) {
      return sendError(reply, error);
    }
  });

  app.get('/api/clash-reports/:jobId', async (request, reply) => {
    try {
      const caller = authenticatePublicRequest(request, config);
      const job = await store.getJob(request.params.jobId);
      if (!job) {
        return reply.code(404).send({ error: 'CLASH_JOB_NOT_FOUND' });
      }
      assertJobAccess(caller, job);
      return toJobResponse(job, config);
    } catch (error) {
      return sendError(reply, error);
    }
  });

  app.post('/api/clash-reports/:jobId/cancel', async (request, reply) => {
    try {
      const caller = authenticatePublicRequest(request, config);
      const existingJob = await store.getJob(request.params.jobId);
      if (!existingJob) {
        return reply.code(404).send({ error: 'CLASH_JOB_NOT_FOUND' });
      }
      assertJobAccess(caller, existingJob);

      const job = await store.requestCancel({
        jobId: request.params.jobId,
        caller,
      });
      const settledJob = await cancelAndSettleExecution({
        store,
        cloudRunClient,
        config,
        job,
        logger: request.log,
      });
      const responseJob = settledJob || await store.getJob(request.params.jobId);
      const response = toJobResponse(responseJob, config);
      const statusCode = isTerminalStatus(response?.status) ? 200 : 202;
      return reply.code(statusCode).send(response);
    } catch (error) {
      return sendError(reply, error);
    }
  });

  app.post('/internal/clash/reconcile', async (request, reply) => {
    try {
      authenticateInternalRequest(request, config);
      const summary = await reconcileClashJobs({
        store,
        cloudRunClient,
        config,
      });
      return { ok: true, summary };
    } catch (error) {
      return sendError(reply, error);
    }
  });

  return { config, store, cloudRunClient };
}
