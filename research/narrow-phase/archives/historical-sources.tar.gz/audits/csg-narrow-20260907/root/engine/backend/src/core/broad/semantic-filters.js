export function normalizeModelLaneId(modelId) {
  return String(modelId || '').trim();
}

// Builds a relationship object key from an already-normalized model ID. Callers
// that key many rows from the same model normalize the model ID once and reuse it.
export function createRelationshipObjectKey(normalizedModelId, globalId) {
  const normalizedGlobalId = String(globalId || '').trim();
  if (!normalizedModelId || !normalizedGlobalId) {
    return null;
  }

  return `${normalizedModelId}::${normalizedGlobalId}`;
}

export function getRelationshipObjectKey(modelId, globalId) {
  return createRelationshipObjectKey(normalizeModelLaneId(modelId), globalId);
}

function getObjectRelationshipKey(object) {
  return getRelationshipObjectKey(object.modelId, object.globalId);
}

export function createSortedPairKey(sourceKey, targetKey) {
  return [sourceKey, targetKey].sort((a, b) => a.localeCompare(b)).join('||');
}

export function createSemanticFilterCounts() {
  return {
    COVERS_BLDG_ELEMENTS: 0,
    CONNECTS_PATH_ELEMENTS: 0,
    HOST_OPENING_FILL: 0,
    PORT_CONNECTED: 0,
  };
}

export function decideCoversBldgElementIgnore(sourceObject, targetObject, dataset) {
  const sourceKey = getObjectRelationshipKey(sourceObject);
  const targetKey = getObjectRelationshipKey(targetObject);

  if (!sourceKey || !targetKey) {
    return {
      ignore: false,
    };
  }

  if (dataset.coversBldgElementPairs?.has(createSortedPairKey(sourceKey, targetKey))) {
    return {
      ignore: true,
      level: 'COVERS_BLDG_ELEMENTS',
      reason: 'The candidate objects are connected by explicit IfcRelCoversBldgElements covered-element and covering relationship.',
    };
  }

  return {
    ignore: false,
  };
}

export function decideConnectsPathElementIgnore(sourceObject, targetObject, dataset) {
  const sourceKey = getObjectRelationshipKey(sourceObject);
  const targetKey = getObjectRelationshipKey(targetObject);

  if (!sourceKey || !targetKey) {
    return {
      ignore: false,
    };
  }

  if (dataset.connectsPathElementPairs?.has(createSortedPairKey(sourceKey, targetKey))) {
    return {
      ignore: true,
      level: 'CONNECTS_PATH_ELEMENTS',
      reason: 'The candidate objects are connected by explicit IfcRelConnectsPathElements path-element relationship.',
    };
  }

  return {
    ignore: false,
  };
}

export function decidePortConnectedIgnore(sourceObject, targetObject, dataset) {
  const sourceKey = getObjectRelationshipKey(sourceObject);
  const targetKey = getObjectRelationshipKey(targetObject);

  if (!sourceKey || !targetKey) {
    return {
      ignore: false,
    };
  }

  if (dataset.portConnectedElementPairs?.has(createSortedPairKey(sourceKey, targetKey))) {
    return {
      ignore: true,
      level: 'PORT_CONNECTED',
      reason: 'The candidate objects are joined through an IfcRelConnectsPorts port-to-port connection, with port ownership resolved via IfcRelNests or IfcRelConnectsPortToElement.',
    };
  }

  return {
    ignore: false,
  };
}

export function decideHostOpeningFillIgnore(sourceObject, targetObject, dataset) {
  const sourceKey = getObjectRelationshipKey(sourceObject);
  const targetKey = getObjectRelationshipKey(targetObject);

  if (!sourceKey || !targetKey) {
    return {
      ignore: false,
    };
  }

  if (dataset.hostOpeningFillPairs.has(createSortedPairKey(sourceKey, targetKey))) {
    return {
      ignore: true,
      level: 'HOST_OPENING_FILL',
      reason: 'The candidate objects are connected by IfcRelVoidsElement and IfcRelFillsElement through an IfcOpeningElement.',
    };
  }

  return {
    ignore: false,
  };
}
