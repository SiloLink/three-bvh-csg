export function boxContainsBox(outerBox, innerBox, tolerance) {
  if (!outerBox || !innerBox) {
    return false;
  }

  return (
    outerBox.min.x <= innerBox.min.x + tolerance
    && outerBox.min.y <= innerBox.min.y + tolerance
    && outerBox.min.z <= innerBox.min.z + tolerance
    && outerBox.max.x >= innerBox.max.x - tolerance
    && outerBox.max.y >= innerBox.max.y - tolerance
    && outerBox.max.z >= innerBox.max.z - tolerance
  );
}

export function boxesNearlyMutuallyContain(boxA, boxB, tolerance) {
  return boxContainsBox(boxA, boxB, tolerance) && boxContainsBox(boxB, boxA, tolerance);
}
