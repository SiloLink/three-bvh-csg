export const MODEL_FILE_SPECS = Object.freeze([
  Object.freeze({ key: 'model', fileName: 'model.parquet' }),
  Object.freeze({ key: 'geometry', fileName: 'geometry_library.parquet' }),
  Object.freeze({ key: 'relationships', fileName: 'relationships.parquet' }),
]);

export const REQUIRED_MODEL_FILES = Object.freeze(
  MODEL_FILE_SPECS.map(spec => spec.fileName),
);
