import crypto from 'node:crypto';
import { normalizeSpatialLevelName } from '../core/model/spatial-levels.js';
import {
  PAIR_HASH_ENCODING,
  PAIR_HASH_MANIFEST_SCHEMA_VERSION,
  canonicalPairKey,
} from './pair-hash-evidence.js';

export const EVALUATED_COVERAGE_SCHEMA_VERSION = 'clash.evaluated-coverage/1.0';
export const ENGINE_SEMANTICS_VERSION = 'clash-detection.engine/1.0';

function cleanText(value) {
  return String(value ?? '').trim();
}

// Canonical artifact ordering must be byte-deterministic across hosts, so it
// compares code units instead of using locale-aware collation.
function compareText(left, right) {
  if (left < right) return -1;
  if (left > right) return 1;
  return 0;
}

function endpointFromRule(endpoint = {}) {
  return {
    modelId: cleanText(endpoint.modelGuid || endpoint.modelId),
    discipline: cleanText(endpoint.discipline),
    entityType: cleanText(endpoint.entityType || endpoint.ifcType),
  };
}

function buildLanes(ruleSummaries = []) {
  return ruleSummaries.map((summary, laneIndex) => ({
    laneIndex,
    marker: cleanText(summary.marker) || 'G',
    source: endpointFromRule(summary.source),
    target: endpointFromRule(summary.target),
    toleranceMm: summary.toleranceMm || { horizontal: 0, vertical: 0 },
    sourceObjectCount: Number(summary.sourceObjectCount || 0),
    targetObjectCount: Number(summary.targetObjectCount || 0),
    testedPairCount: Number(summary.testedPairCount || 0),
    excludedByTypePolicy: summary.ignoredByTypePolicy === true,
  }));
}

function buildAggregateSets(forest) {
  return [...(forest?.membersByTreeId || new Map()).entries()]
    .map(([treeId, members]) => ({
      treeId: cleanText(treeId),
      memberGlobalIds: [...members].map(cleanText).filter(Boolean).sort(compareText),
    }))
    .filter(entry => entry.treeId && entry.memberGlobalIds.length > 0)
    .sort((left, right) => compareText(left.treeId, right.treeId));
}

function buildModels({ models = [], dataset }) {
  const requestModels = new Map(models.map(model => [
    cleanText(model.modelGuid || model.modelId),
    model,
  ]));
  const statsByModel = new Map((dataset.disciplineStats || []).map(stats => [
    cleanText(stats.modelId),
    stats,
  ]));
  const objectsByModel = new Map();

  for (const object of dataset.objects || []) {
    const modelId = cleanText(object.modelId);
    if (!modelId) continue;
    if (!objectsByModel.has(modelId)) objectsByModel.set(modelId, []);
    objectsByModel.get(modelId).push({
      globalId: cleanText(object.globalId),
      entityType: cleanText(object.entityType || object.ifcType),
      normalizedLevel: normalizeSpatialLevelName(
        object.spatialLevelNormalizedName || object.spatialLevelName,
      ) || null,
      aggregateTreeId: cleanText(object.aggregateTreeId) || null,
    });
  }

  const modelIds = new Set([
    ...requestModels.keys(),
    ...statsByModel.keys(),
    ...objectsByModel.keys(),
  ]);

  return [...modelIds]
    .filter(Boolean)
    .sort(compareText)
    .map(modelId => {
      const requestModel = requestModels.get(modelId) || {};
      const stats = statsByModel.get(modelId) || {};
      const objects = (objectsByModel.get(modelId) || [])
        .filter(object => object.globalId && object.entityType)
        .sort((left, right) => (
          compareText(left.globalId, right.globalId)
          || compareText(left.entityType, right.entityType)
        ));
      return {
        modelId,
        version: cleanText(requestModel.version) || null,
        discipline: cleanText(requestModel.discipline || stats.discipline),
        objectCount: objects.length,
        objects,
        aggregateSets: buildAggregateSets(
          dataset.aggregateForestsByModelId?.get(modelId),
        ),
      };
    });
}

function buildSpatialLevelFilter(filter) {
  if (!filter) return null;
  const names = [...(filter.names || [])].map(cleanText).filter(Boolean);
  return {
    mode: cleanText(filter.mode) || 'anySide',
    names,
    normalizedNames: [
      ...new Set(names.map(normalizeSpatialLevelName).filter(Boolean)),
    ].sort(compareText),
  };
}

const BAD_AGGREGATE_REASONS = new Set([
  'bad-aggregate-geometry',
  'bad-aggregate-geometry-kept',
]);

const BAD_AGGREGATE_EVIDENCE_FIELDS = [
  'geometryId',
  'geometrySourceGlobalId',
  'geometrySourceKind',
  'boundingBoxDiagonalM',
  'connectedComponentCount',
  'componentMedianDiagonalM',
  'componentMaxDiagonalM',
  'componentCenterSpreadDiagonalM',
  'componentCenterLargestExtentM',
  'componentCenterSecondExtentM',
  'componentCenterPrincipalFirstSpreadM',
  'componentCenterPrincipalSecondSpreadM',
  'componentCenterPrincipalSecondToFirstRatio',
  'boundingBoxToMedianComponentRatio',
  'sparseCenterSpreadRatio',
  'componentCenterSpreadToMedianRatio',
  'componentCloudSecondExtentToMedianRatio',
  'componentCloudSecondToLargestExtentRatio',
  'maxComponentToBoundingBoxRatio',
  'badAggregateGeometryPattern',
  'replacementEvidenceMethod',
  'exclusionEvidenceMethod',
  'replacementEvidence',
  'badAggregateGeometryRule',
];

function buildBadAggregateGeometryExceptions(exceptions = []) {
  return exceptions
    .filter(exception => BAD_AGGREGATE_REASONS.has(cleanText(exception?.reason)))
    .map(exception => {
      const evidence = {};
      for (const field of BAD_AGGREGATE_EVIDENCE_FIELDS) {
        if (exception[field] !== undefined) {
          evidence[field] = canonicalize(exception[field]);
        }
      }
      return {
        identity: {
          modelId: cleanText(exception.modelId),
          globalId: cleanText(exception.globalId),
          entityId: cleanText(exception.entityId),
          discipline: cleanText(exception.discipline),
          occurrenceType: cleanText(exception.occurrenceType),
          entityType: cleanText(exception.entityType || exception.ifcType),
        },
        reason: cleanText(exception.reason),
        message: cleanText(exception.message),
        evidence,
      };
    })
    .sort((left, right) => (
      compareText(left.identity.modelId, right.identity.modelId)
      || compareText(left.identity.globalId, right.identity.globalId)
      || compareText(left.identity.entityId, right.identity.entityId)
      || compareText(left.reason, right.reason)
      || compareText(left.message, right.message)
    ));
}

// One detected pair == one grouped-pipeline clash row. The key is the shared
// identity representation across engine, data-process, and backend: versioned
// UTF-8 byte-length-prefixed endpoint tuples in canonical byte order.
// data-process keeps rows where Collision is TRUE and both GlobalIDs are
// present; the caller must apply the same predicate before adding keys.
export function canonicalDetectedPairKey({
  sourceModelId,
  sourceGlobalId,
  targetModelId,
  targetGlobalId,
}) {
  return canonicalPairKey({
    sourceModelId,
    sourceGlobalId,
    targetModelId,
    targetGlobalId,
  });
}

function normalizeDetectedPairs(detectedPairs) {
  const encoding = detectedPairs?.encoding;
  const count = detectedPairs?.count;
  const digest = detectedPairs?.digest;
  if (
    encoding !== PAIR_HASH_ENCODING
    || !Number.isInteger(count)
    || count < 0
    || !/^[a-f0-9]{64}$/.test(String(digest || ''))
  ) {
    throw new Error('detectedPairs evidence with count and digest is required.');
  }
  return { encoding, count, digest };
}

function normalizePairHashManifest(manifest, field) {
  if (
    manifest?.schemaVersion !== PAIR_HASH_MANIFEST_SCHEMA_VERSION
    || manifest?.encoding !== PAIR_HASH_ENCODING
    || !Number.isInteger(manifest?.totalCount)
    || manifest.totalCount < 0
    || !/^[a-f0-9]{64}$/.test(String(manifest?.digest || ''))
    || !Array.isArray(manifest?.chunks)
  ) {
    throw new Error(`${field} pair-hash manifest is invalid.`);
  }
  if (
    manifest.chunks.reduce((total, chunk) => total + Number(chunk?.pairCount || 0), 0)
    !== manifest.totalCount
  ) {
    throw new Error(`${field} pair-hash manifest count is inconsistent.`);
  }
  return manifest;
}

export function buildEvaluatedCoverageArtifact({
  jobId,
  projectId,
  detectionIdentity,
  models,
  dataset,
  broadPhase,
  intentionalExclusions,
  evaluationFailures,
  detectedPairs,
}) {
  if (!dataset || !broadPhase) {
    throw new Error('dataset and broadPhase are required for evaluated coverage.');
  }

  return {
    schemaVersion: EVALUATED_COVERAGE_SCHEMA_VERSION,
    engineSemanticsVersion: ENGINE_SEMANTICS_VERSION,
    jobId: cleanText(jobId),
    projectId: cleanText(projectId || dataset.basePath),
    detectionIdentity: cleanText(detectionIdentity) || null,
    detectedPairs: normalizeDetectedPairs(detectedPairs),
    effectiveOptions: {
      ignoreConnectsPathElements: broadPhase.ignoreConnectsPathElements === true,
      ignoreCoversBldgElements: broadPhase.ignoreCoversBldgElements === true,
      ignoreHostOpeningFill: broadPhase.ignoreHostOpeningFill === true,
      ignorePortConnected: broadPhase.ignorePortConnected === true,
      ignoreSameSystem: broadPhase.ignoreSameSystem === true,
      ignoreSpacesAndOpenings: broadPhase.ignoreSpacesAndOpenings === true,
      useObbRefinement: broadPhase.useObbRefinement === true,
    },
    spatialLevelFilter: buildSpatialLevelFilter(broadPhase.spatialLevelFilter),
    lanes: buildLanes(broadPhase.ruleSummaries),
    intentionalExclusions: normalizePairHashManifest(
      intentionalExclusions,
      'intentionalExclusions',
    ),
    evaluationFailures: normalizePairHashManifest(
      evaluationFailures,
      'evaluationFailures',
    ),
    badAggregateGeometryExceptions: buildBadAggregateGeometryExceptions(
      dataset.exceptions,
    ),
    models: buildModels({ models, dataset }),
  };
}

function canonicalize(value) {
  if (Array.isArray(value)) return value.map(canonicalize);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(
    Object.keys(value)
      .sort(compareText)
      .map(key => [key, canonicalize(value[key])]),
  );
}

export function serializeEvaluatedCoverageArtifact(artifact) {
  const bytes = Buffer.from(`${JSON.stringify(canonicalize(artifact))}\n`, 'utf8');
  return {
    bytes,
    digest: crypto.createHash('sha256').update(bytes).digest('hex'),
    schemaVersion: EVALUATED_COVERAGE_SCHEMA_VERSION,
  };
}
