import path from 'node:path';
import crypto from 'node:crypto';
import { performance } from 'node:perf_hooks';
import { throwIfCanceled } from '../../cancellation.js';
import { createCandidatePair } from '../candidate-pair.js';
import { createProjectDescriptor } from '../project-descriptor.js';
import {
  createObjectSpatialLevelLookup,
  normalizeSpatialLevelName,
} from '../model/spatial-levels.js';
import {
  computeHorizontalObb,
  intersectsHorizontalObb,
} from '../geometry/oriented-box.js';
import {
  createSameSystemFilterCounts,
  decideSameSystemIgnore,
} from './same-system-filter.js';
import {
  createRelationshipObjectKey,
  createSemanticFilterCounts,
  createSortedPairKey,
  decideConnectsPathElementIgnore,
  decideCoversBldgElementIgnore,
  decideHostOpeningFillIgnore,
  decidePortConnectedIgnore,
  normalizeModelLaneId,
} from './semantic-filters.js';
import { NON_CLASHABLE_ENTITY_TYPES } from '../model/ignored-entity-types.js';
import { createAggregateForest } from '../model/aggregate-forest.js';
import { hasDirectGeometryId } from '../model/geometry-eligibility.js';
import { normalizeToleranceMm } from '../tolerance.js';
import { normalizeClashBatchSize } from '../runtime-limits.js';
import { normalizeNestedArray, readParquetObjects } from '../parquet.js';

const SOURCE_UNITS_TO_MM = 1000;
const IFC_SYSTEM_GROUP_TYPES = new Set([
  'IfcSystem',
  'IfcDistributionSystem',
  'IfcBuildingSystem',
]);
const SPACE_AND_OPENING_ENTITY_TYPES = new Set([
  'IfcSpace',
  'IfcOpeningElement',
]);
const SMALL_OBJECT_AGGREGATE_ENTITY_TYPES = new Set([
  'IfcAirTerminal',
  'IfcCableCarrierFitting',
  'IfcDuctFitting',
  'IfcElectricAppliance',
  'IfcFireSuppressionTerminal',
  'IfcFlowInstrument',
  'IfcFlowTerminal',
  'IfcLightFixture',
  'IfcOutlet',
  'IfcPipeFitting',
  'IfcValve',
]);
export const BAD_AGGREGATE_GEOMETRY_RULE = Object.freeze({
  minBoundingBoxDiagonalM: 5,
  minComponentCount: 5,
  minBoundingBoxToMedianComponentRatio: 20,
  minSparseCenterSpreadRatio: 0.5,
  minSparsePrincipalSecondToFirstRatio: 0.15,
  maxComponentToBoundingBoxRatio: 0.35,
  lowComponentCountMax: 4,
  lowComponentCountMinBoundingBoxDiagonalM: 20,
  lowComponentCountMinBoundingBoxToMedianComponentRatio: 50,
  lowComponentCountMaxComponentToBoundingBoxRatio: 0.2,
  minComponentCloudBoundingBoxDiagonalM: 50,
  minComponentCloudComponentCount: 100,
  minComponentCloudBoundingBoxToMedianComponentRatio: 30,
  minComponentCloudCenterSpreadToMedianRatio: 25,
  minComponentCloudSecondExtentToMedianRatio: 8,
  minComponentCloudPrincipalSecondToFirstRatio: 0.12,
  maxComponentCloudMaxComponentToBoundingBoxRatio: 0.36,
  minSmallComponentScatterBoundingBoxDiagonalM: 50,
  minSmallComponentScatterComponentCount: 5,
  minSmallComponentScatterBoundingBoxToMedianComponentRatio: 60,
  minSmallComponentScatterCenterSpreadToMedianRatio: 50,
  minSmallComponentScatterSparseCenterSpreadRatio: 1,
  maxSmallComponentScatterMaxComponentToBoundingBoxRatio: 0.05,
  minLowCountComponentScatterBoundingBoxDiagonalM: 50,
  minLowCountComponentScatterBoundingBoxToMedianComponentRatio: 20,
  minLowCountComponentScatterCenterSpreadToMedianRatio: 20,
  minLowCountComponentScatterSparseCenterSpreadRatio: 1,
  maxLowCountComponentScatterMaxComponentToBoundingBoxRatio: 0.05,
  minTypedSmallObjectBoundingBoxDiagonalM: 15,
  minTypedSmallObjectComponentCloudComponentCount: 100,
  minTypedSmallObjectComponentCloudBoundingBoxToMedianComponentRatio: 30,
  minTypedSmallObjectComponentCloudCenterSpreadToMedianRatio: 25,
  minTypedSmallObjectComponentCloudSecondExtentToMedianRatio: 8,
  minTypedSmallObjectComponentCloudPrincipalSecondToFirstRatio: 0.12,
  maxTypedSmallObjectComponentCloudMaxComponentToBoundingBoxRatio: 0.1,
  minTypedSmallObjectScatterComponentCount: 5,
  minTypedSmallObjectScatterBoundingBoxToMedianComponentRatio: 60,
  minTypedSmallObjectScatterCenterSpreadToMedianRatio: 50,
  minTypedSmallObjectScatterSparseCenterSpreadRatio: 1,
  maxTypedSmallObjectScatterMaxComponentToBoundingBoxRatio: 0.1,
  typedSmallObjectLowCountMax: 4,
  minTypedSmallObjectLowCountBoundingBoxToMedianComponentRatio: 20,
  minTypedSmallObjectLowCountCenterSpreadToMedianRatio: 20,
  minTypedSmallObjectLowCountSparseCenterSpreadRatio: 1,
  maxTypedSmallObjectLowCountMaxComponentToBoundingBoxRatio: 0.1,
  minExtremeSparseGeometryOnlyBoundingBoxDiagonalM: 100,
  minExtremeSparseGeometryOnlyComponentCount: 100,
  minExtremeSparseGeometryOnlyBoundingBoxToMedianComponentRatio: 100,
  minExtremeSparseGeometryOnlySparseCenterSpreadRatio: 1,
  minExtremeSparseGeometryOnlyPrincipalSecondToFirstRatio: 0.15,
  maxExtremeSparseGeometryOnlyMaxComponentToBoundingBoxRatio: 0.02,
  minReplacementHashCoverage: 0.8,
  replacementSpatialToleranceM: 0.2,
});

function elapsedMs(startedAtMs) {
  return Number((performance.now() - startedAtMs).toFixed(3));
}

function roundMs(value) {
  return Number(value.toFixed(3));
}

function normalizeTriples(value, fieldName) {
  const arrayValue = normalizeNestedArray(value, fieldName);
  if (arrayValue.length === 0) {
    return [];
  }

  if (Array.isArray(arrayValue[0])) {
    return arrayValue.map((triple, index) => {
      if (!Array.isArray(triple) || triple.length < 3) {
        throw new Error(`Field "${fieldName}" row ${index} must contain at least three values.`);
      }
      return [
        Number(triple[0]),
        Number(triple[1]),
        Number(triple[2]),
      ];
    });
  }

  if (arrayValue.length % 3 !== 0) {
    throw new Error(`Field "${fieldName}" flat array length must be divisible by 3.`);
  }

  const triples = [];
  for (let index = 0; index < arrayValue.length; index += 3) {
    triples.push([
      Number(arrayValue[index]),
      Number(arrayValue[index + 1]),
      Number(arrayValue[index + 2]),
    ]);
  }
  return triples;
}

function getModelTypeKey(modelGuid, entityType) {
  return `${modelGuid}|${entityType}`;
}

function addMapSetValue(map, key, value) {
  if (!key || !value) {
    return;
  }
  if (!map.has(key)) {
    map.set(key, new Set());
  }
  map.get(key).add(value);
}

function createGeometryLookup(geometryRows) {
  const lookup = new Map();

  for (const row of geometryRows) {
    lookup.set(String(row.geometry_id), row);
  }

  return lookup;
}

function createAggregateChildrenLookup(rows) {
  const lookup = new Map();

  for (const row of rows) {
    if (row.Relationship_Type !== 'IfcRelAggregates') {
      continue;
    }

    const parentGlobalId = String(row.Relating_Object_GUID || '').trim();
    const childGlobalId = String(row.Related_Object_GUID || '').trim();
    if (!parentGlobalId || !childGlobalId) {
      continue;
    }

    if (!lookup.has(parentGlobalId)) {
      lookup.set(parentGlobalId, new Set());
    }
    lookup.get(parentGlobalId).add(childGlobalId);
  }

  return {
    get(parentGlobalId) {
      return [...(lookup.get(String(parentGlobalId)) || [])];
    },
  };
}

function createSystemAssignmentLookup(rows, modelId) {
  const lookup = new Map();
  const systemModelId = normalizeModelLaneId(modelId);

  for (const row of rows) {
    if (row.Relationship_Type !== 'IfcRelAssignsToGroup') {
      continue;
    }

    const systemEntityType = String(row.Relating_Object_Type || '').trim();
    if (!IFC_SYSTEM_GROUP_TYPES.has(systemEntityType)) {
      continue;
    }

    const systemGlobalId = String(row.Relating_Object_GUID || '').trim();
    const objectGlobalId = String(row.Related_Object_GUID || '').trim();
    if (!systemGlobalId || !objectGlobalId) {
      continue;
    }

    if (!lookup.has(objectGlobalId)) {
      lookup.set(objectGlobalId, new Set());
    }
    lookup.get(objectGlobalId).add(`${systemModelId}::${systemGlobalId}`);
  }

  return {
    get(objectGlobalId) {
      return [...(lookup.get(String(objectGlobalId)) || [])];
    },
  };
}

function createCoveredElementByCoveringLookup(rows) {
  const lookup = new Map();

  for (const row of rows) {
    if (row.Relationship_Type !== 'IfcRelCoversBldgElements') {
      continue;
    }

    const coveredElementGlobalId = String(row.Relating_Object_GUID || '').trim();
    const coveringGlobalId = String(row.Related_Object_GUID || '').trim();
    if (!coveredElementGlobalId || !coveringGlobalId) {
      continue;
    }

    if (!lookup.has(coveringGlobalId)) {
      lookup.set(coveringGlobalId, new Set());
    }
    lookup.get(coveringGlobalId).add(coveredElementGlobalId);
  }

  return {
    get(coveringGlobalId) {
      return [...(lookup.get(String(coveringGlobalId)) || [])];
    },
  };
}

function createCoversBldgElementPairSet(rows, modelId) {
  const pairs = new Set();
  const normalizedModelId = normalizeModelLaneId(modelId);

  for (const row of rows) {
    if (row.Relationship_Type !== 'IfcRelCoversBldgElements') {
      continue;
    }

    const coveredElementKey = createRelationshipObjectKey(normalizedModelId, row.Relating_Object_GUID);
    const coveringKey = createRelationshipObjectKey(normalizedModelId, row.Related_Object_GUID);
    if (coveredElementKey && coveringKey) {
      pairs.add(createSortedPairKey(coveredElementKey, coveringKey));
    }
  }

  return pairs;
}

function createConnectsPathElementPairSet(rows, modelId) {
  const pairs = new Set();
  const normalizedModelId = normalizeModelLaneId(modelId);

  for (const row of rows) {
    if (row.Relationship_Type !== 'IfcRelConnectsPathElements') {
      continue;
    }

    const relatingKey = createRelationshipObjectKey(normalizedModelId, row.Relating_Object_GUID);
    const relatedKey = createRelationshipObjectKey(normalizedModelId, row.Related_Object_GUID);
    if (relatingKey && relatedKey) {
      pairs.add(createSortedPairKey(relatingKey, relatedKey));
    }
  }

  return pairs;
}

// Suppress an opening-filler (door/window) against its host element AND every
// transitive IfcRelAggregates child-part of that host. The host fills an opening
// that voids the host; the part is a component the host is aggregated from, so a
// door/window vs. its host wall's layers/parts is never a real clash.
//
//   filler --IfcRelFillsElement--> opening <--IfcRelVoidsElement-- host
//                                                                   |
//                                              IfcRelAggregates (transitive)
//                                                                   v
//                                                            part, part-of-part, ...
//
// KEY-SPACE BRIDGE: createAggregateChildrenLookup is keyed by RAW globalId, but
// the emitted pair keys are modelId-prefixed (createRelationshipObjectKey). The
// traversal therefore runs in raw-guid space (from row.Relating_Object_GUID) and
// only folds into prefixed keys at emit time. Mixing the two yields zero expansion.
//
// KNOWN LIMITATION (v2): every transitive aggregate descendant of the host is
// suppressed, not only its geometry-source material layers. If a host aggregated an
// unrelated attachment, a real filler-vs-child clash could be hidden. Empirically
// safe (Rule 1 killed 1 TP across 6 GT projects); v2 could restrict to geometry-
// source children if a future project shows damage.
// aggregateChildren defaults to a freshly built lookup so the function stays
// self-contained for unit tests; the per-discipline caller passes the lookup it
// already built (buildDisciplineObjects) to avoid a redundant rows scan.
export function createHostOpeningFillPairSet(
  rows,
  modelId,
  aggregateChildren = createAggregateChildrenLookup(rows),
) {
  const openingsByHost = new Map();
  const fillsByOpening = new Map();
  const rawHostGuidByHostKey = new Map();
  const normalizedModelId = normalizeModelLaneId(modelId);

  for (const row of rows) {
    const relatingKey = createRelationshipObjectKey(normalizedModelId, row.Relating_Object_GUID);
    const relatedKey = createRelationshipObjectKey(normalizedModelId, row.Related_Object_GUID);

    if (row.Relationship_Type === 'IfcRelVoidsElement') {
      addMapSetValue(openingsByHost, relatingKey, relatedKey);
      if (relatingKey) {
        rawHostGuidByHostKey.set(relatingKey, String(row.Relating_Object_GUID || '').trim());
      }
    } else if (row.Relationship_Type === 'IfcRelFillsElement') {
      addMapSetValue(fillsByOpening, relatingKey, relatedKey);
    }
  }

  // host (prefixed key) -> [host key, ...descendant part keys]. Walks raw guids
  // with a visited set (cycle guard, mirrors loadObjectRecordsFromFolder), folding
  // each raw descendant into a modelId-prefixed key for emit.
  function collectHostAndDescendantKeys(hostKey) {
    const keys = [hostKey];
    const rawHostGuid = rawHostGuidByHostKey.get(hostKey);
    if (!rawHostGuid) {
      return keys;
    }

    const visited = new Set([rawHostGuid]);
    const queue = [rawHostGuid];
    for (let queueIndex = 0; queueIndex < queue.length; queueIndex += 1) {
      const parentGuid = queue[queueIndex];
      for (const childGuid of aggregateChildren.get(parentGuid)) {
        if (visited.has(childGuid)) {
          continue;
        }
        visited.add(childGuid);
        queue.push(childGuid);
        const childKey = createRelationshipObjectKey(normalizedModelId, childGuid);
        if (childKey) {
          keys.push(childKey);
        }
      }
    }

    return keys;
  }

  const hostFillPairs = new Set();
  for (const [hostKey, openingKeys] of openingsByHost) {
    const elementKeys = collectHostAndDescendantKeys(hostKey);
    for (const openingKey of openingKeys) {
      for (const fillKey of fillsByOpening.get(openingKey) || []) {
        for (const elementKey of elementKeys) {
          hostFillPairs.add(createSortedPairKey(elementKey, fillKey));
        }
      }
    }
  }

  return hostFillPairs;
}

function isPortType(objectType) {
  return String(objectType || '').includes('Port');
}

function createPortConnectedElementPairSet(rows, modelId) {
  // Resolve each distribution port to the element that owns it. IfcRelNests stores
  // element -> ports (related is the port); the deprecated IfcRelConnectsPortToElement
  // stores port -> element (relating is the port).
  const elementByPort = new Map();
  for (const row of rows) {
    if (row.Relationship_Type === 'IfcRelNests' && isPortType(row.Related_Object_Type)) {
      const portGlobalId = String(row.Related_Object_GUID || '').trim();
      const elementGlobalId = String(row.Relating_Object_GUID || '').trim();
      if (portGlobalId && elementGlobalId) {
        elementByPort.set(portGlobalId, elementGlobalId);
      }
    } else if (row.Relationship_Type === 'IfcRelConnectsPortToElement' && isPortType(row.Relating_Object_Type)) {
      const portGlobalId = String(row.Relating_Object_GUID || '').trim();
      const elementGlobalId = String(row.Related_Object_GUID || '').trim();
      if (portGlobalId && elementGlobalId) {
        elementByPort.set(portGlobalId, elementGlobalId);
      }
    }
  }

  const normalizedModelId = normalizeModelLaneId(modelId);
  const pairs = new Set();
  for (const row of rows) {
    if (row.Relationship_Type !== 'IfcRelConnectsPorts') {
      continue;
    }

    const elementA = elementByPort.get(String(row.Relating_Object_GUID || '').trim());
    const elementB = elementByPort.get(String(row.Related_Object_GUID || '').trim());
    if (!elementA || !elementB || elementA === elementB) {
      continue;
    }

    const keyA = createRelationshipObjectKey(normalizedModelId, elementA);
    const keyB = createRelationshipObjectKey(normalizedModelId, elementB);
    if (keyA && keyB) {
      pairs.add(createSortedPairKey(keyA, keyB));
    }
  }

  return pairs;
}

function getLocalBoundingBox(vertices) {
  let minX = Infinity;
  let minY = Infinity;
  let minZ = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  let maxZ = -Infinity;

  if (vertices.length > 0 && Array.isArray(vertices[0])) {
    for (const vertex of vertices) {
      const [x, y, z] = vertex;
      minX = Math.min(minX, x);
      minY = Math.min(minY, y);
      minZ = Math.min(minZ, z);
      maxX = Math.max(maxX, x);
      maxY = Math.max(maxY, y);
      maxZ = Math.max(maxZ, z);
    }
  } else {
    for (let index = 0; index < vertices.length; index += 3) {
      const x = vertices[index];
      const y = vertices[index + 1];
      const z = vertices[index + 2];
      minX = Math.min(minX, x);
      minY = Math.min(minY, y);
      minZ = Math.min(minZ, z);
      maxX = Math.max(maxX, x);
      maxY = Math.max(maxY, y);
      maxZ = Math.max(maxZ, z);
    }
  }

  if (![minX, minY, minZ, maxX, maxY, maxZ].every(Number.isFinite)) {
    throw new Error('Geometry vertices did not produce a finite bounding box.');
  }

  return { minX, minY, minZ, maxX, maxY, maxZ };
}

function getBoundingBoxDiagonal(box) {
  const dx = box.maxX - box.minX;
  const dy = box.maxY - box.minY;
  const dz = box.maxZ - box.minZ;
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

function median(values) {
  if (values.length === 0) {
    return 0;
  }
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  if (sorted.length % 2 === 1) {
    return sorted[middle];
  }
  return (sorted[middle - 1] + sorted[middle]) / 2;
}

function getSymmetricEigenvalues3x3(matrix) {
  const a = matrix.map(row => row.slice());
  for (let iteration = 0; iteration < 24; iteration += 1) {
    let p = 0;
    let q = 1;
    let maxOffDiagonal = Math.abs(a[0][1]);
    const candidates = [
      [0, 2],
      [1, 2],
    ];
    for (const [i, j] of candidates) {
      const value = Math.abs(a[i][j]);
      if (value > maxOffDiagonal) {
        maxOffDiagonal = value;
        p = i;
        q = j;
      }
    }
    if (maxOffDiagonal < 1e-12) {
      break;
    }

    const app = a[p][p];
    const aqq = a[q][q];
    const apq = a[p][q];
    const tau = (aqq - app) / (2 * apq);
    const t = Math.sign(tau || 1) / (Math.abs(tau) + Math.sqrt(1 + tau * tau));
    const c = 1 / Math.sqrt(1 + t * t);
    const s = t * c;

    a[p][p] = app - t * apq;
    a[q][q] = aqq + t * apq;
    a[p][q] = 0;
    a[q][p] = 0;

    for (let r = 0; r < 3; r += 1) {
      if (r === p || r === q) {
        continue;
      }
      const arp = a[r][p];
      const arq = a[r][q];
      a[r][p] = c * arp - s * arq;
      a[p][r] = a[r][p];
      a[r][q] = s * arp + c * arq;
      a[q][r] = a[r][q];
    }
  }

  return [a[0][0], a[1][1], a[2][2]]
    .map(value => Math.max(0, value))
    .sort((left, right) => right - left);
}

function computePrincipalSpreadRatios(points) {
  if (points.length <= 1) {
    return {
      principalFirstSpreadM: 0,
      principalSecondSpreadM: 0,
      principalThirdSpreadM: 0,
      principalSecondToFirstRatio: 0,
      principalThirdToFirstRatio: 0,
    };
  }

  const mean = [0, 0, 0];
  for (const point of points) {
    mean[0] += point[0] / points.length;
    mean[1] += point[1] / points.length;
    mean[2] += point[2] / points.length;
  }

  const covariance = [
    [0, 0, 0],
    [0, 0, 0],
    [0, 0, 0],
  ];
  for (const point of points) {
    const delta = [
      point[0] - mean[0],
      point[1] - mean[1],
      point[2] - mean[2],
    ];
    for (let row = 0; row < 3; row += 1) {
      for (let column = 0; column < 3; column += 1) {
        covariance[row][column] += (delta[row] * delta[column]) / points.length;
      }
    }
  }

  const eigenvalues = getSymmetricEigenvalues3x3(covariance);
  const principalFirstSpreadM = Math.sqrt(eigenvalues[0] ?? 0);
  const principalSecondSpreadM = Math.sqrt(eigenvalues[1] ?? 0);
  const principalThirdSpreadM = Math.sqrt(eigenvalues[2] ?? 0);
  return {
    principalFirstSpreadM,
    principalSecondSpreadM,
    principalThirdSpreadM,
    principalSecondToFirstRatio: principalFirstSpreadM > 0
      ? principalSecondSpreadM / principalFirstSpreadM
      : 0,
    principalThirdToFirstRatio: principalFirstSpreadM > 0
      ? principalThirdSpreadM / principalFirstSpreadM
      : 0,
  };
}

function createComponentHash(vertexCoords, box) {
  const dx = box.maxX - box.minX;
  const dy = box.maxY - box.minY;
  const dz = box.maxZ - box.minZ;
  const quantizedVertices = vertexCoords
    .map(([x, y, z]) => [
      Math.round((x - box.minX) * SOURCE_UNITS_TO_MM),
      Math.round((y - box.minY) * SOURCE_UNITS_TO_MM),
      Math.round((z - box.minZ) * SOURCE_UNITS_TO_MM),
    ].join(':'))
    .sort();
  const signature = [
    vertexCoords.length,
    Math.round(dx * SOURCE_UNITS_TO_MM),
    Math.round(dy * SOURCE_UNITS_TO_MM),
    Math.round(dz * SOURCE_UNITS_TO_MM),
    ...quantizedVertices,
  ].join('|');

  return crypto.createHash('sha1').update(signature).digest('hex').slice(0, 16);
}

export function computeMeshComponents(vertices, faces) {
  const normalizedVertices = normalizeTriples(vertices, 'vertices');
  const normalizedFaces = normalizeTriples(faces, 'faces');
  const vertexCount = normalizedVertices.length;

  if (vertexCount === 0 || normalizedFaces.length === 0) {
    const componentBox = vertexCount > 0
      ? getLocalBoundingBox(normalizedVertices)
      : null;
    return {
      components: componentBox
        ? [{
          localBox: componentBox,
          localDiagonalM: getBoundingBoxDiagonal(componentBox),
          vertexCount,
          hash: createComponentHash(normalizedVertices, componentBox),
        }]
        : [],
      invalidFaceCount: 0,
    };
  }

  const parents = Array.from({ length: vertexCount }, (_, index) => index);
  const ranks = Array.from({ length: vertexCount }, () => 0);
  const find = (value) => {
    let current = value;
    while (parents[current] !== current) {
      parents[current] = parents[parents[current]];
      current = parents[current];
    }
    return current;
  };
  const union = (a, b) => {
    const rootA = find(a);
    const rootB = find(b);
    if (rootA === rootB) {
      return;
    }
    if (ranks[rootA] < ranks[rootB]) {
      parents[rootA] = rootB;
    } else if (ranks[rootA] > ranks[rootB]) {
      parents[rootB] = rootA;
    } else {
      parents[rootB] = rootA;
      ranks[rootA] += 1;
    }
  };

  let invalidFaceCount = 0;
  for (const [rawA, rawB, rawC] of normalizedFaces) {
    const a = Number(rawA);
    const b = Number(rawB);
    const c = Number(rawC);
    if (
      !Number.isInteger(a)
      || !Number.isInteger(b)
      || !Number.isInteger(c)
      || a < 0
      || b < 0
      || c < 0
      || a >= vertexCount
      || b >= vertexCount
      || c >= vertexCount
    ) {
      invalidFaceCount += 1;
      continue;
    }
    union(a, b);
    union(b, c);
    union(c, a);
  }

  const components = new Map();
  for (let index = 0; index < vertexCount; index += 1) {
    const root = find(index);
    if (!components.has(root)) {
      components.set(root, []);
    }
    components.get(root).push(index);
  }

  const componentsList = [];
  for (const indices of components.values()) {
    let minX = Infinity;
    let minY = Infinity;
    let minZ = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    let maxZ = -Infinity;
    for (const index of indices) {
      const [x, y, z] = normalizedVertices[index];
      minX = Math.min(minX, x);
      minY = Math.min(minY, y);
      minZ = Math.min(minZ, z);
      maxX = Math.max(maxX, x);
      maxY = Math.max(maxY, y);
      maxZ = Math.max(maxZ, z);
    }
    const componentBox = { minX, minY, minZ, maxX, maxY, maxZ };
    const vertexCoords = indices.map(index => normalizedVertices[index]);
    componentsList.push({
      localBox: componentBox,
      localDiagonalM: getBoundingBoxDiagonal(componentBox),
      vertexCount: indices.length,
      hash: createComponentHash(vertexCoords, componentBox),
    });
  }

  return {
    components: componentsList,
    invalidFaceCount,
  };
}

function computeComponentStatsFromComponents(components, invalidFaceCount) {
  if (components.length === 0) {
    return {
      componentCount: 0,
      componentMedianDiagonalM: 0,
      componentMaxDiagonalM: 0,
      componentCenterSpreadDiagonalM: 0,
      componentCenterLargestExtentM: 0,
      componentCenterSecondExtentM: 0,
      componentCenterPrincipalFirstSpreadM: 0,
      componentCenterPrincipalSecondSpreadM: 0,
      componentCenterPrincipalSecondToFirstRatio: 0,
      sparseCenterSpreadRatio: 0,
      invalidFaceCount,
    };
  }

  const componentDiagonals = components.map(component => component.localDiagonalM);
  const componentCenterBox = createEmptyBoundingBox();
  const componentCenters = [];
  for (const component of components) {
    const { minX, minY, minZ, maxX, maxY, maxZ } = component.localBox;
    const centerX = (minX + maxX) / 2;
    const centerY = (minY + maxY) / 2;
    const centerZ = (minZ + maxZ) / 2;
    componentCenters.push([centerX, centerY, centerZ]);
    expandBoundingBox(componentCenterBox, {
      minX: centerX,
      minY: centerY,
      minZ: centerZ,
      maxX: centerX,
      maxY: centerY,
      maxZ: centerZ,
    });
  }

  const componentMedianDiagonalM = median(componentDiagonals);
  const componentCenterSpreadDiagonalM = components.length > 1
    ? getBoundingBoxDiagonal(componentCenterBox)
    : 0;
  const centerExtents = [
    componentCenterBox.maxX - componentCenterBox.minX,
    componentCenterBox.maxY - componentCenterBox.minY,
    componentCenterBox.maxZ - componentCenterBox.minZ,
  ].sort((a, b) => b - a);
  const principalSpread = computePrincipalSpreadRatios(componentCenters);
  const sparseCenterSpreadRatio = componentMedianDiagonalM > 0
    ? componentCenterSpreadDiagonalM / (components.length * componentMedianDiagonalM)
    : Number.POSITIVE_INFINITY;

  return {
    componentCount: components.length,
    componentMedianDiagonalM,
    componentMaxDiagonalM: Math.max(...componentDiagonals),
    componentCenterSpreadDiagonalM,
    componentCenterLargestExtentM: centerExtents[0] ?? 0,
    componentCenterSecondExtentM: centerExtents[1] ?? 0,
    componentCenterPrincipalFirstSpreadM: principalSpread.principalFirstSpreadM,
    componentCenterPrincipalSecondSpreadM: principalSpread.principalSecondSpreadM,
    componentCenterPrincipalThirdSpreadM: principalSpread.principalThirdSpreadM,
    componentCenterPrincipalSecondToFirstRatio: principalSpread.principalSecondToFirstRatio,
    componentCenterPrincipalThirdToFirstRatio: principalSpread.principalThirdToFirstRatio,
    sparseCenterSpreadRatio,
    invalidFaceCount,
  };
}

export function computeMeshComponentStats(vertices, faces) {
  const { components, invalidFaceCount } = computeMeshComponents(vertices, faces);
  return computeComponentStatsFromComponents(components, invalidFaceCount);
}

function matchesComponentCloud(stats, profile) {
  return (
    stats.boundingBoxDiagonalM >= profile.minBoundingBoxDiagonalM
    && stats.componentCount >= profile.minComponentCount
    && stats.boundingBoxToMedianComponentRatio >= profile.minBoundingBoxToMedianComponentRatio
    && stats.componentCenterSpreadToMedianRatio >= profile.minCenterSpreadToMedianRatio
    && stats.componentCloudSecondExtentToMedianRatio >= profile.minSecondExtentToMedianRatio
    && stats.componentCenterPrincipalSecondToFirstRatio >= profile.minPrincipalSecondToFirstRatio
    && stats.maxComponentToBoundingBoxRatio <= profile.maxComponentToBoundingBoxRatio
  );
}

function matchesComponentScatter(stats, profile) {
  return (
    stats.boundingBoxDiagonalM >= profile.minBoundingBoxDiagonalM
    && stats.componentCount >= profile.minComponentCount
    && stats.boundingBoxToMedianComponentRatio >= profile.minBoundingBoxToMedianComponentRatio
    && stats.componentCenterSpreadToMedianRatio >= profile.minCenterSpreadToMedianRatio
    && stats.sparseCenterSpreadRatio >= profile.minSparseCenterSpreadRatio
    && stats.maxComponentToBoundingBoxRatio <= profile.maxComponentToBoundingBoxRatio
  );
}

function matchesLowCountScatter(stats, profile) {
  return (
    stats.boundingBoxDiagonalM >= profile.minBoundingBoxDiagonalM
    && stats.componentCount >= 2
    && stats.componentCount <= profile.maxComponentCount
    && stats.boundingBoxToMedianComponentRatio >= profile.minBoundingBoxToMedianComponentRatio
    && stats.componentCenterSpreadToMedianRatio >= profile.minCenterSpreadToMedianRatio
    && stats.sparseCenterSpreadRatio >= profile.minSparseCenterSpreadRatio
    && stats.maxComponentToBoundingBoxRatio <= profile.maxComponentToBoundingBoxRatio
  );
}

export function classifyBadAggregateGeometry(geometryQuality, rule = BAD_AGGREGATE_GEOMETRY_RULE) {
  const entityType = String(geometryQuality?.entityType || geometryQuality?.ifcType || '').trim();
  const isSmallObjectAggregateType = SMALL_OBJECT_AGGREGATE_ENTITY_TYPES.has(entityType);
  const boundingBoxDiagonalM = Number(geometryQuality?.boundingBoxDiagonalM ?? 0);
  const componentCount = Number(geometryQuality?.componentCount ?? 0);
  const componentMedianDiagonalM = Number(geometryQuality?.componentMedianDiagonalM ?? 0);
  const componentMaxDiagonalM = Number(geometryQuality?.componentMaxDiagonalM ?? 0);
  const componentCenterSpreadDiagonalM = Number(geometryQuality?.componentCenterSpreadDiagonalM ?? 0);
  const componentCenterLargestExtentM = Number(geometryQuality?.componentCenterLargestExtentM ?? 0);
  const componentCenterSecondExtentM = Number(geometryQuality?.componentCenterSecondExtentM ?? 0);
  const componentCenterPrincipalFirstSpreadM = Number(geometryQuality?.componentCenterPrincipalFirstSpreadM ?? 0);
  const componentCenterPrincipalSecondSpreadM = Number(geometryQuality?.componentCenterPrincipalSecondSpreadM ?? 0);
  const componentCenterPrincipalSecondToFirstRatio = Number(
    geometryQuality?.componentCenterPrincipalSecondToFirstRatio ?? 0,
  );
  const sparseCenterSpreadRatio = Number(geometryQuality?.sparseCenterSpreadRatio ?? 0);
  const boundingBoxToMedianComponentRatio = componentMedianDiagonalM > 0
    ? boundingBoxDiagonalM / componentMedianDiagonalM
    : Number.POSITIVE_INFINITY;
  const componentCenterSpreadToMedianRatio = componentMedianDiagonalM > 0
    ? componentCenterSpreadDiagonalM / componentMedianDiagonalM
    : Number.POSITIVE_INFINITY;
  const maxComponentToBoundingBoxRatio = boundingBoxDiagonalM > 0
    ? componentMaxDiagonalM / boundingBoxDiagonalM
    : Number.POSITIVE_INFINITY;
  const componentCloudSecondExtentToMedianRatio = componentMedianDiagonalM > 0
    ? componentCenterSecondExtentM / componentMedianDiagonalM
    : Number.POSITIVE_INFINITY;
  const componentCloudSecondToLargestExtentRatio = componentCenterLargestExtentM > 0
    ? componentCenterSecondExtentM / componentCenterLargestExtentM
    : 0;
  const stats = {
    boundingBoxDiagonalM,
    componentCount,
    boundingBoxToMedianComponentRatio,
    componentCenterSpreadToMedianRatio,
    componentCloudSecondExtentToMedianRatio,
    componentCenterPrincipalSecondToFirstRatio,
    sparseCenterSpreadRatio,
    maxComponentToBoundingBoxRatio,
  };
  const patterns = [
    {
      name: 'sparse-components',
      matches: () => (
        boundingBoxDiagonalM >= rule.minBoundingBoxDiagonalM
        && componentCount >= rule.minComponentCount
        && boundingBoxToMedianComponentRatio >= rule.minBoundingBoxToMedianComponentRatio
        && sparseCenterSpreadRatio >= rule.minSparseCenterSpreadRatio
        && componentCenterPrincipalSecondToFirstRatio >= rule.minSparsePrincipalSecondToFirstRatio
        && maxComponentToBoundingBoxRatio <= rule.maxComponentToBoundingBoxRatio
      ),
    },
    {
      name: 'low-component-extreme',
      matches: () => (
        boundingBoxDiagonalM >= rule.lowComponentCountMinBoundingBoxDiagonalM
        && componentCount >= 2
        && componentCount <= rule.lowComponentCountMax
        && boundingBoxToMedianComponentRatio >= rule.lowComponentCountMinBoundingBoxToMedianComponentRatio
        && sparseCenterSpreadRatio >= rule.minSparseCenterSpreadRatio
        && maxComponentToBoundingBoxRatio <= rule.lowComponentCountMaxComponentToBoundingBoxRatio
      ),
    },
    {
      name: 'component-cloud',
      matches: () => matchesComponentCloud(stats, {
        minBoundingBoxDiagonalM: rule.minComponentCloudBoundingBoxDiagonalM,
        minComponentCount: rule.minComponentCloudComponentCount,
        minBoundingBoxToMedianComponentRatio: rule.minComponentCloudBoundingBoxToMedianComponentRatio,
        minCenterSpreadToMedianRatio: rule.minComponentCloudCenterSpreadToMedianRatio,
        minSecondExtentToMedianRatio: rule.minComponentCloudSecondExtentToMedianRatio,
        minPrincipalSecondToFirstRatio: rule.minComponentCloudPrincipalSecondToFirstRatio,
        maxComponentToBoundingBoxRatio: rule.maxComponentCloudMaxComponentToBoundingBoxRatio,
      }),
    },
    {
      name: 'small-component-scatter',
      matches: () => matchesComponentScatter(stats, {
        minBoundingBoxDiagonalM: rule.minSmallComponentScatterBoundingBoxDiagonalM,
        minComponentCount: rule.minSmallComponentScatterComponentCount,
        minBoundingBoxToMedianComponentRatio: rule.minSmallComponentScatterBoundingBoxToMedianComponentRatio,
        minCenterSpreadToMedianRatio: rule.minSmallComponentScatterCenterSpreadToMedianRatio,
        minSparseCenterSpreadRatio: rule.minSmallComponentScatterSparseCenterSpreadRatio,
        maxComponentToBoundingBoxRatio: rule.maxSmallComponentScatterMaxComponentToBoundingBoxRatio,
      }),
    },
    {
      name: 'low-count-component-scatter',
      matches: () => matchesLowCountScatter(stats, {
        minBoundingBoxDiagonalM: rule.minLowCountComponentScatterBoundingBoxDiagonalM,
        maxComponentCount: rule.lowComponentCountMax,
        minBoundingBoxToMedianComponentRatio: rule.minLowCountComponentScatterBoundingBoxToMedianComponentRatio,
        minCenterSpreadToMedianRatio: rule.minLowCountComponentScatterCenterSpreadToMedianRatio,
        minSparseCenterSpreadRatio: rule.minLowCountComponentScatterSparseCenterSpreadRatio,
        maxComponentToBoundingBoxRatio: rule.maxLowCountComponentScatterMaxComponentToBoundingBoxRatio,
      }),
    },
    {
      name: 'typed-small-object-component-cloud',
      applies: isSmallObjectAggregateType,
      matches: () => matchesComponentCloud(stats, {
        minBoundingBoxDiagonalM: rule.minTypedSmallObjectBoundingBoxDiagonalM,
        minComponentCount: rule.minTypedSmallObjectComponentCloudComponentCount,
        minBoundingBoxToMedianComponentRatio: rule.minTypedSmallObjectComponentCloudBoundingBoxToMedianComponentRatio,
        minCenterSpreadToMedianRatio: rule.minTypedSmallObjectComponentCloudCenterSpreadToMedianRatio,
        minSecondExtentToMedianRatio: rule.minTypedSmallObjectComponentCloudSecondExtentToMedianRatio,
        minPrincipalSecondToFirstRatio: rule.minTypedSmallObjectComponentCloudPrincipalSecondToFirstRatio,
        maxComponentToBoundingBoxRatio: rule.maxTypedSmallObjectComponentCloudMaxComponentToBoundingBoxRatio,
      }),
    },
    {
      name: 'typed-small-object-scatter',
      applies: isSmallObjectAggregateType,
      matches: () => matchesComponentScatter(stats, {
        minBoundingBoxDiagonalM: rule.minTypedSmallObjectBoundingBoxDiagonalM,
        minComponentCount: rule.minTypedSmallObjectScatterComponentCount,
        minBoundingBoxToMedianComponentRatio: rule.minTypedSmallObjectScatterBoundingBoxToMedianComponentRatio,
        minCenterSpreadToMedianRatio: rule.minTypedSmallObjectScatterCenterSpreadToMedianRatio,
        minSparseCenterSpreadRatio: rule.minTypedSmallObjectScatterSparseCenterSpreadRatio,
        maxComponentToBoundingBoxRatio: rule.maxTypedSmallObjectScatterMaxComponentToBoundingBoxRatio,
      }),
    },
    {
      name: 'typed-small-object-low-count-scatter',
      applies: isSmallObjectAggregateType,
      matches: () => matchesLowCountScatter(stats, {
        minBoundingBoxDiagonalM: rule.minTypedSmallObjectBoundingBoxDiagonalM,
        maxComponentCount: rule.typedSmallObjectLowCountMax,
        minBoundingBoxToMedianComponentRatio: rule.minTypedSmallObjectLowCountBoundingBoxToMedianComponentRatio,
        minCenterSpreadToMedianRatio: rule.minTypedSmallObjectLowCountCenterSpreadToMedianRatio,
        minSparseCenterSpreadRatio: rule.minTypedSmallObjectLowCountSparseCenterSpreadRatio,
        maxComponentToBoundingBoxRatio: rule.maxTypedSmallObjectLowCountMaxComponentToBoundingBoxRatio,
      }),
    },
  ];
  const matchedPattern = patterns.find(pattern => (
    pattern.applies !== false && pattern.matches()
  ))?.name || 'none';

  return {
    isBadAggregateGeometry: matchedPattern !== 'none',
    badAggregateGeometryPattern: matchedPattern,
    entityType,
    boundingBoxDiagonalM,
    componentCount,
    componentMedianDiagonalM,
    componentMaxDiagonalM,
    componentCenterSpreadDiagonalM,
    componentCenterLargestExtentM,
    componentCenterSecondExtentM,
    componentCenterPrincipalFirstSpreadM,
    componentCenterPrincipalSecondSpreadM,
    componentCenterPrincipalSecondToFirstRatio,
    sparseCenterSpreadRatio,
    componentCenterSpreadToMedianRatio,
    componentCloudSecondExtentToMedianRatio,
    componentCloudSecondToLargestExtentRatio,
    maxComponentToBoundingBoxRatio,
    invalidFaceCount: Number(geometryQuality?.invalidFaceCount ?? 0),
    boundingBoxToMedianComponentRatio,
    rule,
  };
}

function matchesExtremeSparseGeometryOnly(analysis, rule) {
  return (
    analysis.boundingBoxDiagonalM >= rule.minExtremeSparseGeometryOnlyBoundingBoxDiagonalM
    && analysis.componentCount >= rule.minExtremeSparseGeometryOnlyComponentCount
    && analysis.boundingBoxToMedianComponentRatio >= rule.minExtremeSparseGeometryOnlyBoundingBoxToMedianComponentRatio
    && analysis.sparseCenterSpreadRatio >= rule.minExtremeSparseGeometryOnlySparseCenterSpreadRatio
    && analysis.componentCenterPrincipalSecondToFirstRatio >= rule.minExtremeSparseGeometryOnlyPrincipalSecondToFirstRatio
    && analysis.maxComponentToBoundingBoxRatio <= rule.maxExtremeSparseGeometryOnlyMaxComponentToBoundingBoxRatio
  );
}

export function isGeometryOnlyBadAggregate(analysis, rule = BAD_AGGREGATE_GEOMETRY_RULE) {
  if (Number(analysis?.invalidFaceCount ?? 0) > 0) {
    return false;
  }

  switch (analysis?.badAggregateGeometryPattern) {
    case 'component-cloud':
    case 'small-component-scatter':
      return true;
    case 'sparse-components':
      return matchesExtremeSparseGeometryOnly(analysis, rule);
    default:
      return false;
  }
}

function analyzeGeometryForBadAggregate(vertices, faces, localBox, options = {}) {
  const boundingBoxDiagonalM = getBoundingBoxDiagonal(localBox);
  if (
    boundingBoxDiagonalM < BAD_AGGREGATE_GEOMETRY_RULE.minBoundingBoxDiagonalM
    && !options.requireComponents
  ) {
    return {
      ...classifyBadAggregateGeometry({
        boundingBoxDiagonalM,
        componentCount: 0,
        componentMedianDiagonalM: 0,
        componentMaxDiagonalM: 0,
        componentCenterSpreadDiagonalM: 0,
        componentCenterLargestExtentM: 0,
        componentCenterSecondExtentM: 0,
        componentCenterPrincipalFirstSpreadM: 0,
        componentCenterPrincipalSecondSpreadM: 0,
        componentCenterPrincipalSecondToFirstRatio: 0,
        sparseCenterSpreadRatio: 0,
        invalidFaceCount: 0,
      }),
      components: [],
      componentsComputed: false,
    };
  }

  const componentAnalysis = computeMeshComponents(vertices, faces);
  return {
    ...classifyBadAggregateGeometry({
      boundingBoxDiagonalM,
      ...computeComponentStatsFromComponents(componentAnalysis.components, componentAnalysis.invalidFaceCount),
    }),
    components: componentAnalysis.components,
    componentsComputed: true,
  };
}

function classifyCachedGeometryForEntityType(cachedBadAggregateGeometry, entityType) {
  return {
    ...cachedBadAggregateGeometry,
    ...classifyBadAggregateGeometry({
      ...cachedBadAggregateGeometry,
      entityType,
    }),
    components: cachedBadAggregateGeometry.components,
    componentsComputed: cachedBadAggregateGeometry.componentsComputed,
  };
}

function formatMeters(value) {
  return Number(value).toFixed(3);
}

function transformPoint(transform, x, y, z) {
  return {
    x: transform[0] * x + transform[1] * y + transform[2] * z + transform[3],
    y: transform[4] * x + transform[5] * y + transform[6] * z + transform[7],
    z: transform[8] * x + transform[9] * y + transform[10] * z + transform[11],
  };
}

function getBoundingBoxCorners(localBox) {
  return [
    [localBox.minX, localBox.minY, localBox.minZ],
    [localBox.minX, localBox.minY, localBox.maxZ],
    [localBox.minX, localBox.maxY, localBox.minZ],
    [localBox.minX, localBox.maxY, localBox.maxZ],
    [localBox.maxX, localBox.minY, localBox.minZ],
    [localBox.maxX, localBox.minY, localBox.maxZ],
    [localBox.maxX, localBox.maxY, localBox.minZ],
    [localBox.maxX, localBox.maxY, localBox.maxZ],
  ];
}

function transformBoundingBoxCorners(localBox, transform) {
  if (!Array.isArray(transform) || transform.length < 12) {
    throw new Error('Transform matrix must contain at least 12 numeric values.');
  }

  return getBoundingBoxCorners(localBox).map(([x, y, z]) => {
    const point = transformPoint(transform, x, y, z);
    return [point.x, point.y, point.z];
  });
}

function transformPoints(points, transform) {
  if (!Array.isArray(transform) || transform.length < 12) {
    throw new Error('Transform matrix must contain at least 12 numeric values.');
  }

  const transformedPoints = [];
  if (points?.length > 0 && !Array.isArray(points[0]) && typeof points[0] !== 'object') {
    if (points.length % 3 !== 0) {
      throw new Error('Flat point array length must be divisible by 3.');
    }

    for (let index = 0; index < points.length; index += 3) {
      const x = Number(points[index]);
      const y = Number(points[index + 1]);
      const z = Number(points[index + 2]);
      if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(z)) {
        continue;
      }

      const transformedPoint = transformPoint(transform, x, y, z);
      transformedPoints.push([transformedPoint.x, transformedPoint.y, transformedPoint.z]);
    }

    return transformedPoints;
  }

  for (const point of points || []) {
    const x = Array.isArray(point) ? Number(point[0]) : Number(point?.x);
    const y = Array.isArray(point) ? Number(point[1]) : Number(point?.y);
    const z = Array.isArray(point) ? Number(point[2]) : Number(point?.z);
    if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(z)) {
      continue;
    }

    const transformedPoint = transformPoint(transform, x, y, z);
    transformedPoints.push([transformedPoint.x, transformedPoint.y, transformedPoint.z]);
  }

  return transformedPoints;
}

function createEmptyBoundingBox() {
  return {
    minX: Infinity,
    minY: Infinity,
    minZ: Infinity,
    maxX: -Infinity,
    maxY: -Infinity,
    maxZ: -Infinity,
  };
}

function boundingBoxFromPoints(points) {
  const box = createEmptyBoundingBox();
  for (const point of points || []) {
    const x = Array.isArray(point) ? point[0] : point.x;
    const y = Array.isArray(point) ? point[1] : point.y;
    const z = Array.isArray(point) ? point[2] : point.z;
    box.minX = Math.min(box.minX, x);
    box.minY = Math.min(box.minY, y);
    box.minZ = Math.min(box.minZ, z);
    box.maxX = Math.max(box.maxX, x);
    box.maxY = Math.max(box.maxY, y);
    box.maxZ = Math.max(box.maxZ, z);
  }
  return box;
}

function transformBoundingBox(localBox, transform) {
  return boundingBoxFromPoints(transformBoundingBoxCorners(localBox, transform));
}

function expandBoundingBox(target, source) {
  target.minX = Math.min(target.minX, source.minX);
  target.minY = Math.min(target.minY, source.minY);
  target.minZ = Math.min(target.minZ, source.minZ);
  target.maxX = Math.max(target.maxX, source.maxX);
  target.maxY = Math.max(target.maxY, source.maxY);
  target.maxZ = Math.max(target.maxZ, source.maxZ);
}

function isValidBoundingBox(box) {
  return [box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ].every(Number.isFinite);
}

function addObjectToIndex(byModelType, object) {
  const key = getModelTypeKey(object.modelId, object.entityType);
  if (!byModelType.has(key)) {
    byModelType.set(key, []);
  }

  byModelType.get(key).push(object.index);
}

function appendArray(target, values) {
  for (const value of values) {
    target.push(value);
  }
}

function createBroadPhaseException(
  row,
  modelId,
  discipline,
  entityType,
  reason,
  message,
  details = {},
) {
  return {
    phase: 'broad-phase',
    reason,
    message,
    modelId,
    discipline,
    globalId: String(row.GlobalId ?? '').trim(),
    entityId: String(row.entity_id ?? '').trim(),
    occurrenceType: String(row.type ?? '').trim(),
    entityType,
    ifcType: entityType,
    ...details,
  };
}

function getBoxCenter(box) {
  return {
    x: (box.minX + box.maxX) / 2,
    y: (box.minY + box.maxY) / 2,
    z: (box.minZ + box.maxZ) / 2,
  };
}

function getCenterDistance(a, b) {
  const centerA = getBoxCenter(a);
  const centerB = getBoxCenter(b);
  return Math.sqrt(
    (centerA.x - centerB.x) ** 2
    + (centerA.y - centerB.y) ** 2
    + (centerA.z - centerB.z) ** 2,
  );
}

function isReplacementSpatialMatch(a, b, rule = BAD_AGGREGATE_GEOMETRY_RULE) {
  const tolerance = Math.max(
    Number(rule.replacementSpatialToleranceM || 0),
    0.25 * Math.max(getBoundingBoxDiagonal(a), getBoundingBoxDiagonal(b)),
  );
  return getCenterDistance(a, b) <= tolerance;
}

export function getHashReplacementEvidence({
  badSource,
  badAnalysis,
  replacementComponentIndex,
  rule = BAD_AGGREGATE_GEOMETRY_RULE,
}) {
  const badGlobalId = String(badSource.row.GlobalId ?? '').trim();
  const badGeometryId = String(badSource.geometryId ?? '').trim();
  const badComponents = Array.isArray(badAnalysis.components) ? badAnalysis.components : [];
  if (badComponents.length === 0) {
    return {
      kind: 'none',
      hasReplacement: false,
      componentCount: 0,
      matchedComponentCount: 0,
      matchedCoverage: 0,
      matchedObjectCount: 0,
      matchedObjects: [],
    };
  }

  const badTransform = normalizeNestedArray(badSource.row.transform, 'transform');
  const badComponentWorldBoxes = badComponents.map(component => (
    transformBoundingBox(component.localBox, badTransform)
  ));
  const matchedComponentIndexes = new Set();
  const matchedObjects = new Map();

  for (let index = 0; index < badComponents.length; index += 1) {
    const badComponent = badComponents[index];
    const candidates = replacementComponentIndex.get(badComponent.hash) || [];
    for (const candidate of candidates) {
      if (
        candidate.globalId === badGlobalId
        || candidate.geometryId === badGeometryId
        || !isReplacementSpatialMatch(badComponentWorldBoxes[index], candidate.worldBox, rule)
      ) {
        continue;
      }
      matchedComponentIndexes.add(index);
      matchedObjects.set(candidate.globalId, {
        globalId: candidate.globalId,
        type: candidate.type,
        geometryId: candidate.geometryId,
      });
    }
  }

  const matchedComponentCount = matchedComponentIndexes.size;
  const matchedCoverage = badComponents.length > 0 ? matchedComponentCount / badComponents.length : 0;
  const hasReplacement = matchedObjects.size > 0 && matchedCoverage >= rule.minReplacementHashCoverage;

  return {
    kind: hasReplacement ? 'component-hash-spatial' : 'none',
    hasReplacement,
    componentCount: badComponents.length,
    matchedComponentCount,
    matchedCoverage,
    matchedObjectCount: matchedObjects.size,
    matchedObjects: [...matchedObjects.values()],
  };
}

export function getBadAggregateReplacementEvidence({
  badSource,
  badAnalysis,
  getReplacementComponentIndex,
}) {
  const hashEvidence = getHashReplacementEvidence({
    badSource,
    badAnalysis,
    replacementComponentIndex: getReplacementComponentIndex(),
  });
  return {
    canExclude: hashEvidence.hasReplacement,
    method: hashEvidence.hasReplacement ? hashEvidence.kind : 'none',
    hashEvidence,
  };
}

function getObjectDirectSystemIds(systemAssignments, globalId) {
  const systemIds = new Set();
  if (!globalId) {
    return [];
  }

  for (const systemId of systemAssignments.get(globalId)) {
    systemIds.add(systemId);
  }

  return [...systemIds].sort((a, b) => a.localeCompare(b));
}

function getObjectEffectiveSystemInfo(systemAssignments, coveredElementByCovering, row) {
  const globalId = String(row.GlobalId ?? '').trim();
  const directSystemIds = getObjectDirectSystemIds(systemAssignments, globalId);
  const effectiveSystemIds = new Set(directSystemIds);
  const derivedSystemIds = new Set();
  const coveringCoveredElementGlobalIds = [];

  if (String(row.type ?? '').trim() === 'IfcCovering') {
    for (const coveredElementGlobalId of coveredElementByCovering.get(globalId)) {
      coveringCoveredElementGlobalIds.push(coveredElementGlobalId);
      for (const systemId of getObjectDirectSystemIds(systemAssignments, coveredElementGlobalId)) {
        effectiveSystemIds.add(systemId);
        derivedSystemIds.add(systemId);
      }
    }
  }

  return {
    directSystemIds,
    effectiveSystemIds: [...effectiveSystemIds].sort((a, b) => a.localeCompare(b)),
    derivedSystemIds: [...derivedSystemIds].sort((a, b) => a.localeCompare(b)),
    coveringCoveredElementGlobalIds: coveringCoveredElementGlobalIds.sort((a, b) => a.localeCompare(b)),
  };
}

async function buildDisciplineObjects(model, globalObjectOffset = 0) {
  const { discipline } = model;
  const { folderName, modelId } = model;
  const modelPath = model.files.model;
  const geometryLibraryPath = model.files.geometry;
  const relationshipsPath = model.files.relationships;
  const folderPath = path.dirname(modelPath);
  const [modelRows, geometryRows, relationshipRows] = await Promise.all([
    readParquetObjects(modelPath, ['entity_id', 'GlobalId', 'type', 'Name', 'geometry_id', 'transform']),
    readParquetObjects(geometryLibraryPath, ['geometry_id', 'vertices', 'faces']),
    readParquetObjects(relationshipsPath, [
      'Relating_Object_Type',
      'Relating_Object_GUID',
      'Related_Object_Type',
      'Related_Object_GUID',
      'Relationship_Type',
    ]),
  ]);

  const spatialLevelLookup = createObjectSpatialLevelLookup(modelRows, relationshipRows);
  const geometryLookup = createGeometryLookup(geometryRows);
  const aggregateChildren = createAggregateChildrenLookup(relationshipRows);
  const aggregateForest = createAggregateForest(modelRows, relationshipRows, { modelId });
  const coversBldgElementPairs = createCoversBldgElementPairSet(relationshipRows, modelId);
  const connectsPathElementPairs = createConnectsPathElementPairSet(relationshipRows, modelId);
  const hostOpeningFillPairs = createHostOpeningFillPairSet(relationshipRows, modelId, aggregateChildren);
  const portConnectedElementPairs = createPortConnectedElementPairSet(relationshipRows, modelId);
  const systemAssignments = createSystemAssignmentLookup(relationshipRows, modelId);
  const coveredElementByCovering = createCoveredElementByCoveringLookup(relationshipRows);
  const geometryAnalysisCache = new Map();
  const objects = [];
  const exceptions = [];
  const timing = {
    badAggregateGeometryAnalysisMs: 0,
    badAggregateGeometryReplacementEvidenceMs: 0,
    badAggregateGeometryReplacementIndexBuildMs: 0,
  };
  const skipped = {
    noIfcType: 0,
    ignoredEntityType: 0,
    noGeometryId: 0,
    missingGeometry: 0,
    invalidGeometry: 0,
    invalidTransform: 0,
    badAggregateGeometry: 0,
    badAggregateGeometryExcluded: 0,
    badAggregateGeometryKept: 0,
  };

  const getGeometryAnalysis = (geometryId, analysisOptions = {}) => {
    const requireComponents = analysisOptions.requireComponents === true;
    if (!geometryAnalysisCache.has(geometryId)) {
      const geometryRow = geometryLookup.get(geometryId);
      if (!geometryRow) {
        throw new Error(`Geometry "${geometryId}" is missing from geometry_library.parquet.`);
      }
      const analysisStartedAtMs = performance.now();
      const vertices = normalizeNestedArray(geometryRow.vertices, 'vertices');
      const localBox = getLocalBoundingBox(vertices);
      geometryAnalysisCache.set(geometryId, {
        vertices,
        localBox,
        badAggregateGeometry: analyzeGeometryForBadAggregate(vertices, geometryRow.faces, localBox, {
          requireComponents,
        }),
      });
      timing.badAggregateGeometryAnalysisMs += elapsedMs(analysisStartedAtMs);
    }

    const cachedAnalysis = geometryAnalysisCache.get(geometryId);
    if (requireComponents && !cachedAnalysis.badAggregateGeometry.componentsComputed) {
      const geometryRow = geometryLookup.get(geometryId);
      if (!geometryRow) {
        throw new Error(`Geometry "${geometryId}" is missing from geometry_library.parquet.`);
      }
      const analysisStartedAtMs = performance.now();
      const vertices = cachedAnalysis.vertices || normalizeNestedArray(geometryRow.vertices, 'vertices');
      cachedAnalysis.badAggregateGeometry = analyzeGeometryForBadAggregate(
        vertices,
        geometryRow.faces,
        cachedAnalysis.localBox,
        { requireComponents: true },
      );
      timing.badAggregateGeometryAnalysisMs += elapsedMs(analysisStartedAtMs);
    }

    return cachedAnalysis;
  };

  let replacementComponentIndex = null;
  const getReplacementComponentIndex = () => {
    if (replacementComponentIndex) {
      return replacementComponentIndex;
    }

    const indexStartedAtMs = performance.now();
    replacementComponentIndex = new Map();
    for (const candidateRow of modelRows) {
      const candidateGlobalId = String(candidateRow.GlobalId ?? '').trim();
      const candidateType = String(candidateRow.type ?? '').trim();
      const candidateGeometryId = String(candidateRow.geometry_id ?? '').trim();
      if (
        !candidateGlobalId
        || !candidateType
        || NON_CLASHABLE_ENTITY_TYPES.has(candidateType)
        || !hasDirectGeometryId(candidateRow.geometry_id)
      ) {
        continue;
      }

      let candidateAnalysis;
      let candidateTransform;
      try {
        candidateAnalysis = getGeometryAnalysis(candidateGeometryId, { requireComponents: true });
        const candidateBadAggregateGeometry = classifyCachedGeometryForEntityType(
          candidateAnalysis.badAggregateGeometry,
          candidateType,
        );
        if (candidateBadAggregateGeometry.isBadAggregateGeometry) {
          continue;
        }
        candidateTransform = normalizeNestedArray(candidateRow.transform, 'transform');
      } catch {
        continue;
      }

      for (const component of candidateAnalysis.badAggregateGeometry.components || []) {
        let worldBox;
        try {
          worldBox = transformBoundingBox(component.localBox, candidateTransform);
        } catch {
          continue;
        }
        if (!replacementComponentIndex.has(component.hash)) {
          replacementComponentIndex.set(component.hash, []);
        }
        replacementComponentIndex.get(component.hash).push({
          globalId: candidateGlobalId,
          type: candidateType,
          geometryId: candidateGeometryId,
          worldBox,
        });
      }
    }

    timing.badAggregateGeometryReplacementIndexBuildMs += elapsedMs(indexStartedAtMs);
    return replacementComponentIndex;
  };

  for (const row of modelRows) {
    const entityId = String(row.entity_id ?? '').trim();
    const globalId = String(row.GlobalId ?? '').trim();
    const occurrenceType = String(row.type ?? '').trim();
    const entityType = occurrenceType;

    if (NON_CLASHABLE_ENTITY_TYPES.has(occurrenceType)) {
      skipped.ignoredEntityType += 1;
      continue;
    }
    if (!entityType) {
      skipped.noIfcType += 1;
      continue;
    }

    if (!hasDirectGeometryId(row.geometry_id)) {
      skipped.noGeometryId += 1;
      continue;
    }

    const geometryId = String(row.geometry_id).trim();
    const geometrySource = {
      row,
      geometryId,
      geometrySource: {
        kind: 'direct',
        globalId,
        geometryId,
      },
    };
    const geometryRow = geometryLookup.get(geometryId);
    if (!geometryRow) {
      skipped.missingGeometry += 1;
      continue;
    }

    let geometryAnalysis;
    try {
      geometryAnalysis = getGeometryAnalysis(geometryId);
    } catch {
      skipped.invalidGeometry += 1;
      continue;
    }

    let badAggregateGeometry = null;
    const sourceBadAggregateGeometry = classifyCachedGeometryForEntityType(
      geometryAnalysis.badAggregateGeometry,
      entityType,
    );
    if (sourceBadAggregateGeometry.isBadAggregateGeometry) {
      badAggregateGeometry = {
        source: geometrySource,
        analysis: sourceBadAggregateGeometry,
      };
    }

    let bbox;
    let worldPoints;
    try {
      const transform = normalizeNestedArray(row.transform, 'transform');
      worldPoints = transformPoints(geometryAnalysis.vertices, transform);
      bbox = boundingBoxFromPoints(worldPoints);
    } catch {
      skipped.invalidTransform += 1;
      continue;
    }
    if (badAggregateGeometry) {
      const analysis = badAggregateGeometry.analysis;
      skipped.badAggregateGeometry += 1;
      let replacementEvidence;
      const replacementEvidenceStartedAtMs = performance.now();
      try {
        replacementEvidence = getBadAggregateReplacementEvidence({
          badSource: badAggregateGeometry.source,
          badAnalysis: analysis,
          getReplacementComponentIndex,
        });
      } catch {
        replacementEvidence = {
          canExclude: false,
          method: 'replacement-analysis-failed',
        };
      }
      timing.badAggregateGeometryReplacementEvidenceMs += elapsedMs(replacementEvidenceStartedAtMs);
      const geometryOnlyBadAggregate = isGeometryOnlyBadAggregate(analysis);
      const exclusionEvidenceMethod = replacementEvidence.canExclude
        ? replacementEvidence.method
        : geometryOnlyBadAggregate
          ? `geometry-${analysis.badAggregateGeometryPattern}`
          : 'none';

      const badAggregateDetails = {
        geometryId: String(badAggregateGeometry.source.geometryId || ''),
        geometrySourceGlobalId: String(badAggregateGeometry.source.geometrySource?.globalId || ''),
        geometrySourceKind: String(badAggregateGeometry.source.geometrySource?.kind || ''),
        boundingBoxDiagonalM: analysis.boundingBoxDiagonalM,
        connectedComponentCount: analysis.componentCount,
        componentMedianDiagonalM: analysis.componentMedianDiagonalM,
        componentMaxDiagonalM: analysis.componentMaxDiagonalM,
        componentCenterSpreadDiagonalM: analysis.componentCenterSpreadDiagonalM,
        componentCenterLargestExtentM: analysis.componentCenterLargestExtentM,
        componentCenterSecondExtentM: analysis.componentCenterSecondExtentM,
        componentCenterPrincipalFirstSpreadM: analysis.componentCenterPrincipalFirstSpreadM,
        componentCenterPrincipalSecondSpreadM: analysis.componentCenterPrincipalSecondSpreadM,
        componentCenterPrincipalSecondToFirstRatio: analysis.componentCenterPrincipalSecondToFirstRatio,
        boundingBoxToMedianComponentRatio: analysis.boundingBoxToMedianComponentRatio,
        sparseCenterSpreadRatio: analysis.sparseCenterSpreadRatio,
        componentCenterSpreadToMedianRatio: analysis.componentCenterSpreadToMedianRatio,
        componentCloudSecondExtentToMedianRatio: analysis.componentCloudSecondExtentToMedianRatio,
        componentCloudSecondToLargestExtentRatio: analysis.componentCloudSecondToLargestExtentRatio,
        maxComponentToBoundingBoxRatio: analysis.maxComponentToBoundingBoxRatio,
        badAggregateGeometryPattern: analysis.badAggregateGeometryPattern,
        replacementEvidenceMethod: replacementEvidence.method,
        exclusionEvidenceMethod,
        replacementEvidence,
        badAggregateGeometryRule: analysis.rule,
      };

      if (
        replacementEvidence.canExclude
        || geometryOnlyBadAggregate
      ) {
        skipped.badAggregateGeometryExcluded += 1;
        exceptions.push(createBroadPhaseException(
          row,
          modelId,
          discipline,
          entityType,
          'bad-aggregate-geometry',
          `Object "${globalId}" was excluded from clash detection because geometry "${badAggregateGeometry.source.geometryId}" matches the bad aggregate geometry guard (${analysis.badAggregateGeometryPattern}) with exclusion evidence "${exclusionEvidenceMethod}": bbox diagonal ${formatMeters(analysis.boundingBoxDiagonalM)}m, ${analysis.componentCount} connected components, bbox/median-component ratio ${analysis.boundingBoxToMedianComponentRatio.toFixed(1)}, sparse center spread ratio ${analysis.sparseCenterSpreadRatio.toFixed(1)}.`,
          badAggregateDetails,
        ));
        continue;
      }

      skipped.badAggregateGeometryKept += 1;
      exceptions.push(createBroadPhaseException(
        row,
        modelId,
        discipline,
        entityType,
        'bad-aggregate-geometry-kept',
        `Object "${globalId}" matches the bad aggregate geometry guard (${analysis.badAggregateGeometryPattern}) but was kept in clash detection because no replacement geometry was proven: bbox diagonal ${formatMeters(analysis.boundingBoxDiagonalM)}m, ${analysis.componentCount} connected components, bbox/median-component ratio ${analysis.boundingBoxToMedianComponentRatio.toFixed(1)}, sparse center spread ratio ${analysis.sparseCenterSpreadRatio.toFixed(1)}.`,
        badAggregateDetails,
      ));
    }
    if (!isValidBoundingBox(bbox)) {
      skipped.invalidTransform += 1;
      continue;
    }

    const systemInfo = getObjectEffectiveSystemInfo(systemAssignments, coveredElementByCovering, row);
    const spatialLevel = spatialLevelLookup.get(globalId);
    const object = {
      index: globalObjectOffset + objects.length,
      modelId,
      folderName,
      discipline,
      entityId,
      globalId,
      occurrenceType,
      entityType,
      ifcType: entityType,
      geometryId,
      geometrySource: geometrySource.geometrySource,
      aggregateTreeId: aggregateForest.treeIdByObject.get(globalId) || null,
      directSystemIds: systemInfo.directSystemIds,
      effectiveSystemIds: systemInfo.effectiveSystemIds,
      derivedSystemIds: systemInfo.derivedSystemIds,
      coveringCoveredElementGlobalIds: systemInfo.coveringCoveredElementGlobalIds,
      spatialLevelName: spatialLevel?.name || null,
      spatialLevelNormalizedName: spatialLevel?.normalizedName || null,
      spatialLevelStoreyGlobalId: spatialLevel?.storeyGlobalId || null,
      bbox,
      obb: computeHorizontalObb(worldPoints),
    };

    objects.push(object);
  }

  return {
    discipline,
    folderName,
    folderPath,
    ifcPath: null,
    objects,
    exceptions,
    aggregateForest,
    coversBldgElementPairs,
    connectsPathElementPairs,
    hostOpeningFillPairs,
    portConnectedElementPairs,
    stats: {
      modelRowCount: modelRows.length,
      geometryCount: geometryRows.length,
      relationshipCount: relationshipRows.length,
      exceptionCount: exceptions.length,
      objectCount: objects.length,
      ifcTypeCount: 0,
      typedObjectCount: objects.length,
      relationCount: 0,
      aggregateForest: aggregateForest.stats,
      skipped,
      timing: {
        badAggregateGeometryAnalysisMs: roundMs(timing.badAggregateGeometryAnalysisMs),
        badAggregateGeometryReplacementEvidenceMs: roundMs(timing.badAggregateGeometryReplacementEvidenceMs),
        badAggregateGeometryReplacementIndexBuildMs: roundMs(timing.badAggregateGeometryReplacementIndexBuildMs),
      },
    },
  };
}

function mergeSet(target, source) {
  for (const value of source) {
    target.add(value);
  }
}

export async function buildBroadPhaseDataset(projectDescriptor, options = {}) {
  const project = createProjectDescriptor(projectDescriptor);
  const objects = [];
  const aggregateForestsByModelId = new Map();
  const coversBldgElementPairs = new Set();
  const connectsPathElementPairs = new Set();
  const hostOpeningFillPairs = new Set();
  const portConnectedElementPairs = new Set();
  const disciplineStats = [];
  const exceptions = [];

  for (const model of project.models) {
    const { discipline } = model;
    const { folderName, modelId } = model;
    const folderPath = path.dirname(model.files.model);
    await throwIfCanceled(options.shouldCancel, `loading ${discipline}`);
    await options.onDisciplineStart?.(discipline);
    const disciplineDataset = await buildDisciplineObjects(model, objects.length);
    await options.onDisciplineEnd?.(discipline, disciplineDataset.stats);

    appendArray(objects, disciplineDataset.objects);
    appendArray(exceptions, disciplineDataset.exceptions);
    aggregateForestsByModelId.set(modelId, disciplineDataset.aggregateForest);
    mergeSet(coversBldgElementPairs, disciplineDataset.coversBldgElementPairs);
    mergeSet(connectsPathElementPairs, disciplineDataset.connectsPathElementPairs);
    mergeSet(hostOpeningFillPairs, disciplineDataset.hostOpeningFillPairs);
    mergeSet(portConnectedElementPairs, disciplineDataset.portConnectedElementPairs);
    disciplineStats.push({
      modelId,
      discipline,
      folderName,
      folderPath: disciplineDataset.folderPath,
      ifcPath: disciplineDataset.ifcPath,
      ...disciplineDataset.stats,
    });
  }

  // Duplicate input models (the same model staged twice) are treated as an
  // input-contract violation and are not merged away here. The only expected
  // cross-model GlobalId reuse is shared reference elements (project base
  // points, coordination bodies) exported into several discipline models;
  // their copy-vs-copy pairs are dropped by the same-GlobalId self-pair filter
  // during candidate enumeration.
  const byModelType = new Map();
  for (const object of objects) {
    addObjectToIndex(byModelType, object);
  }

  return {
    basePath: project.projectId || null,
    projectDescriptor: project,
    objects,
    byModelType,
    aggregateForestsByModelId,
    coversBldgElementPairs,
    connectsPathElementPairs,
    hostOpeningFillPairs,
    portConnectedElementPairs,
    exceptions,
    disciplineStats,
  };
}

export function summarizeBroadPhaseDataset(dataset) {
  const byModelType = Object.fromEntries(
    [...dataset.byModelType.entries()]
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([key, indices]) => [key, indices.length]),
  );

  return {
    basePath: dataset.basePath,
    objectCount: dataset.objects.length,
    exceptionCount: dataset.exceptions.length,
    exceptions: dataset.exceptions,
    disciplineStats: dataset.disciplineStats,
    byModelType,
  };
}

// Matrix tolerance is a narrow-phase report filter, not a clearance search
// radius, so the broad phase tests pure geometric overlap only.
function intersectsAabb(a, b) {
  return (
    a.minX <= b.maxX
    && a.maxX >= b.minX
    && a.minY <= b.maxY
    && a.maxY >= b.minY
    && a.minZ <= b.maxZ
    && a.maxZ >= b.minZ
  );
}

function getAxisMin(box, axis) {
  return axis === 'x' ? box.minX : axis === 'y' ? box.minY : box.minZ;
}

function getAxisMax(box, axis) {
  return axis === 'x' ? box.maxX : axis === 'y' ? box.maxY : box.maxZ;
}

function chooseSweepAxis(objects, sourceIndices, targetIndices) {
  const bounds = {
    x: { min: Infinity, max: -Infinity },
    y: { min: Infinity, max: -Infinity },
    z: { min: Infinity, max: -Infinity },
  };

  for (const objectIndex of new Set([...sourceIndices, ...targetIndices])) {
    const box = objects[objectIndex]?.bbox;
    if (!box) {
      continue;
    }

    bounds.x.min = Math.min(bounds.x.min, box.minX);
    bounds.x.max = Math.max(bounds.x.max, box.maxX);
    bounds.y.min = Math.min(bounds.y.min, box.minY);
    bounds.y.max = Math.max(bounds.y.max, box.maxY);
    bounds.z.min = Math.min(bounds.z.min, box.minZ);
    bounds.z.max = Math.max(bounds.z.max, box.maxZ);
  }

  return ['x', 'y', 'z']
    .map(axis => ({
      axis,
      spread: Number.isFinite(bounds[axis].min) ? bounds[axis].max - bounds[axis].min : -Infinity,
    }))
    .sort((a, b) => b.spread - a.spread)[0]?.axis || 'x';
}

function getTheoreticalPairCount(sourceIndices, targetIndices, sameGroup) {
  if (sameGroup) {
    return sourceIndices.length * Math.max(sourceIndices.length - 1, 0) / 2;
  }

  return sourceIndices.length * targetIndices.length;
}

function isSameAggregateTree(sourceObject, targetObject) {
  return Boolean(
    sourceObject.aggregateTreeId
    && sourceObject.aggregateTreeId === targetObject.aggregateTreeId,
  );
}

export function shouldFilterByObbRefinement(sourceObject, targetObject, enabled) {
  if (!enabled) {
    return false;
  }
  if (!sourceObject.obb || !targetObject.obb) {
    return false;
  }
  return !intersectsHorizontalObb(sourceObject.obb, targetObject.obb);
}

async function* enumerateAabbCandidatePairsBruteForce(
  objects,
  sourceIndices,
  targetIndices,
  sameGroup,
  stats,
  options = {},
) {
  for (let sourcePosition = 0; sourcePosition < sourceIndices.length; sourcePosition += 1) {
    await throwIfCanceled(options.shouldCancel, 'broad-phase source scan');
    const sourceObject = objects[sourceIndices[sourcePosition]];
    const targetStart = sameGroup ? sourcePosition + 1 : 0;

    for (let targetPosition = targetStart; targetPosition < targetIndices.length; targetPosition += 1) {
      const targetObject = objects[targetIndices[targetPosition]];
      if (isSameAggregateTree(sourceObject, targetObject)) {
        stats.aggregateTreeFilteredCount += 1;
        options.onAggregateTreeFiltered?.(sourceObject, targetObject);
        continue;
      }

      stats.aabbCheckCount += 1;

      if (intersectsAabb(sourceObject.bbox, targetObject.bbox)) {
        yield { sourceObject, targetObject };
      }
    }
  }
}

async function* enumerateAabbCandidatePairsSweep(
  objects,
  sourceIndices,
  targetIndices,
  sameGroup,
  stats,
  options = {},
) {
  const axis = chooseSweepAxis(objects, sourceIndices, targetIndices);
  stats.sweepAxis = axis;
  const sortedSources = getSortedRuleObjects(
    objects,
    sourceIndices,
    axis,
    'sourcePosition',
  );
  const sortedTargets = getSortedRuleObjects(
    objects,
    targetIndices,
    axis,
    'targetPosition',
  );

  const activeTargets = [];
  let targetCursor = 0;
  let expiredSinceCompaction = 0;

  for (const source of sortedSources) {
    await throwIfCanceled(options.shouldCancel, 'broad-phase source scan');
    const sourceMin = getAxisMin(source.object.bbox, axis);
    const sourceMax = getAxisMax(source.object.bbox, axis);

    while (
      targetCursor < sortedTargets.length
      && getAxisMin(sortedTargets[targetCursor].object.bbox, axis) <= sourceMax
    ) {
      activeTargets.push(sortedTargets[targetCursor]);
      targetCursor += 1;
    }

    for (const target of activeTargets) {
      if (getAxisMax(target.object.bbox, axis) < sourceMin) {
        expiredSinceCompaction += 1;
        continue;
      }
      if (sameGroup && target.targetPosition <= source.sourcePosition) {
        continue;
      }
      if (isSameAggregateTree(source.object, target.object)) {
        stats.aggregateTreeFilteredCount += 1;
        options.onAggregateTreeFiltered?.(source.object, target.object);
        continue;
      }

      stats.aabbCheckCount += 1;
      if (intersectsAabb(source.object.bbox, target.object.bbox)) {
        yield {
          sourceObject: source.object,
          targetObject: target.object,
        };
      }
    }

    if (expiredSinceCompaction > 1024 || activeTargets.length > 10000) {
      let writeIndex = 0;
      for (const target of activeTargets) {
        if (getAxisMax(target.object.bbox, axis) >= sourceMin) {
          activeTargets[writeIndex] = target;
          writeIndex += 1;
        }
      }
      activeTargets.length = writeIndex;
      expiredSinceCompaction = 0;
    }
  }
}

function getSortedRuleObjects(objects, indices, axis, positionField) {
  return indices
    .map((objectIndex, position) => ({
      objectIndex,
      [positionField]: position,
      object: objects[objectIndex],
    }))
    .sort((a, b) => (
      getAxisMin(a.object.bbox, axis) - getAxisMin(b.object.bbox, axis)
      || a[positionField] - b[positionField]
    ));
}

function serializeCandidateObject(object) {
  return {
    modelId: object.modelId,
    folderName: object.folderName,
    discipline: object.discipline,
    globalId: object.globalId,
    entityType: object.entityType,
  };
}

function createCandidate(rule, sourceObject, targetObject, toleranceMm) {
  const source = serializeCandidateObject(sourceObject);
  const target = serializeCandidateObject(targetObject);
  const pair = createCandidatePair(source, target, {
    rule: rule.marker || rule.name || 'G',
    toleranceMm,
    sourceIndex: sourceObject.index,
    targetIndex: targetObject.index,
  });
  pair.source = source;
  pair.target = target;
  return pair;
}

function getObjectIndicesForRule(dataset, endpoint) {
  const entityType = endpoint.entityType || endpoint.ifcType;
  const modelGuid = String(endpoint.modelGuid || '').trim();
  if (!modelGuid) {
    throw new Error('Broad-phase matrix endpoint modelGuid is required.');
  }

  return dataset.byModelType.get(getModelTypeKey(modelGuid, entityType)) || [];
}

function canonicalizeRuleValue(value) {
  if (Array.isArray(value)) {
    return value.map(item => canonicalizeRuleValue(item));
  }
  if (!value || typeof value !== 'object') {
    return value;
  }

  return Object.fromEntries(
    Object.keys(value)
      .filter(key => value[key] !== undefined)
      .sort()
      .map(key => [key, canonicalizeRuleValue(value[key])]),
  );
}

function createEquivalentRuleKey(rule = {}) {
  const sourceKey = JSON.stringify(canonicalizeRuleValue(rule.source || {}));
  const targetKey = JSON.stringify(canonicalizeRuleValue(rule.target || {}));
  const {
    source: _source,
    target: _target,
    marker: _marker,
    name: _name,
    toleranceMm: _toleranceMm,
    ...directionalOptions
  } = rule;
  const normalizedDirectionalOptions = canonicalizeRuleValue(directionalOptions);
  const hasDirectionalOptions = Object.keys(normalizedDirectionalOptions).length > 0;

  return JSON.stringify({
    endpoints: hasDirectionalOptions
      ? [sourceKey, targetKey]
      : [sourceKey, targetKey].sort((left, right) => left.localeCompare(right)),
    marker: String(rule.marker || rule.name || 'G').trim() || 'G',
    toleranceMm: normalizeToleranceMm(rule.toleranceMm),
    directionalOptions: normalizedDirectionalOptions,
  });
}

function getUniqueMatrixRules(matrix) {
  const uniqueRules = [];
  const ruleKeys = new Set();
  for (const rule of Array.isArray(matrix?.enabledPairs) ? matrix.enabledPairs : []) {
    const ruleKey = createEquivalentRuleKey(rule);
    if (ruleKeys.has(ruleKey)) {
      continue;
    }
    ruleKeys.add(ruleKey);
    uniqueRules.push(rule);
  }
  return uniqueRules;
}

function shouldIgnoreSameSystem(matrix, options) {
  return options.ignoreSameSystem ?? matrix?.options?.ignoreSameSystem ?? true;
}

function shouldIgnoreSpacesAndOpenings(matrix, options) {
  return (
    options.ignoreSpacesAndOpenings
    ?? matrix?.options?.ignoreSpacesAndOpenings
    ?? true
  );
}

function normalizeSpatialLevelFilterForBroadPhase(matrix, options) {
  const rawFilter = options.spatialLevelFilter
    ?? matrix?.spatialLevelFilter
    ?? matrix?.options?.spatialLevelFilter
    ?? null;
  if (!rawFilter) {
    return null;
  }

  const mode = rawFilter.mode || 'anySide';
  if (mode !== 'anySide') {
    throw new Error(`Unsupported spatialLevelFilter.mode "${mode}".`);
  }

  const names = [];
  const normalizedNames = new Set();
  for (const value of rawFilter.names || rawFilter.levelNames || []) {
    const name = String(value ?? '').trim().replace(/\s+/g, ' ');
    const normalizedName = normalizeSpatialLevelName(name);
    if (!normalizedName || normalizedNames.has(normalizedName)) {
      continue;
    }

    names.push(name);
    normalizedNames.add(normalizedName);
  }

  if (names.length === 0) {
    return null;
  }
  names.sort((left, right) => left.localeCompare(right, undefined, {
    numeric: true,
    sensitivity: 'base',
  }));

  return {
    mode: 'anySide',
    names,
    normalizedNames,
  };
}

function serializeSpatialLevelFilter(filter) {
  if (!filter) {
    return null;
  }

  return {
    mode: filter.mode,
    names: filter.names,
  };
}

function getObjectSpatialLevelNormalizedName(object) {
  return normalizeSpatialLevelName(
    object?.spatialLevelNormalizedName || object?.spatialLevelName || '',
  ) || null;
}

function evaluateSpatialLevelFilter(sourceObject, targetObject, spatialLevelFilter) {
  if (!spatialLevelFilter) {
    return {
      keep: true,
      keptBecauseUnknown: false,
    };
  }

  const sourceLevel = getObjectSpatialLevelNormalizedName(sourceObject);
  const targetLevel = getObjectSpatialLevelNormalizedName(targetObject);
  if (!sourceLevel || !targetLevel) {
    return {
      keep: true,
      keptBecauseUnknown: true,
    };
  }

  return {
    keep: (
      spatialLevelFilter.normalizedNames.has(sourceLevel)
      || spatialLevelFilter.normalizedNames.has(targetLevel)
    ),
    keptBecauseUnknown: false,
  };
}

export function isSpaceOrOpeningObject(object) {
  return SPACE_AND_OPENING_ENTITY_TYPES.has(object?.entityType || object?.ifcType);
}

function isSpaceOrOpeningEntityType(entityType) {
  return SPACE_AND_OPENING_ENTITY_TYPES.has(String(entityType || '').trim());
}

export async function runBroadPhaseCandidateBatches(dataset, matrix, options = {}) {
  const timingStartedAtMs = performance.now();
  const batchSize = normalizeClashBatchSize(options.batchSize, {
    maxBatchSize: options.batchSizeLimit,
  });
  const ignoreSameSystem = shouldIgnoreSameSystem(matrix, options);
  const ignoreCoversBldgElements = options.ignoreCoversBldgElements ?? true;
  const ignoreConnectsPathElements = options.ignoreConnectsPathElements ?? true;
  const ignoreHostOpeningFill = options.ignoreHostOpeningFill ?? true;
  const ignorePortConnected = options.ignorePortConnected ?? true;
  const ignoreSpacesAndOpenings = shouldIgnoreSpacesAndOpenings(matrix, options);
  const spatialLevelFilter = normalizeSpatialLevelFilterForBroadPhase(matrix, options);
  const useAabbSweep = options.useAabbSweep ?? matrix?.options?.useAabbSweep ?? true;
  const useObbRefinement = options.useObbRefinement ?? matrix?.options?.useObbRefinement ?? true;
  const onBatch = typeof options.onBatch === 'function' ? options.onBatch : async () => {};
  const onCandidate = typeof options.onCandidate === 'function' ? options.onCandidate : null;
  const onCoverageExclusion = typeof options.onCoverageExclusion === 'function'
    ? options.onCoverageExclusion
    : null;
  const recordCoverageExclusions = (
    options.recordCoverageExclusions === true
    || onCoverageExclusion !== null
  );
  const collectCoverageExclusions = options.collectCoverageExclusions !== false;
  const configuredExclusionLimit = Number(options.coverageExclusionLimit ?? 250000);
  const coverageExclusionLimit = Number.isFinite(configuredExclusionLimit)
    ? Math.max(0, Math.floor(configuredExclusionLimit))
    : 250000;
  const coverageExclusions = [];
  let coverageExclusionCount = 0;
  let coverageExclusionsTruncated = false;

  function recordCoverageExclusion(reason, sourceObject, targetObject) {
    if (!recordCoverageExclusions) return;
    coverageExclusionCount += 1;
    onCoverageExclusion?.(reason, sourceObject, targetObject);
    if (!collectCoverageExclusions) return;
    if (coverageExclusions.length >= coverageExclusionLimit) {
      coverageExclusionsTruncated = true;
      return;
    }
    coverageExclusions.push({
      reason,
      source: {
        modelId: sourceObject.modelId,
        globalId: sourceObject.globalId,
      },
      target: {
        modelId: targetObject.modelId,
        globalId: targetObject.globalId,
      },
    });
  }
  const rules = getUniqueMatrixRules(matrix);
  const ruleSummaries = [];
  let batch = [];
  let totalCandidateCount = 0;
  let totalSpatialCandidateCount = 0;
  let totalTheoreticalPairCount = 0;
  let totalAabbCheckCount = 0;
  let aggregateTreeFilteredCount = 0;
  let selfPairFilteredCount = 0;
  let obbFilteredCount = 0;
  let sameSystemFilteredCount = 0;
  let semanticFilteredCount = 0;
  let spatialLevelFilteredCount = 0;
  let spatialLevelUnknownKeptCount = 0;
  const sameSystemFilteredByLevel = createSameSystemFilterCounts();
  const semanticFilteredByLevel = createSemanticFilterCounts();
  let batchCount = 0;
  let onBatchMs = 0;

  // Optional live progress logging for diagnosing candidate explosions. Enabled
  // by options.verboseProgress or CLASH_BROAD_VERBOSE=1. Goes to stderr so it
  // never mixes with the worker's stdout JSON logs. Throttled to ~2s, plus a
  // one-line summary for any single rule (type-pair) that emits many spatial
  // candidates — that pinpoints which pair is exploding and which filter (if
  // any) is failing to cut it down.
  const verboseProgress = options.verboseProgress ?? (process.env.CLASH_BROAD_VERBOSE === '1');
  const heavyRuleSpatialThreshold = Number(process.env.CLASH_BROAD_HEAVY_RULE || 5000);
  let lastProgressLogAtMs = 0;
  let ruleIndex = 0;
  function logBroadProgress(force = false) {
    if (!verboseProgress) {
      return;
    }
    const now = performance.now();
    if (!force && now - lastProgressLogAtMs < 2000) {
      return;
    }
    lastProgressLogAtMs = now;
    console.error(
      `[broad] rule ${ruleIndex}/${rules.length} | spatial=${totalSpatialCandidateCount} `
      + `treeFiltered=${aggregateTreeFilteredCount} selfFiltered=${selfPairFilteredCount} obbFiltered=${obbFilteredCount} sameSysFiltered=${sameSystemFilteredCount} semanticFiltered=${semanticFilteredCount} `
      + `spatialLevelFiltered=${spatialLevelFilteredCount} -> candidates=${totalCandidateCount} `
      + `(batches=${batchCount}, ${roundMs(elapsedMs(timingStartedAtMs))}ms)`,
    );
  }

  async function flushBatch() {
    if (batch.length === 0) {
      return;
    }

    await throwIfCanceled(options.shouldCancel, 'broad-phase batch flush');
    batchCount += 1;
    const flushedCandidateCount = batch.length;
    const onBatchStartedAtMs = performance.now();
    await onBatch(batch, {
      batchNumber: batchCount,
      batchCandidateCount: flushedCandidateCount,
      totalCandidateCount,
    });
    onBatchMs += performance.now() - onBatchStartedAtMs;
    batch = [];
  }

  for (const rule of rules) {
    await throwIfCanceled(options.shouldCancel, 'broad-phase rule');
    ruleIndex += 1;
    logBroadProgress();
    const ruleStartedAtMs = performance.now();
    const ruleOnBatchStartedMs = onBatchMs;
    const toleranceMm = normalizeToleranceMm(rule.toleranceMm);
    const sourceEntityType = rule.source?.entityType || rule.source?.ifcType;
    const targetEntityType = rule.target?.entityType || rule.target?.ifcType;
    const ignoredByTypeRule = (
      ignoreSpacesAndOpenings
      && (isSpaceOrOpeningEntityType(sourceEntityType)
        || isSpaceOrOpeningEntityType(targetEntityType))
    );
    const sourceIndices = ignoredByTypeRule
      ? []
      : getObjectIndicesForRule(dataset, rule.source || {});
    const targetIndices = ignoredByTypeRule
      ? []
      : getObjectIndicesForRule(dataset, rule.target || {});
    const sameGroup = (
      rule.source?.modelGuid === rule.target?.modelGuid
      && rule.source?.discipline === rule.target?.discipline
      && sourceEntityType === targetEntityType
    );
    let ruleCandidateCount = 0;
    let ruleSpatialCandidateCount = 0;
    let ruleSelfPairFilteredCount = 0;
    let ruleObbFilteredCount = 0;
    let ruleSameSystemFilteredCount = 0;
    let ruleSemanticFilteredCount = 0;
    let ruleSpatialLevelFilteredCount = 0;
    let ruleSpatialLevelUnknownKeptCount = 0;
    const ruleSameSystemFilteredByLevel = createSameSystemFilterCounts();
    const ruleSemanticFilteredByLevel = createSemanticFilterCounts();
    const testedPairCount = getTheoreticalPairCount(sourceIndices, targetIndices, sameGroup);
    const aabbStats = {
      aabbCheckCount: 0,
      aggregateTreeFilteredCount: 0,
      sweepAxis: null,
    };
    const pairEnumerationOptions = recordCoverageExclusions
      ? {
          ...options,
          onAggregateTreeFiltered: (sourceObject, targetObject) => {
            recordCoverageExclusion(
              'same_aggregate_tree',
              sourceObject,
              targetObject,
            );
          },
        }
      : options;
    totalTheoreticalPairCount += testedPairCount;
    const aabbPairIterator = useAabbSweep
      ? enumerateAabbCandidatePairsSweep(
        dataset.objects,
        sourceIndices,
        targetIndices,
        sameGroup,
        aabbStats,
        pairEnumerationOptions,
      )
      : enumerateAabbCandidatePairsBruteForce(
        dataset.objects,
        sourceIndices,
        targetIndices,
        sameGroup,
        aabbStats,
        pairEnumerationOptions,
      );

    for await (const { sourceObject, targetObject } of aabbPairIterator) {
      ruleSpatialCandidateCount += 1;
      totalSpatialCandidateCount += 1;

      // Same GlobalId on both endpoints means one physical object was loaded from
      // more than one model. The expected case is shared reference elements
      // (project base points, coordination bodies) exported into several
      // discipline models; copies are not merged at dataset build, so this filter
      // is the guard that stops a copy pair here. The copies fully overlap, so
      // CSG would report a spurious 100%-volume self-collision. An object can
      // never clash itself, so drop the pair before it becomes a candidate.
      // Copy-vs-third-party pairs are intentionally NOT deduplicated: each model
      // copy reports its own row (known, accepted noise for shared reference
      // elements; duplicate input models are an input-contract violation).
      if (sourceObject.globalId && sourceObject.globalId === targetObject.globalId) {
        ruleSelfPairFilteredCount += 1;
        selfPairFilteredCount += 1;
        recordCoverageExclusion('same_global_id', sourceObject, targetObject);
        continue;
      }

      if (shouldFilterByObbRefinement(sourceObject, targetObject, useObbRefinement)) {
        ruleObbFilteredCount += 1;
        obbFilteredCount += 1;
        continue;
      }

      if (
        ignoreSpacesAndOpenings
        && (isSpaceOrOpeningObject(sourceObject) || isSpaceOrOpeningObject(targetObject))
      ) {
        recordCoverageExclusion('space_or_opening', sourceObject, targetObject);
        continue;
      }

      const spatialLevelDecision = evaluateSpatialLevelFilter(
        sourceObject,
        targetObject,
        spatialLevelFilter,
      );
      if (!spatialLevelDecision.keep) {
        ruleSpatialLevelFilteredCount += 1;
        spatialLevelFilteredCount += 1;
        continue;
      }
      if (spatialLevelDecision.keptBecauseUnknown) {
        ruleSpatialLevelUnknownKeptCount += 1;
        spatialLevelUnknownKeptCount += 1;
      }

      if (ignoreSameSystem) {
        const sameSystemDecision = decideSameSystemIgnore(sourceObject, targetObject);
        if (sameSystemDecision.ignore) {
          ruleSameSystemFilteredCount += 1;
          sameSystemFilteredCount += 1;
          ruleSameSystemFilteredByLevel[sameSystemDecision.level] += 1;
          sameSystemFilteredByLevel[sameSystemDecision.level] += 1;
          recordCoverageExclusion('same_system', sourceObject, targetObject);
          continue;
        }
      }

      if (ignoreCoversBldgElements) {
        const coversBldgElementDecision = decideCoversBldgElementIgnore(sourceObject, targetObject, dataset);
        if (coversBldgElementDecision.ignore) {
          ruleSemanticFilteredCount += 1;
          semanticFilteredCount += 1;
          ruleSemanticFilteredByLevel[coversBldgElementDecision.level] += 1;
          semanticFilteredByLevel[coversBldgElementDecision.level] += 1;
          recordCoverageExclusion(
            'covers_building_element',
            sourceObject,
            targetObject,
          );
          continue;
        }
      }

      if (ignoreConnectsPathElements) {
        const connectsPathElementDecision = decideConnectsPathElementIgnore(sourceObject, targetObject, dataset);
        if (connectsPathElementDecision.ignore) {
          ruleSemanticFilteredCount += 1;
          semanticFilteredCount += 1;
          ruleSemanticFilteredByLevel[connectsPathElementDecision.level] += 1;
          semanticFilteredByLevel[connectsPathElementDecision.level] += 1;
          recordCoverageExclusion(
            'connects_path_element',
            sourceObject,
            targetObject,
          );
          continue;
        }
      }

      if (ignoreHostOpeningFill) {
        const hostOpeningFillDecision = decideHostOpeningFillIgnore(sourceObject, targetObject, dataset);
        if (hostOpeningFillDecision.ignore) {
          ruleSemanticFilteredCount += 1;
          semanticFilteredCount += 1;
          ruleSemanticFilteredByLevel[hostOpeningFillDecision.level] += 1;
          semanticFilteredByLevel[hostOpeningFillDecision.level] += 1;
          recordCoverageExclusion(
            'host_opening_fill',
            sourceObject,
            targetObject,
          );
          continue;
        }
      }

      if (ignorePortConnected) {
        const portConnectedDecision = decidePortConnectedIgnore(sourceObject, targetObject, dataset);
        if (portConnectedDecision.ignore) {
          ruleSemanticFilteredCount += 1;
          semanticFilteredCount += 1;
          ruleSemanticFilteredByLevel[portConnectedDecision.level] += 1;
          semanticFilteredByLevel[portConnectedDecision.level] += 1;
          recordCoverageExclusion('port_connected', sourceObject, targetObject);
          continue;
        }
      }

      ruleCandidateCount += 1;
      totalCandidateCount += 1;
      const candidate = createCandidate(rule, sourceObject, targetObject, toleranceMm);
      await onCandidate?.(candidate);
      batch.push(candidate);

      if (batch.length >= batchSize) {
        await flushBatch();
      }
    }
    totalAabbCheckCount += aabbStats.aabbCheckCount;
    aggregateTreeFilteredCount += aabbStats.aggregateTreeFilteredCount;

    const ruleDurationMs = elapsedMs(ruleStartedAtMs);
    const ruleOnBatchMs = onBatchMs - ruleOnBatchStartedMs;
    ruleSummaries.push({
      marker: rule.marker || rule.name || 'G',
      source: rule.source,
      target: rule.target,
      toleranceMm,
      sourceObjectCount: sourceIndices.length,
      targetObjectCount: targetIndices.length,
      testedPairCount,
      ignoredByTypePolicy: ignoredByTypeRule,
      aabbCheckCount: aabbStats.aabbCheckCount,
      aggregateTreeFilteredCount: aabbStats.aggregateTreeFilteredCount,
      sweepPrunedCount: Math.max(
        testedPairCount - aabbStats.aabbCheckCount - aabbStats.aggregateTreeFilteredCount,
        0,
      ),
      aabbEnumeration: useAabbSweep ? 'sweep-and-prune' : 'brute-force',
      sweepAxis: useAabbSweep ? aabbStats.sweepAxis : null,
      spatialCandidateCount: ruleSpatialCandidateCount,
      selfPairFilteredCount: ruleSelfPairFilteredCount,
      obbFilteredCount: ruleObbFilteredCount,
      spatialLevelFilteredCount: ruleSpatialLevelFilteredCount,
      spatialLevelUnknownKeptCount: ruleSpatialLevelUnknownKeptCount,
      sameSystemFilteredCount: ruleSameSystemFilteredCount,
      sameSystemFilteredByLevel: ruleSameSystemFilteredByLevel,
      semanticFilteredCount: ruleSemanticFilteredCount,
      semanticFilteredByLevel: ruleSemanticFilteredByLevel,
      candidateCount: ruleCandidateCount,
      timing: {
        durationMs: ruleDurationMs,
        scanMs: roundMs(Math.max(ruleDurationMs - ruleOnBatchMs, 0)),
        onBatchMs: roundMs(ruleOnBatchMs),
      },
    });

    if (verboseProgress && ruleSpatialCandidateCount >= heavyRuleSpatialThreshold) {
      console.error(
        `[broad] HEAVY rule ${ruleIndex}/${rules.length}: `
        + `${rule.source?.discipline || '?'}/${sourceEntityType || '?'} x `
        + `${rule.target?.discipline || '?'}/${targetEntityType || '?'} | `
        + `objs ${sourceIndices.length}x${targetIndices.length} `
        + `spatial=${ruleSpatialCandidateCount} tree=${aabbStats.aggregateTreeFilteredCount} self=${ruleSelfPairFilteredCount} obb=${ruleObbFilteredCount} sameSys=${ruleSameSystemFilteredCount} `
        + `semantic=${ruleSemanticFilteredCount} spatialLevel=${ruleSpatialLevelFilteredCount} `
        + `-> candidates=${ruleCandidateCount} (${roundMs(ruleDurationMs)}ms)`,
      );
    }
  }

  await flushBatch();

  const durationMs = elapsedMs(timingStartedAtMs);

  return {
    basePath: dataset.basePath,
    objectCount: dataset.objects.length,
    exceptionCount: dataset.exceptions.length,
    ruleCount: rules.length,
    testedPairCount: totalTheoreticalPairCount,
    aabbCheckCount: totalAabbCheckCount,
    aggregateTreeFilteredCount,
    sweepPrunedCount: Math.max(
      totalTheoreticalPairCount - totalAabbCheckCount - aggregateTreeFilteredCount,
      0,
    ),
    aabbEnumeration: useAabbSweep ? 'sweep-and-prune' : 'brute-force',
    spatialCandidateCount: totalSpatialCandidateCount,
    selfPairFilteredCount,
    useObbRefinement,
    obbFilteredCount,
    sameSystemFilteredCount,
    sameSystemFilteredByLevel,
    semanticFilteredCount,
    semanticFilteredByLevel,
    ignoreSameSystem,
    ignoreCoversBldgElements,
    ignoreConnectsPathElements,
    ignoreSpacesAndOpenings,
    spatialLevelFilter: serializeSpatialLevelFilter(spatialLevelFilter),
    spatialLevelFilteredCount,
    spatialLevelUnknownKeptCount,
    ignoreHostOpeningFill,
    ignorePortConnected,
    candidateCount: totalCandidateCount,
    batchCount,
    batchSize,
    ruleSummaries,
    coverageExclusionCount,
    coverageExclusionsTruncated,
    coverageExclusions,
    timing: {
      durationMs,
      scanMs: roundMs(Math.max(durationMs - onBatchMs, 0)),
      onBatchMs: roundMs(onBatchMs),
    },
  };
}

export async function runBroadPhaseDetection(dataset, matrix, options = {}) {
  return runBroadPhaseCandidateBatches(dataset, matrix, {
    batchSize: options.batchSize,
    ignoreSameSystem: options.ignoreSameSystem,
    ignoreCoversBldgElements: options.ignoreCoversBldgElements,
    ignoreConnectsPathElements: options.ignoreConnectsPathElements,
    ignoreHostOpeningFill: options.ignoreHostOpeningFill,
    ignorePortConnected: options.ignorePortConnected,
    ignoreSpacesAndOpenings: options.ignoreSpacesAndOpenings,
    spatialLevelFilter: options.spatialLevelFilter,
    useAabbSweep: options.useAabbSweep,
    onBatch: async () => {},
  });
}
