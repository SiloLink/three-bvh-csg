const EPSILON = 1e-12;

function toFinitePoint2D(point) {
  const x = Number(point?.[0] ?? point?.x);
  const y = Number(point?.[1] ?? point?.y);
  return Number.isFinite(x) && Number.isFinite(y) ? [x, y] : null;
}

function toFinitePoint3D(point) {
  const x = Number(point?.[0] ?? point?.x);
  const y = Number(point?.[1] ?? point?.y);
  const z = Number(point?.[2] ?? point?.z);
  return Number.isFinite(x) && Number.isFinite(y) && Number.isFinite(z) ? [x, y, z] : null;
}

function normalizeAngleDeg(angleRad) {
  let degrees = (angleRad * 180) / Math.PI;
  degrees %= 180;
  if (degrees < 0) {
    degrees += 180;
  }
  return degrees;
}

function dot2(a, b) {
  return a.x * b.x + a.y * b.y;
}

function rectInFrame(points, angleRad) {
  const ux = Math.cos(angleRad);
  const uy = Math.sin(angleRad);
  const vx = -uy;
  const vy = ux;
  let minU = Infinity;
  let maxU = -Infinity;
  let minV = Infinity;
  let maxV = -Infinity;

  for (const point of points) {
    const du = point[0] * ux + point[1] * uy;
    const dv = point[0] * vx + point[1] * vy;
    minU = Math.min(minU, du);
    maxU = Math.max(maxU, du);
    minV = Math.min(minV, dv);
    maxV = Math.max(maxV, dv);
  }

  const spanU = maxU - minU;
  const spanV = maxV - minV;
  const centerU = (minU + maxU) / 2;
  const centerV = (minV + maxV) / 2;
  const uAxis = { x: ux, y: uy };
  const vAxis = { x: vx, y: vy };
  const longAxisIsU = spanU >= spanV;
  const xAxis = longAxisIsU ? uAxis : vAxis;
  const yAxis = longAxisIsU ? vAxis : uAxis;
  const angleOfLong = longAxisIsU ? angleRad : angleRad + Math.PI / 2;

  return {
    length: Math.max(spanU, spanV),
    width: Math.min(spanU, spanV),
    area: spanU * spanV,
    angleRad: angleOfLong,
    angleDeg: normalizeAngleDeg(angleOfLong),
    center: {
      x: centerU * ux + centerV * vx,
      y: centerU * uy + centerV * vy,
    },
    axes: {
      x: xAxis,
      y: yAxis,
    },
    halfExtents: {
      x: Math.max(spanU, spanV) / 2,
      y: Math.min(spanU, spanV) / 2,
    },
  };
}

export function convexHull2D(points) {
  const sortedPoints = (Array.isArray(points) ? points : [])
    .map(toFinitePoint2D)
    .filter(Boolean)
    .sort((a, b) => (a[0] - b[0]) || (a[1] - b[1]));
  const uniquePoints = [];

  for (const point of sortedPoints) {
    const last = uniquePoints[uniquePoints.length - 1];
    if (
      !last
      || Math.abs(last[0] - point[0]) > EPSILON
      || Math.abs(last[1] - point[1]) > EPSILON
    ) {
      uniquePoints.push(point);
    }
  }

  if (uniquePoints.length <= 2) {
    return uniquePoints;
  }

  function cross(origin, a, b) {
    return (a[0] - origin[0]) * (b[1] - origin[1])
      - (a[1] - origin[1]) * (b[0] - origin[0]);
  }

  const lower = [];
  for (const point of uniquePoints) {
    while (
      lower.length >= 2
      && cross(lower[lower.length - 2], lower[lower.length - 1], point) <= 0
    ) {
      lower.pop();
    }
    lower.push(point);
  }

  const upper = [];
  for (let index = uniquePoints.length - 1; index >= 0; index -= 1) {
    const point = uniquePoints[index];
    while (
      upper.length >= 2
      && cross(upper[upper.length - 2], upper[upper.length - 1], point) <= 0
    ) {
      upper.pop();
    }
    upper.push(point);
  }

  lower.pop();
  upper.pop();
  return lower.concat(upper);
}

export function minimumAreaRect2D(points) {
  const hull = convexHull2D(points);
  if (hull.length === 0) {
    return {
      length: 0,
      width: 0,
      area: 0,
      angleDeg: 0,
      center: { x: 0, y: 0 },
      axes: { x: { x: 1, y: 0 }, y: { x: 0, y: 1 } },
      halfExtents: { x: 0, y: 0 },
      hull,
    };
  }
  if (hull.length === 1) {
    return {
      length: 0,
      width: 0,
      area: 0,
      angleDeg: 0,
      center: { x: hull[0][0], y: hull[0][1] },
      axes: { x: { x: 1, y: 0 }, y: { x: 0, y: 1 } },
      halfExtents: { x: 0, y: 0 },
      hull,
    };
  }

  let best = null;
  for (let index = 0; index < hull.length; index += 1) {
    const a = hull[index];
    const b = hull[(index + 1) % hull.length];
    const dx = b[0] - a[0];
    const dy = b[1] - a[1];
    if (Math.abs(dx) < EPSILON && Math.abs(dy) < EPSILON) {
      continue;
    }

    const rect = rectInFrame(hull, Math.atan2(dy, dx));
    if (!best || rect.area < best.area) {
      best = rect;
    }
  }

  return {
    ...(best || rectInFrame(hull, 0)),
    hull,
  };
}

export function minimumAreaRect2DBySweep(points, stepDeg = 0.25) {
  const hull = convexHull2D(points);
  if (hull.length <= 1) {
    return minimumAreaRect2D(hull);
  }

  let best = null;
  for (let degrees = 0; degrees < 90; degrees += stepDeg) {
    const rect = rectInFrame(hull, (degrees * Math.PI) / 180);
    if (!best || rect.area < best.area) {
      best = rect;
    }
  }

  return {
    ...best,
    hull,
  };
}

export function computeOrientedClashSize(points3D) {
  const points = (Array.isArray(points3D) ? points3D : []).map(toFinitePoint3D).filter(Boolean);
  if (points.length === 0) {
    return {
      x: 0,
      y: 0,
      z: 0,
      length: 0,
      width: 0,
      height: 0,
      angleDeg: 0,
    };
  }

  let minZ = Infinity;
  let maxZ = -Infinity;
  const points2D = points.map(point => {
    minZ = Math.min(minZ, point[2]);
    maxZ = Math.max(maxZ, point[2]);
    return [point[0], point[1]];
  });
  const rect = minimumAreaRect2D(points2D);
  const height = maxZ - minZ;

  return {
    x: rect.length,
    y: rect.width,
    z: height,
    length: rect.length,
    width: rect.width,
    height,
    angleDeg: rect.angleDeg,
  };
}

export function computeHorizontalObb(points3D) {
  const points = (Array.isArray(points3D) ? points3D : []).map(toFinitePoint3D).filter(Boolean);
  if (points.length === 0) {
    return null;
  }

  let minZ = Infinity;
  let maxZ = -Infinity;
  const points2D = points.map(point => {
    minZ = Math.min(minZ, point[2]);
    maxZ = Math.max(maxZ, point[2]);
    return [point[0], point[1]];
  });
  const rect = minimumAreaRect2D(points2D);

  return {
    center: {
      x: rect.center.x,
      y: rect.center.y,
      z: (minZ + maxZ) / 2,
    },
    axes: rect.axes,
    halfExtents: {
      x: rect.halfExtents.x,
      y: rect.halfExtents.y,
      z: (maxZ - minZ) / 2,
    },
    minZ,
    maxZ,
    angleDeg: rect.angleDeg,
  };
}

export function intersectsHorizontalObb(left, right) {
  if (!left || !right) {
    return false;
  }

  if (left.minZ > right.maxZ || left.maxZ < right.minZ) {
    return false;
  }

  const centerDelta = {
    x: right.center.x - left.center.x,
    y: right.center.y - left.center.y,
  };
  const testAxes = [
    left.axes.x,
    left.axes.y,
    right.axes.x,
    right.axes.y,
  ];

  for (const axis of testAxes) {
    const distance = Math.abs(dot2(centerDelta, axis));
    const leftRadius = left.halfExtents.x * Math.abs(dot2(left.axes.x, axis))
      + left.halfExtents.y * Math.abs(dot2(left.axes.y, axis));
    const rightRadius = right.halfExtents.x * Math.abs(dot2(right.axes.x, axis))
      + right.halfExtents.y * Math.abs(dot2(right.axes.y, axis));
    if (distance > leftRadius + rightRadius) {
      return false;
    }
  }

  return true;
}
