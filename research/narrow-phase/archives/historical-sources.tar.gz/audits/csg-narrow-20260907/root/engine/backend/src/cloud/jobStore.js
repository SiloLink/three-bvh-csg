import crypto from 'node:crypto';

export const ACTIVE_STATUSES = new Set(['starting', 'running', 'canceling']);
export const TERMINAL_STATUSES = new Set(['succeeded', 'failed', 'canceled']);
const MATRIX_STORAGE_KIND = 'firestore-subcollection';
const MATRIX_CHUNK_PAIR_COUNT = 500;
const CURRENT_REQUEST_HASH_CONTRACT = 'current';
const LEGACY_REQUEST_HASH_CONTRACT = 'legacy';

function nowIso() {
  return new Date().toISOString();
}

function addMs(ms) {
  return new Date(Date.now() + ms).toISOString();
}

function parseTime(value) {
  const millis = Date.parse(value || '');
  return Number.isFinite(millis) ? millis : 0;
}

function clone(value) {
  return value ? JSON.parse(JSON.stringify(value)) : value;
}

function pickNumber(value) {
  return Number.isFinite(value) ? Number(value.toFixed(3)) : null;
}

function summarizeBatchTiming(batchTiming) {
  if (!batchTiming || typeof batchTiming !== 'object') {
    return null;
  }

  return {
    batchNumber: batchTiming.batchNumber ?? null,
    candidateCount: batchTiming.candidateCount ?? null,
    resultCount: batchTiming.resultCount ?? null,
    reportRowCount: batchTiming.reportRowCount ?? null,
    workerDurationMs: pickNumber(batchTiming.workerDurationMs),
    reportWriteDurationMs: pickNumber(batchTiming.reportWriteDurationMs),
    durationMs: pickNumber(batchTiming.durationMs),
  };
}

function compactTiming(timing) {
  if (!timing || typeof timing !== 'object') {
    return timing;
  }

  const compact = { ...timing };
  if (Array.isArray(timing.batchTimings)) {
    compact.batchCount = timing.batchTimings.length;
    compact.lastBatch = summarizeBatchTiming(timing.batchTimings.at(-1));
    delete compact.batchTimings;
  }
  return compact;
}

function compactNarrowPhase(narrowPhase) {
  if (!narrowPhase || typeof narrowPhase !== 'object') {
    return narrowPhase;
  }

  const compact = { ...narrowPhase };
  if (narrowPhase.timing !== undefined) {
    compact.timing = compactTiming(narrowPhase.timing);
  } else {
    delete compact.timing;
  }

  if (Array.isArray(narrowPhase.batchTimings)) {
    compact.batchCount = narrowPhase.batchTimings.length;
    compact.lastBatch = summarizeBatchTiming(narrowPhase.batchTimings.at(-1));
    delete compact.batchTimings;
  }

  return compact;
}

function compactBroadPhase(broadPhase) {
  if (!broadPhase || typeof broadPhase !== 'object') {
    return broadPhase;
  }

  const compact = { ...broadPhase };
  if (Array.isArray(broadPhase.ruleSummaries)) {
    compact.ruleSummaryCount = broadPhase.ruleSummaries.length;
    delete compact.ruleSummaries;
  }
  return compact;
}

function getMatrixPayload(job) {
  if (Array.isArray(job?.matrix?.enabledPairs)) {
    return job.matrix;
  }
  if (Array.isArray(job?.request?.matrix?.enabledPairs)) {
    return job.request.matrix;
  }
  return null;
}

function summarizeMatrix(matrix) {
  if (!matrix || typeof matrix !== 'object') {
    return matrix;
  }

  const enabledPairs = Array.isArray(matrix.enabledPairs) ? matrix.enabledPairs : [];
  return {
    options: matrix.options || {},
    enabledPairCount: enabledPairs.length,
    storage: enabledPairs.length > 0 ? MATRIX_STORAGE_KIND : null,
    chunkCount: Math.ceil(enabledPairs.length / MATRIX_CHUNK_PAIR_COUNT),
  };
}

function createPersistedJobDocument(job) {
  const matrix = getMatrixPayload(job);
  const persisted = {
    ...job,
    request: {
      ...(job.request || {}),
    },
  };
  delete persisted.matrix;
  if (matrix) {
    persisted.request.matrix = summarizeMatrix(matrix);
  }
  return persisted;
}

function createMatrixChunks(matrix) {
  const enabledPairs = Array.isArray(matrix?.enabledPairs) ? matrix.enabledPairs : [];
  const chunks = [];
  for (let index = 0; index < enabledPairs.length; index += MATRIX_CHUNK_PAIR_COUNT) {
    const chunkIndex = chunks.length;
    const chunkPairs = enabledPairs.slice(index, index + MATRIX_CHUNK_PAIR_COUNT);
    chunks.push({
      chunkIndex,
      pairStart: index,
      pairCount: chunkPairs.length,
      enabledPairs: chunkPairs,
    });
  }
  return chunks;
}

function matrixFromChunks(job, chunks) {
  const sortedChunks = [...chunks].sort((a, b) => a.chunkIndex - b.chunkIndex);
  const expectedChunkCount = job?.request?.matrix?.chunkCount;
  if (Number.isInteger(expectedChunkCount) && sortedChunks.length !== expectedChunkCount) {
    const error = new Error(
      `Clash matrix is incomplete: expected ${expectedChunkCount} chunks, found ${sortedChunks.length}.`,
    );
    error.code = 'CLASH_MATRIX_INCOMPLETE';
    throw error;
  }
  for (let index = 0; index < sortedChunks.length; index += 1) {
    const chunk = sortedChunks[index];
    if (
      chunk.chunkIndex !== index
      || chunk.pairStart !== index * MATRIX_CHUNK_PAIR_COUNT
      || !Array.isArray(chunk.enabledPairs)
      || chunk.pairCount !== chunk.enabledPairs.length
    ) {
      const error = new Error(`Clash matrix chunk ${index} is invalid or out of sequence.`);
      error.code = 'CLASH_MATRIX_INCOMPLETE';
      throw error;
    }
  }
  const enabledPairs = sortedChunks
    .flatMap(chunk => chunk.enabledPairs);
  const expectedPairCount = job?.request?.matrix?.enabledPairCount;
  if (Number.isInteger(expectedPairCount) && enabledPairs.length !== expectedPairCount) {
    const error = new Error(
      `Clash matrix is incomplete: expected ${expectedPairCount} pairs, found ${enabledPairs.length}.`,
    );
    error.code = 'CLASH_MATRIX_INCOMPLETE';
    throw error;
  }
  if (enabledPairs.length === 0) {
    return null;
  }
  return {
    enabledPairs,
    options: job?.request?.matrix?.options || {},
  };
}

function safeDocId(value) {
  return encodeURIComponent(String(value));
}

function legacyIdempotencyDocId(ownerId, clientRequestId) {
  const hash = crypto.createHash('sha256').update(String(clientRequestId)).digest('hex');
  return `${safeDocId(ownerId)}_${hash}`;
}

function idempotencyDocId(ownerId, tenantId, clientRequestId) {
  const identity = JSON.stringify([
    String(ownerId),
    String(tenantId),
    String(clientRequestId),
  ]);
  const hash = crypto.createHash('sha256').update(identity).digest('hex');
  return `v2_${hash}`;
}

function jobMatchesIdentity(job, ownerId, tenantId) {
  return job?.ownerId === ownerId && job?.tenantId === tenantId;
}

export function matchesIdempotencyRequest(
  existing,
  { requestHash, legacyRequestHash },
) {
  if (existing?.requestHashContract === CURRENT_REQUEST_HASH_CONTRACT) {
    return existing.record?.requestHash === requestHash;
  }
  if (existing?.requestHashContract === LEGACY_REQUEST_HASH_CONTRACT) {
    return existing.record?.requestHash === legacyRequestHash;
  }
  throw new Error('Idempotency record has an unknown request hash contract.');
}

export function isActiveStatus(status) {
  return ACTIVE_STATUSES.has(status);
}

export function isTerminalStatus(status) {
  return TERMINAL_STATUSES.has(status);
}

function isExternalExecutionName(executionName) {
  return Boolean(
    executionName
    && !String(executionName).startsWith('local-inline:'),
  );
}

function isProjectBlockingJob(job) {
  return Boolean(job && (isActiveStatus(job.status) || job.executionCleanupPending));
}

export function createLease(config) {
  return {
    leaseToken: crypto.randomUUID(),
    leaseExpiresAt: addMs(config.startLeaseMs),
    startToken: crypto.randomUUID(),
  };
}

export function createJobDocument({
  jobId = crypto.randomUUID(),
  caller,
  request,
  requestHash,
  lease,
  config,
  resultUri,
  tempResultUri,
  cloudRunJobName,
}) {
  const timestamp = nowIso();
  const batchSizeLimit = request.batchSizeLimit;
  if (!Number.isInteger(batchSizeLimit) || batchSizeLimit < 1) {
    throw new Error('request.batchSizeLimit must be a positive integer.');
  }

  return {
    jobId,
    projectGuid: request.projectGuid,
    detectionIdentity: request.detectionIdentity || null,
    ownerId: caller.ownerId,
    tenantId: caller.tenantId,
    clientRequestId: request.clientRequestId,
    requestHash,
    request: {
      models: request.models,
      matrix: summarizeMatrix(request.matrix),
      spatialLevelFilter: request.spatialLevelFilter || null,
      batchSize: request.batchSize,
      batchSizeLimit,
      outputUri: request.outputUri || null,
      outputPrefix: request.outputPrefix || null,
    },
    matrix: request.matrix,
    batchSizeLimit,
    spatialLevelFilter: request.spatialLevelFilter || null,
    models: request.models,
    batchSize: request.batchSize,
    outputUri: request.outputUri || null,
    outputPrefix: request.outputPrefix || null,
    progressCorrelationId: request.progressCorrelationId || null,
    status: 'starting',
    statusReason: 'accepted',
    createdAt: timestamp,
    updatedAt: timestamp,
    startedAt: null,
    finishedAt: null,
    startAttempts: 1,
    nextStartAttemptAt: null,
    leaseOwner: 'api',
    leaseToken: lease.leaseToken,
    leaseExpiresAt: lease.leaseExpiresAt,
    startToken: lease.startToken,
    jobName: cloudRunJobName || config.cloudRunJobName || null,
    executionName: null,
    taskIndex: null,
    taskAttempt: null,
    stage: 'starting',
    message: 'Cloud Run job is being started.',
    heartbeatAt: timestamp,
    progress: {
      percent: null,
      stage: 'starting',
      message: 'Cloud Run job is being started.',
    },
    broadPhase: null,
    narrowPhase: null,
    resultUri: resultUri || null,
    tempResultUri: tempResultUri || null,
    outputPath: null,
    resultSizeBytes: null,
    resultRowCount: null,
    detectedPairs: null,
    evaluatedCoverageUri: null,
    evaluatedCoverageDigest: null,
    evaluatedCoverageSchemaVersion: null,
    evaluatedCoverageSizeBytes: null,
    evaluatedCoverageError: null,
    cancelRequested: false,
    cancelRequestedAt: null,
    cancelRequestedBy: null,
    cancelAttemptedAt: null,
    executionCleanupPending: false,
    executionCleanupAttemptCount: 0,
    executionCleanupNextAttemptAt: null,
    executionCleanupLastError: null,
    executionCleanupCompletedAt: null,
    executionLookupFailureCount: 0,
    executionLookupFirstFailedAt: null,
    executionLookupLastFailedAt: null,
    executionLookupNextAttemptAt: null,
    executionLookupLastError: null,
    executionLookupLastSucceededAt: null,
    error: null,
    schemaVersion: 1,
    updatedBy: 'api',
    capacityClaimed: config.globalCapacityEnabled,
    capacityReleased: !config.globalCapacityEnabled,
  };
}

function makeProjectLock(job) {
  return {
    activeJobId: job.jobId,
    activeStatus: job.status,
    activeStartedAt: job.createdAt,
    activeUpdatedAt: job.updatedAt,
    leaseToken: job.leaseToken,
    leaseExpiresAt: job.leaseExpiresAt,
    ownerId: job.ownerId,
    tenantId: job.tenantId,
  };
}

function applyProgressPatch(job, progressPatch = {}) {
  return {
    ...job,
    ...createProgressUpdate(job, progressPatch),
  };
}

export function createProgressUpdate(job, progressPatch = {}) {
  const timestamp = nowIso();
  const stage = progressPatch.stage || job.stage;
  const message = progressPatch.message || job.message;
  const progressValues = progressPatch.progress && typeof progressPatch.progress === 'object'
    ? progressPatch.progress
    : {};
  const nextProgress = {
    ...(job.progress || {}),
    ...progressValues,
    stage,
    message,
  };

  const update = {
    updatedAt: timestamp,
    heartbeatAt: progressPatch.heartbeatAt || timestamp,
    stage,
    message,
    progress: nextProgress,
    updatedBy: 'worker',
  };
  if (progressPatch.broadPhase) {
    update.broadPhase = compactBroadPhase(progressPatch.broadPhase);
  }
  if (progressPatch.narrowPhase) {
    update.narrowPhase = compactNarrowPhase(progressPatch.narrowPhase);
  }

  return update;
}

function withStartFailure(job, error) {
  const timestamp = nowIso();
  const failedJob = {
    ...job,
    status: 'failed',
    statusReason: 'start_failed',
    updatedAt: timestamp,
    finishedAt: timestamp,
    stage: 'failed',
    message: error?.message || 'Failed to start Cloud Run job.',
    error: {
      code: error?.code || 'CLASH_JOB_START_FAILED',
      message: error?.message || String(error),
      stack: error?.stack || null,
      phase: error?.phase || 'start',
      retryable: error?.retryable ?? true,
    },
    updatedBy: 'api',
  };
  return isExternalExecutionName(failedJob.executionName)
    ? withExecutionCleanupPending(failedJob)
    : failedJob;
}

function withCloudRunStarted(job, { executionName, jobName }) {
  const startedJob = {
    ...job,
    executionName: job.executionName || executionName,
    jobName: jobName || job.jobName,
    updatedAt: nowIso(),
    updatedBy: 'api',
  };
  return (
    isExternalExecutionName(startedJob.executionName)
    && (isTerminalStatus(job.status) || job.cancelRequested || job.status === 'canceling')
  )
    ? withExecutionCleanupPending(startedJob)
    : startedJob;
}

function withRunningState(job, { executionName, taskIndex, taskAttempt }) {
  const timestamp = nowIso();
  return {
    ...job,
    status: job.status === 'starting' ? 'running' : job.status,
    startedAt: job.startedAt || timestamp,
    updatedAt: timestamp,
    heartbeatAt: timestamp,
    executionName: job.executionName || executionName,
    taskIndex: taskIndex ?? job.taskIndex,
    taskAttempt: taskAttempt ?? job.taskAttempt,
    stage: job.status === 'canceling' ? 'canceling' : 'running',
    message: job.status === 'canceling' ? 'Cancellation requested.' : 'Worker is running.',
    updatedBy: 'worker',
  };
}

function withCancellationRequested(job, caller) {
  const timestamp = nowIso();
  const canceledJob = {
    ...job,
    status: 'canceling',
    statusReason: 'cancel_requested',
    cancelRequested: true,
    cancelRequestedAt: job.cancelRequestedAt || timestamp,
    cancelRequestedBy: job.cancelRequestedBy || caller.ownerId,
    updatedAt: timestamp,
    stage: 'canceling',
    message: 'Cancellation requested.',
    updatedBy: 'api',
  };
  return isExternalExecutionName(canceledJob.executionName)
    ? withExecutionCleanupPending(canceledJob)
    : canceledJob;
}

function withExecutionCleanupPending(job) {
  if (!isExternalExecutionName(job.executionName)) {
    return job;
  }
  const timestamp = nowIso();
  return {
    ...job,
    executionCleanupPending: true,
    executionCleanupAttemptCount: job.executionCleanupPending
      ? job.executionCleanupAttemptCount || 0
      : 0,
    executionCleanupNextAttemptAt: job.executionCleanupPending
      ? job.executionCleanupNextAttemptAt || timestamp
      : timestamp,
    executionCleanupLastError: job.executionCleanupPending
      ? job.executionCleanupLastError || null
      : null,
    executionCleanupCompletedAt: null,
    updatedAt: timestamp,
  };
}

function withExecutionCleanupAttempt(job, config, error) {
  const timestamp = nowIso();
  const attemptCount = (job.executionCleanupAttemptCount || 0) + 1;
  const initialDelay = Math.max(0, config.cancelRetryInitialMs ?? 30_000);
  const maxDelay = Math.max(initialDelay, config.cancelRetryMaxMs ?? 15 * 60_000);
  const delay = Math.min(maxDelay, initialDelay * (2 ** Math.min(attemptCount - 1, 20)));
  return {
    ...job,
    cancelAttemptedAt: timestamp,
    executionCleanupPending: true,
    executionCleanupAttemptCount: attemptCount,
    executionCleanupNextAttemptAt: new Date(Date.parse(timestamp) + delay).toISOString(),
    executionCleanupLastError: error ? error.message || String(error) : null,
    updatedAt: timestamp,
  };
}

function withExecutionCleanupComplete(job) {
  const timestamp = nowIso();
  return {
    ...job,
    executionCleanupPending: false,
    executionCleanupNextAttemptAt: null,
    executionCleanupLastError: null,
    executionCleanupCompletedAt: timestamp,
    updatedAt: timestamp,
  };
}

function withExecutionLookupFailure(job, config, error) {
  const timestamp = nowIso();
  const failureCount = (job.executionLookupFailureCount || 0) + 1;
  const initialDelay = Math.max(
    0,
    config.executionLookupRetryInitialMs,
  );
  const maxDelay = Math.max(
    initialDelay,
    config.executionLookupRetryMaxMs,
  );
  const delay = Math.min(
    maxDelay,
    initialDelay * (2 ** Math.min(failureCount - 1, 20)),
  );
  return {
    ...job,
    executionLookupFailureCount: failureCount,
    executionLookupFirstFailedAt: job.executionLookupFirstFailedAt || timestamp,
    executionLookupLastFailedAt: timestamp,
    executionLookupNextAttemptAt: new Date(Date.parse(timestamp) + delay).toISOString(),
    executionLookupLastError: error,
    updatedAt: timestamp,
  };
}

function withExecutionLookupSuccess(job) {
  const timestamp = nowIso();
  return {
    ...job,
    executionLookupFailureCount: 0,
    executionLookupFirstFailedAt: null,
    executionLookupLastFailedAt: null,
    executionLookupNextAttemptAt: null,
    executionLookupLastError: null,
    executionLookupLastSucceededAt: timestamp,
    updatedAt: timestamp,
  };
}

function withTerminalState(job, {
  status,
  result = {},
  error = null,
  updatedBy = 'worker',
  executionTerminalConfirmed = false,
}) {
  const timestamp = nowIso();
  const isSuccess = status === 'succeeded';
  const isCanceled = status === 'canceled';

  const terminalJob = {
    ...job,
    status,
    statusReason: isSuccess ? 'completed' : status,
    updatedAt: timestamp,
    finishedAt: timestamp,
    stage: status,
    message: isSuccess ? 'Report completed.' : (error?.message || status),
    resultUri: isSuccess ? result.resultUri || job.resultUri : null,
    tempResultUri: result.tempResultUri || job.tempResultUri || null,
    outputPath: isSuccess ? result.outputPath || null : null,
    resultSizeBytes: isSuccess ? result.resultSizeBytes ?? null : null,
    resultRowCount: isSuccess ? result.resultRowCount ?? null : null,
    detectedPairs: isSuccess ? result.detectedPairs || null : null,
    evaluatedCoverageUri: isSuccess ? result.evaluatedCoverageUri || null : null,
    evaluatedCoverageDigest: isSuccess ? result.evaluatedCoverageDigest || null : null,
    evaluatedCoverageSchemaVersion: isSuccess
      ? result.evaluatedCoverageSchemaVersion || null
      : null,
    evaluatedCoverageSizeBytes: isSuccess
      ? result.evaluatedCoverageSizeBytes ?? null
      : null,
    evaluatedCoverageError: isSuccess ? result.evaluatedCoverageError || null : null,
    broadPhase: compactBroadPhase(result.broadPhase || job.broadPhase),
    narrowPhase: compactNarrowPhase(result.narrowPhase || job.narrowPhase),
    error: error && !isCanceled ? {
      code: error.code || 'CLASH_REPORT_FAILED',
      message: error.message || String(error),
      stack: error.stack || null,
      phase: error.phase || 'compute',
      retryable: error.retryable ?? false,
    } : null,
    updatedBy,
  };
  return executionTerminalConfirmed
    ? withExecutionCleanupComplete(terminalJob)
    : terminalJob;
}

class MemoryJobStore {
  constructor(config) {
    this.config = config;
    this.jobs = new Map();
    this.matrices = new Map();
    this.locks = new Map();
    this.idempotency = new Map();
    this.global = {
      runningCount: 0,
      maxRunning: config.maxGlobalRunningJobs,
      updatedAt: nowIso(),
    };
    this.lock = Promise.resolve();
  }

  async withLock(callback) {
    const previous = this.lock;
    let release;
    this.lock = new Promise(resolve => {
      release = resolve;
    });
    await previous;
    try {
      return await callback();
    } finally {
      release();
    }
  }

  async getJob(jobId) {
    return clone(this.jobs.get(jobId)) || null;
  }

  async getJobMatrix(jobOrJobId) {
    const jobId = typeof jobOrJobId === 'object' ? jobOrJobId?.jobId : jobOrJobId;
    const inlineMatrix = getMatrixPayload(typeof jobOrJobId === 'object' ? jobOrJobId : null);
    if (inlineMatrix) {
      return clone(inlineMatrix);
    }
    return clone(this.matrices.get(jobId)) || null;
  }

  async getIdempotentJob({ ownerId, tenantId, clientRequestId }) {
    if (!clientRequestId) {
      return null;
    }
    const existing = this.idempotency.get(idempotencyDocId(
      ownerId,
      tenantId,
      clientRequestId,
    ));
    if (!existing || parseTime(existing.expiresAt) <= Date.now()) {
      return null;
    }

    return {
      record: clone(existing),
      job: clone(this.jobs.get(existing.jobId)) || null,
      requestHashContract: CURRENT_REQUEST_HASH_CONTRACT,
    };
  }

  async claimJob({ job, clientRequestId, requestHash, legacyRequestHash }) {
    return this.withLock(async () => {
      if (clientRequestId) {
        const idemId = idempotencyDocId(job.ownerId, job.tenantId, clientRequestId);
        const existing = this.idempotency.get(idemId);
        if (existing && parseTime(existing.expiresAt) > Date.now()) {
          const existingJob = this.jobs.get(existing.jobId);
          const existingIdempotency = {
            record: existing,
            job: existingJob || null,
            requestHashContract: CURRENT_REQUEST_HASH_CONTRACT,
          };
          if (!matchesIdempotencyRequest(existingIdempotency, {
            requestHash,
            legacyRequestHash,
          })) {
            return { type: 'idempotency-conflict', job: clone(existingJob) || null };
          }

          return { type: 'idempotent', job: clone(existingJob) || null };
        }
      }

      const lock = this.locks.get(job.projectGuid);
      if (lock?.activeJobId) {
        const activeJob = this.jobs.get(lock.activeJobId);
        if (isProjectBlockingJob(activeJob)) {
          return { type: 'project-conflict', activeJob: clone(activeJob) };
        }
      }

      if (this.config.globalCapacityEnabled && this.global.runningCount >= this.global.maxRunning) {
        return { type: 'capacity-exceeded' };
      }

      const persistedJob = createPersistedJobDocument(job);
      const matrix = getMatrixPayload(job);
      if (matrix) {
        this.matrices.set(job.jobId, clone(matrix));
      }
      this.jobs.set(job.jobId, clone(persistedJob));
      this.locks.set(job.projectGuid, makeProjectLock(persistedJob));
      if (this.config.globalCapacityEnabled) {
        this.global.runningCount += 1;
        this.global.updatedAt = nowIso();
      }
      if (clientRequestId) {
        this.idempotency.set(idempotencyDocId(job.ownerId, job.tenantId, clientRequestId), {
          ownerId: job.ownerId,
          tenantId: job.tenantId,
          clientRequestId,
          requestHash,
          jobId: job.jobId,
          createdAt: persistedJob.createdAt,
          expiresAt: addMs(this.config.idempotencyRetentionMs),
        });
      }

      return { type: 'created', job: clone(persistedJob) };
    });
  }

  async updateLockForJob(job) {
    const lock = this.locks.get(job.projectGuid);
    if (lock?.activeJobId === job.jobId) {
      this.locks.set(job.projectGuid, {
        ...lock,
        activeStatus: job.status,
        activeUpdatedAt: job.updatedAt,
        leaseToken: job.leaseToken,
        leaseExpiresAt: job.leaseExpiresAt,
      });
    } else if (!lock && job.executionCleanupPending) {
      this.locks.set(job.projectGuid, makeProjectLock(job));
    }
  }

  async recordCloudRunStarted({ jobId, executionName, jobName }) {
    return this.withLock(async () => {
      const job = this.jobs.get(jobId);
      if (!job) {
        return null;
      }
      const nextJob = withCloudRunStarted(job, { executionName, jobName });
      this.jobs.set(jobId, nextJob);
      await this.updateLockForJob(nextJob);
      return clone(nextJob);
    });
  }

  async markStartFailed({ jobId, error }) {
    return this.withLock(async () => {
      const job = this.jobs.get(jobId);
      if (!job || isTerminalStatus(job.status)) {
        return clone(job) || null;
      }
      const nextJob = withStartFailure(job, error);
      this.jobs.set(jobId, nextJob);
      const releasedJob = await this.releaseCapacityAndLock(nextJob);
      return clone(releasedJob);
    });
  }

  async markRunning({ jobId, startToken, executionName, taskIndex, taskAttempt }) {
    return this.withLock(async () => {
      const job = this.jobs.get(jobId);
      if (!job || job.startToken !== startToken || isTerminalStatus(job.status)) {
        return { type: 'stale', job: clone(job) || null };
      }

      const nextJob = withRunningState(job, { executionName, taskIndex, taskAttempt });
      this.jobs.set(jobId, nextJob);
      await this.updateLockForJob(nextJob);
      return { type: 'updated', job: clone(nextJob) };
    });
  }

  async patchProgress({ jobId, startToken, progressPatch }) {
    return this.withLock(async () => {
      const job = this.jobs.get(jobId);
      if (!job || job.startToken !== startToken || isTerminalStatus(job.status)) {
        return clone(job) || null;
      }
      const nextJob = applyProgressPatch(job, progressPatch);
      this.jobs.set(jobId, nextJob);
      return clone(nextJob);
    });
  }

  async requestCancel({ jobId, caller }) {
    return this.withLock(async () => {
      const job = this.jobs.get(jobId);
      if (!job || isTerminalStatus(job.status)) {
        return clone(job) || null;
      }
      const nextJob = withCancellationRequested(job, caller);
      this.jobs.set(jobId, nextJob);
      await this.updateLockForJob(nextJob);
      return clone(nextJob);
    });
  }

  async ensureExecutionCleanupPending({ jobId }) {
    return this.withLock(async () => {
      const job = this.jobs.get(jobId);
      if (
        !job
        || !isActiveStatus(job.status)
        || !isExternalExecutionName(job.executionName)
      ) {
        return clone(job) || null;
      }
      const nextJob = withExecutionCleanupPending(job);
      this.jobs.set(jobId, nextJob);
      await this.updateLockForJob(nextJob);
      return clone(nextJob);
    });
  }

  async recordExecutionCleanupAttempt({ jobId, error = null }) {
    return this.withLock(async () => {
      const job = this.jobs.get(jobId);
      if (
        !job
        || !isExternalExecutionName(job.executionName)
        || !job.executionCleanupPending
      ) {
        return clone(job) || null;
      }
      const nextJob = withExecutionCleanupAttempt(job, this.config, error);
      this.jobs.set(jobId, nextJob);
      await this.updateLockForJob(nextJob);
      return clone(nextJob);
    });
  }

  async recordExecutionLookupFailure({ jobId, error }) {
    return this.withLock(async () => {
      const job = this.jobs.get(jobId);
      if (!job || !isActiveStatus(job.status)) {
        return clone(job) || null;
      }
      const nextJob = withExecutionLookupFailure(job, this.config, error);
      this.jobs.set(jobId, nextJob);
      return clone(nextJob);
    });
  }

  async recordExecutionLookupSuccess({ jobId }) {
    return this.withLock(async () => {
      const job = this.jobs.get(jobId);
      if (!job || !isActiveStatus(job.status)) {
        return clone(job) || null;
      }
      const nextJob = withExecutionLookupSuccess(job);
      this.jobs.set(jobId, nextJob);
      return clone(nextJob);
    });
  }

  async completeExecutionCleanup({ jobId }) {
    return this.withLock(async () => {
      const job = this.jobs.get(jobId);
      if (!job) {
        return null;
      }
      if (!isTerminalStatus(job.status) || !job.executionCleanupPending) {
        return clone(job);
      }
      const nextJob = withExecutionCleanupComplete(job);
      this.jobs.set(jobId, nextJob);
      const releasedJob = await this.releaseCapacityAndLock(nextJob);
      return clone(releasedJob);
    });
  }

  async markTerminal({
    jobId,
    startToken,
    status,
    result,
    error,
    updatedBy,
    executionTerminalConfirmed,
  }) {
    return this.withLock(async () => {
      const job = this.jobs.get(jobId);
      if (!job || isTerminalStatus(job.status)) {
        return { type: 'unchanged', job: clone(job) || null };
      }
      if (startToken && job.startToken !== startToken) {
        return { type: 'stale', job: clone(job) };
      }

      const nextJob = withTerminalState(job, {
        status,
        result,
        error,
        updatedBy,
        executionTerminalConfirmed,
      });
      this.jobs.set(jobId, nextJob);
      const releasedJob = await this.releaseCapacityAndLock(nextJob);
      return { type: 'updated', job: clone(releasedJob) };
    });
  }

  async releaseCapacityAndLock(job) {
    if (job.executionCleanupPending) {
      await this.updateLockForJob(job);
      return this.jobs.get(job.jobId) || job;
    }
    const lock = this.locks.get(job.projectGuid);
    if (lock?.activeJobId === job.jobId) {
      this.locks.delete(job.projectGuid);
    }
    if (job.capacityClaimed && !job.capacityReleased) {
      this.global.runningCount = Math.max(0, this.global.runningCount - 1);
      this.global.updatedAt = nowIso();
      const releasedJob = {
        ...this.jobs.get(job.jobId),
        capacityReleased: true,
      };
      this.jobs.set(job.jobId, releasedJob);
      return releasedJob;
    }

    return this.jobs.get(job.jobId) || job;
  }

  async listActiveJobs(limit = 100) {
    return [...this.jobs.values()]
      .filter(job => isActiveStatus(job.status))
      .slice(0, limit)
      .map(clone);
  }

  async listExecutionCleanupJobs(limit = 100) {
    return [...this.jobs.values()]
      .filter(job => job.executionCleanupPending === true)
      .slice(0, limit)
      .map(clone);
  }

  async repairProjectLocks() {
    return this.withLock(async () => {
      let repaired = 0;
      for (const [projectGuid, lock] of this.locks.entries()) {
        const job = this.jobs.get(lock.activeJobId);
        if (!isProjectBlockingJob(job)) {
          this.locks.delete(projectGuid);
          repaired += 1;
        }
      }
      return repaired;
    });
  }

  async repairStagedJobs() {
    return 0;
  }

  async repairGlobalCapacity() {
    if (!this.config.globalCapacityEnabled) {
      return null;
    }

    return this.withLock(async () => {
      const runningCount = [...this.jobs.values()]
        .filter(job => (
          isProjectBlockingJob(job)
          && job.capacityClaimed
          && !job.capacityReleased
        ))
        .length;
      const previous = this.global.runningCount;
      this.global = {
        runningCount,
        maxRunning: this.config.maxGlobalRunningJobs,
        updatedAt: nowIso(),
      };
      return { previous, runningCount };
    });
  }
}

class FirestoreJobStore {
  constructor(config) {
    this.config = config;
    this.ready = this.init(config);
  }

  async init(config) {
    const { FieldPath, Firestore } = await import('@google-cloud/firestore');
    this.db = new Firestore({
      projectId: config.projectId || undefined,
      databaseId: config.firestoreDatabaseId,
    });
    this.documentIdField = FieldPath.documentId();
  }

  jobRef(jobId) {
    return this.db.collection('clashJobs').doc(jobId);
  }

  matrixChunkRef(jobId, chunkIndex) {
    return this.jobRef(jobId).collection('matrixChunks').doc(String(chunkIndex).padStart(6, '0'));
  }

  lockRef(projectGuid) {
    return this.db.collection('clashProjectLocks').doc(safeDocId(projectGuid));
  }

  idempotencyRef(ownerId, tenantId, clientRequestId) {
    return this.db.collection('clashIdempotencyKeys').doc(
      idempotencyDocId(ownerId, tenantId, clientRequestId),
    );
  }

  legacyIdempotencyRef(ownerId, clientRequestId) {
    return this.db.collection('clashIdempotencyKeys').doc(
      legacyIdempotencyDocId(ownerId, clientRequestId),
    );
  }

  globalRef() {
    return this.db.collection('clashScheduler').doc('global');
  }

  async getJob(jobId) {
    await this.ready;
    const snapshot = await this.jobRef(jobId).get();
    return snapshot.exists ? snapshot.data() : null;
  }

  async getJobMatrix(jobOrJobId) {
    await this.ready;
    const job = typeof jobOrJobId === 'object' ? jobOrJobId : await this.getJob(jobOrJobId);
    const inlineMatrix = getMatrixPayload(job);
    if (inlineMatrix) {
      return inlineMatrix;
    }
    if (!job?.jobId || job.request?.matrix?.storage !== MATRIX_STORAGE_KIND) {
      return null;
    }

    const snapshot = await this.jobRef(job.jobId)
      .collection('matrixChunks')
      .orderBy('chunkIndex')
      .get();
    return matrixFromChunks(job, snapshot.docs.map(doc => doc.data()));
  }

  async readIdempotentJob(getSnapshot, { ownerId, tenantId, clientRequestId }) {
    const currentSnapshot = await getSnapshot(
      this.idempotencyRef(ownerId, tenantId, clientRequestId),
    );
    if (
      currentSnapshot.exists
      && parseTime(currentSnapshot.data().expiresAt) > Date.now()
    ) {
      const record = currentSnapshot.data();
      const jobSnapshot = await getSnapshot(this.jobRef(record.jobId));
      return {
        record,
        job: jobSnapshot.exists ? jobSnapshot.data() : null,
        requestHashContract: CURRENT_REQUEST_HASH_CONTRACT,
      };
    }

    const legacySnapshot = await getSnapshot(
      this.legacyIdempotencyRef(ownerId, clientRequestId),
    );
    if (
      !legacySnapshot.exists
      || parseTime(legacySnapshot.data().expiresAt) <= Date.now()
    ) {
      return null;
    }

    const record = legacySnapshot.data();
    const jobSnapshot = await getSnapshot(this.jobRef(record.jobId));
    const job = jobSnapshot.exists ? jobSnapshot.data() : null;
    if (!jobMatchesIdentity(job, ownerId, tenantId)) {
      return null;
    }
    return {
      record,
      job,
      requestHashContract: LEGACY_REQUEST_HASH_CONTRACT,
    };
  }

  async getIdempotentJob({ ownerId, tenantId, clientRequestId }) {
    if (!clientRequestId) {
      return null;
    }

    await this.ready;
    return this.readIdempotentJob(ref => ref.get(), {
      ownerId,
      tenantId,
      clientRequestId,
    });
  }

  async stageMatrix(job, chunks) {
    if (chunks.length === 0) {
      return false;
    }

    const ref = this.jobRef(job.jobId);
    let created = false;
    try {
      await ref.create({
        jobId: job.jobId,
        projectGuid: job.projectGuid,
        ownerId: job.ownerId,
        tenantId: job.tenantId,
        persistenceState: 'staging',
        matrix: summarizeMatrix(getMatrixPayload(job)),
        matrixStagingExpiresAt: addMs(this.config.matrixStagingRetentionMs),
        createdAt: job.createdAt,
        updatedAt: nowIso(),
      });
      created = true;
      const bulkWriter = this.db.bulkWriter();
      const writes = [];
      let enqueueError = null;
      try {
        for (const chunk of chunks) {
          writes.push(
            bulkWriter.set(this.matrixChunkRef(job.jobId, chunk.chunkIndex), chunk),
          );
        }
      } catch (error) {
        enqueueError = error;
      }
      const writeResultsPromise = Promise.allSettled(writes);
      await bulkWriter.close();
      const writeResults = await writeResultsPromise;
      const writeErrors = writeResults
        .filter(result => result.status === 'rejected')
        .map(result => result.reason);
      if (enqueueError) {
        writeErrors.unshift(enqueueError);
      }
      if (writeErrors.length === 1) {
        throw writeErrors[0];
      }
      if (writeErrors.length > 1) {
        throw new AggregateError(writeErrors, 'Clash matrix chunk writes failed.');
      }
      return true;
    } catch (error) {
      if (created) {
        try {
          await this.db.recursiveDelete(ref);
        } catch (cleanupError) {
          throw new AggregateError(
            [error, cleanupError],
            'Clash matrix staging and cleanup both failed.',
            { cause: error },
          );
        }
      }
      throw error;
    }
  }

  async cleanupStagedJob(jobId) {
    const ref = this.jobRef(jobId);
    const snapshot = await ref.get();
    if (!snapshot.exists || snapshot.data().persistenceState === 'staging') {
      await this.db.recursiveDelete(ref);
    }
  }

  async claimJob({ job, clientRequestId, requestHash, legacyRequestHash }) {
    await this.ready;
    const matrix = getMatrixPayload(job);
    const matrixChunks = matrix ? createMatrixChunks(matrix) : [];
    const staged = await this.stageMatrix(job, matrixChunks);
    let claim;
    try {
      claim = await this.db.runTransaction(async tx => {
        if (clientRequestId) {
          const existing = await this.readIdempotentJob(ref => tx.get(ref), {
            ownerId: job.ownerId,
            tenantId: job.tenantId,
            clientRequestId,
          });
          if (existing) {
            if (!matchesIdempotencyRequest(existing, {
              requestHash,
              legacyRequestHash,
            })) {
              return { type: 'idempotency-conflict', job: existing.job };
            }

            return { type: 'idempotent', job: existing.job };
          }
        }

        const lockSnapshot = await tx.get(this.lockRef(job.projectGuid));
        const lock = lockSnapshot.exists ? lockSnapshot.data() : null;
        if (lock?.activeJobId) {
          const activeJobSnapshot = await tx.get(this.jobRef(lock.activeJobId));
          const activeJob = activeJobSnapshot.exists ? activeJobSnapshot.data() : null;
          if (isProjectBlockingJob(activeJob)) {
            return { type: 'project-conflict', activeJob };
          }
        }

        let global = null;
        if (this.config.globalCapacityEnabled) {
          const globalSnapshot = await tx.get(this.globalRef());
          global = globalSnapshot.exists
            ? globalSnapshot.data()
            : { runningCount: 0, maxRunning: this.config.maxGlobalRunningJobs };
          const maxRunning = global.maxRunning || this.config.maxGlobalRunningJobs;
          if ((global.runningCount || 0) >= maxRunning) {
            return { type: 'capacity-exceeded' };
          }
        }

        const persistedJob = createPersistedJobDocument(job);
        if (staged) {
          const stagingSnapshot = await tx.get(this.jobRef(job.jobId));
          const staging = stagingSnapshot.exists ? stagingSnapshot.data() : null;
          if (
            staging?.persistenceState !== 'staging'
            || staging?.matrix?.chunkCount !== matrixChunks.length
          ) {
            throw new Error('Clash matrix staging did not complete before job activation.');
          }
        }
        tx.set(this.jobRef(job.jobId), persistedJob);
        tx.set(this.lockRef(persistedJob.projectGuid), makeProjectLock(persistedJob));
        if (clientRequestId) {
          tx.set(this.idempotencyRef(job.ownerId, job.tenantId, clientRequestId), {
            ownerId: job.ownerId,
            tenantId: job.tenantId,
            clientRequestId,
            requestHash,
            jobId: job.jobId,
            createdAt: persistedJob.createdAt,
            expiresAt: addMs(this.config.idempotencyRetentionMs),
          });
        }
        if (this.config.globalCapacityEnabled) {
          tx.set(this.globalRef(), {
            runningCount: (global?.runningCount || 0) + 1,
            maxRunning: global?.maxRunning || this.config.maxGlobalRunningJobs,
            updatedAt: nowIso(),
          }, { merge: true });
        }

        return { type: 'created', job: persistedJob };
      });
    } catch (error) {
      if (staged) {
        try {
          await this.cleanupStagedJob(job.jobId);
        } catch (cleanupError) {
          throw new AggregateError(
            [error, cleanupError],
            'Clash job activation and staged matrix cleanup both failed.',
            { cause: error },
          );
        }
      }
      throw error;
    }

    if (staged && claim.type !== 'created') {
      await this.cleanupStagedJob(job.jobId);
    }
    return claim;
  }

  async updateJobTransaction(jobId, callback) {
    await this.ready;
    return this.db.runTransaction(async tx => {
      const ref = this.jobRef(jobId);
      const snapshot = await tx.get(ref);
      const job = snapshot.exists ? snapshot.data() : null;
      const result = await callback({ tx, job, ref });
      return result;
    });
  }

  async updateLockForJobTx(tx, job) {
    const lockRef = this.lockRef(job.projectGuid);
    const lockSnapshot = await tx.get(lockRef);
    const lock = lockSnapshot.exists ? lockSnapshot.data() : null;
    if (lock?.activeJobId === job.jobId) {
      tx.set(lockRef, {
        ...lock,
        activeStatus: job.status,
        activeUpdatedAt: job.updatedAt,
        leaseToken: job.leaseToken,
        leaseExpiresAt: job.leaseExpiresAt,
      });
    } else if (!lock && job.executionCleanupPending) {
      tx.set(lockRef, makeProjectLock(job));
    }
  }

  async releaseCapacityAndLockTx(tx, job) {
    if (job.executionCleanupPending) {
      await this.updateLockForJobTx(tx, job);
      return job;
    }
    const lockRef = this.lockRef(job.projectGuid);
    const lockSnapshot = await tx.get(lockRef);
    const lock = lockSnapshot.exists ? lockSnapshot.data() : null;
    let global = null;
    if (job.capacityClaimed && !job.capacityReleased) {
      const globalSnapshot = await tx.get(this.globalRef());
      global = globalSnapshot.exists ? globalSnapshot.data() : {};
    }

    if (lock?.activeJobId === job.jobId) {
      tx.delete(lockRef);
    }

    let nextJob = job;
    if (job.capacityClaimed && !job.capacityReleased) {
      tx.set(this.globalRef(), {
        runningCount: Math.max(0, (global.runningCount || 0) - 1),
        maxRunning: global.maxRunning || this.config.maxGlobalRunningJobs,
        updatedAt: nowIso(),
      }, { merge: true });
      nextJob = {
        ...nextJob,
        capacityReleased: true,
      };
    }

    return nextJob;
  }

  async recordCloudRunStarted({ jobId, executionName, jobName }) {
    return this.updateJobTransaction(jobId, async ({ tx, job, ref }) => {
      if (!job) {
        return job;
      }
      const nextJob = withCloudRunStarted(job, { executionName, jobName });
      await this.updateLockForJobTx(tx, nextJob);
      tx.set(ref, nextJob);
      return nextJob;
    });
  }

  async markStartFailed({ jobId, error }) {
    return this.updateJobTransaction(jobId, async ({ tx, job, ref }) => {
      if (!job || isTerminalStatus(job.status)) {
        return job;
      }
      const failedJob = withStartFailure(job, error);
      const nextJob = await this.releaseCapacityAndLockTx(tx, failedJob);
      tx.set(ref, nextJob);
      return nextJob;
    });
  }

  async markRunning({ jobId, startToken, executionName, taskIndex, taskAttempt }) {
    return this.updateJobTransaction(jobId, async ({ tx, job, ref }) => {
      if (!job || job.startToken !== startToken || isTerminalStatus(job.status)) {
        return { type: 'stale', job };
      }

      const nextJob = withRunningState(job, { executionName, taskIndex, taskAttempt });
      await this.updateLockForJobTx(tx, nextJob);
      tx.set(ref, nextJob);
      return { type: 'updated', job: nextJob };
    });
  }

  async patchProgress({ jobId, startToken, progressPatch }) {
    await this.ready;
    const ref = this.jobRef(jobId);
    const snapshot = await ref.get();
    const job = snapshot.exists ? snapshot.data() : null;
    if (!job || job.startToken !== startToken || isTerminalStatus(job.status)) {
      return job;
    }

    const progressUpdate = createProgressUpdate(job, progressPatch);
    try {
      await ref.update(progressUpdate, { lastUpdateTime: snapshot.updateTime });
    } catch (error) {
      if (error?.code === 9 || error?.code === 'FAILED_PRECONDITION') {
        return job;
      }
      throw error;
    }

    return {
      ...job,
      ...progressUpdate,
    };
  }

  async requestCancel({ jobId, caller }) {
    return this.updateJobTransaction(jobId, async ({ tx, job, ref }) => {
      if (!job || isTerminalStatus(job.status)) {
        return job;
      }
      const nextJob = withCancellationRequested(job, caller);
      await this.updateLockForJobTx(tx, nextJob);
      tx.set(ref, nextJob);
      return nextJob;
    });
  }

  async ensureExecutionCleanupPending({ jobId }) {
    return this.updateJobTransaction(jobId, async ({ tx, job, ref }) => {
      if (
        !job
        || !isActiveStatus(job.status)
        || !isExternalExecutionName(job.executionName)
      ) {
        return job;
      }
      const nextJob = withExecutionCleanupPending(job);
      await this.updateLockForJobTx(tx, nextJob);
      tx.set(ref, nextJob);
      return nextJob;
    });
  }

  async recordExecutionCleanupAttempt({ jobId, error = null }) {
    return this.updateJobTransaction(jobId, async ({ tx, job, ref }) => {
      if (
        !job
        || !isExternalExecutionName(job.executionName)
        || !job.executionCleanupPending
      ) {
        return job;
      }
      const nextJob = withExecutionCleanupAttempt(job, this.config, error);
      await this.updateLockForJobTx(tx, nextJob);
      tx.set(ref, nextJob);
      return nextJob;
    });
  }

  async recordExecutionLookupFailure({ jobId, error }) {
    return this.updateJobTransaction(jobId, async ({ tx, job, ref }) => {
      if (!job || !isActiveStatus(job.status)) {
        return job;
      }
      const nextJob = withExecutionLookupFailure(job, this.config, error);
      tx.set(ref, nextJob);
      return nextJob;
    });
  }

  async recordExecutionLookupSuccess({ jobId }) {
    return this.updateJobTransaction(jobId, async ({ tx, job, ref }) => {
      if (!job || !isActiveStatus(job.status)) {
        return job;
      }
      const nextJob = withExecutionLookupSuccess(job);
      tx.set(ref, nextJob);
      return nextJob;
    });
  }

  async completeExecutionCleanup({ jobId }) {
    return this.updateJobTransaction(jobId, async ({ tx, job, ref }) => {
      if (!job) {
        return null;
      }
      if (!isTerminalStatus(job.status) || !job.executionCleanupPending) {
        return job;
      }
      const completedJob = withExecutionCleanupComplete(job);
      const nextJob = await this.releaseCapacityAndLockTx(tx, completedJob);
      tx.set(ref, nextJob);
      return nextJob;
    });
  }

  async markTerminal({
    jobId,
    startToken,
    status,
    result,
    error,
    updatedBy,
    executionTerminalConfirmed,
  }) {
    return this.updateJobTransaction(jobId, async ({ tx, job, ref }) => {
      if (!job || isTerminalStatus(job.status)) {
        return { type: 'unchanged', job };
      }
      if (startToken && job.startToken !== startToken) {
        return { type: 'stale', job };
      }

      const terminalJob = withTerminalState(job, {
        status,
        result,
        error,
        updatedBy,
        executionTerminalConfirmed,
      });
      const nextJob = await this.releaseCapacityAndLockTx(tx, terminalJob);
      tx.set(ref, nextJob);
      return { type: 'updated', job: nextJob };
    });
  }

  async listActiveJobs(limit = 100) {
    await this.ready;
    const snapshot = await this.db
      .collection('clashJobs')
      .where('status', 'in', [...ACTIVE_STATUSES])
      .limit(limit)
      .get();

    return snapshot.docs.map(doc => doc.data());
  }

  async listExecutionCleanupJobs(limit = 100) {
    await this.ready;
    const snapshot = await this.db
      .collection('clashJobs')
      .where('executionCleanupPending', '==', true)
      .limit(limit)
      .get();

    return snapshot.docs.map(doc => doc.data());
  }

  async repairStagedJobs() {
    await this.ready;
    let repaired = 0;
    let query = this.db
      .collection('clashJobs')
      .where('persistenceState', 'in', ['staging', 'purging'])
      .orderBy(this.documentIdField)
      .limit(500);
    while (query) {
      const snapshot = await query.get();
      if (snapshot.empty) {
        break;
      }
      for (const observedJob of snapshot.docs) {
        const claimedForPurge = await this.db.runTransaction(async tx => {
          const currentSnapshot = await tx.get(observedJob.ref);
          if (!currentSnapshot.exists) {
            return false;
          }
          const current = currentSnapshot.data();
          if (current.persistenceState === 'purging') {
            return true;
          }
          if (
            current.persistenceState !== 'staging'
            || parseTime(current.matrixStagingExpiresAt) > Date.now()
          ) {
            return false;
          }
          tx.set(observedJob.ref, {
            ...current,
            persistenceState: 'purging',
            updatedAt: nowIso(),
          });
          return true;
        });
        if (claimedForPurge) {
          await this.db.recursiveDelete(observedJob.ref);
          repaired += 1;
        }
      }
      query = snapshot.size === 500
        ? this.db
          .collection('clashJobs')
          .where('persistenceState', 'in', ['staging', 'purging'])
          .orderBy(this.documentIdField)
          .startAfter(snapshot.docs.at(-1))
          .limit(500)
        : null;
    }
    return repaired;
  }

  async repairProjectLocks() {
    await this.ready;
    let repaired = 0;
    let query = this.db
      .collection('clashProjectLocks')
      .orderBy(this.documentIdField)
      .limit(500);
    while (query) {
      const snapshot = await query.get();
      if (snapshot.empty) {
        break;
      }
      for (const observedLock of snapshot.docs) {
        const deleted = await this.db.runTransaction(async tx => {
          const lockSnapshot = await tx.get(observedLock.ref);
          if (!lockSnapshot.exists) {
            return false;
          }
          const lock = lockSnapshot.data();
          const jobSnapshot = lock.activeJobId
            ? await tx.get(this.jobRef(lock.activeJobId))
            : null;
          const job = jobSnapshot?.exists ? jobSnapshot.data() : null;
          if (isProjectBlockingJob(job)) {
            return false;
          }
          tx.delete(observedLock.ref);
          return true;
        });
        if (deleted) {
          repaired += 1;
        }
      }
      query = snapshot.size === 500
        ? this.db
          .collection('clashProjectLocks')
          .orderBy(this.documentIdField)
          .startAfter(snapshot.docs.at(-1))
          .limit(500)
        : null;
    }

    return repaired;
  }

  async repairGlobalCapacity() {
    if (!this.config.globalCapacityEnabled) {
      return null;
    }

    await this.ready;
    return this.db.runTransaction(async tx => {
      const unreleasedJobs = await tx.get(
        this.db
          .collection('clashJobs')
          .where('capacityClaimed', '==', true)
          .where('capacityReleased', '==', false),
      );
      const globalSnapshot = await tx.get(this.globalRef());
      const runningCount = unreleasedJobs.docs
        .map(doc => doc.data())
        .filter(job => (
          isProjectBlockingJob(job)
          && job.capacityClaimed
          && !job.capacityReleased
        )).length;
      const previous = globalSnapshot.exists ? globalSnapshot.data().runningCount || 0 : 0;
      tx.set(this.globalRef(), {
        runningCount,
        maxRunning: this.config.maxGlobalRunningJobs,
        updatedAt: nowIso(),
      }, { merge: true });

      return { previous, runningCount };
    });
  }
}

export function createJobStore(config) {
  if (config.stateBackend === 'firestore') {
    return new FirestoreJobStore(config);
  }

  return new MemoryJobStore(config);
}
