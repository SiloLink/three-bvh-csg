import { normalizeCandidateEndpoint as normalizeCoreCandidateEndpoint } from '../candidate-pair.js';
import { normalizeToleranceMm } from '../tolerance.js';

function formatNumber(value, digits = 3) {
  return Number.isFinite(value) ? value.toFixed(digits) : 'NA';
}

function formatBoolean(value) {
  return value ? 'TRUE' : 'FALSE';
}

function normalizeReportEndpoint(endpoint, label) {
  const normalized = normalizeCoreCandidateEndpoint(endpoint || {});
  const {
    discipline,
    folderName,
    modelId,
    globalId,
    entityType,
  } = normalized;

  if (!discipline) {
    throw new Error(`${label} discipline is required.`);
  }
  if (!folderName) {
    throw new Error(`${label} folderName is required.`);
  }
  if (!modelId) {
    throw new Error(`${label} modelId is required.`);
  }
  if (!globalId) {
    throw new Error(`${label} GlobalID is required.`);
  }

  return { modelId, discipline, folderName, globalId, entityType };
}

export function normalizeNarrowPhasePair(pair, index) {
  const pairId = String(pair?.pairId || '').trim();
  if (!pairId) {
    throw new Error(`Pair ${index + 1} pairId is required.`);
  }
  const source = normalizeReportEndpoint(pair.source || pair.first || pair.object1, `Pair ${index + 1} source`);
  const target = normalizeReportEndpoint(pair.target || pair.second || pair.object2, `Pair ${index + 1} target`);
  const toleranceMm = normalizeToleranceMm(pair.toleranceMm || {});

  return {
    'Clash GUID': pairId,
    'Object 1 GlobalID': source.globalId,
    'Object 1 Folder': source.folderName,
    'Object 1 Model ID': source.modelId,
    'Object 1 Discipline': source.discipline,
    'Object 1 Type': source.entityType,
    'Object 2 GlobalID': target.globalId,
    'Object 2 Folder': target.folderName,
    'Object 2 Model ID': target.modelId,
    'Object 2 Discipline': target.discipline,
    'Object 2 Type': target.entityType,
    toleranceMm,
  };
}

export function normalizeNarrowPhasePairs(pairs) {
  if (!Array.isArray(pairs)) {
    throw new Error('pairs must be an array.');
  }

  return pairs.map((pair, index) => normalizeNarrowPhasePair(pair, index));
}

export function createNarrowPhaseReportRow(row, {
  collision,
  clashType,
  volumeMm3,
  boxSizeMm,
}) {
  return {
    ...row,
    Collision: formatBoolean(collision),
    'Clash Type': clashType,
    'Volume (mm3)': formatNumber(volumeMm3),
    'Box X (mm)': formatNumber(boxSizeMm.x),
    'Box Y (mm)': formatNumber(boxSizeMm.y),
    'Box Z (mm)': formatNumber(boxSizeMm.z),
    Error: 'NA',
  };
}

export function createNarrowPhaseErrorRow(row, error) {
  return {
    ...row,
    Collision: 'FALSE',
    'Clash Type': 'NA',
    'Volume (mm3)': 'NA',
    'Box X (mm)': 'NA',
    'Box Y (mm)': 'NA',
    'Box Z (mm)': 'NA',
    Error: error.message || String(error),
  };
}
