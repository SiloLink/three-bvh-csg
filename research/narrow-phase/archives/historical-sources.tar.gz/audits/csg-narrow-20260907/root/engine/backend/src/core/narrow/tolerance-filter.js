import { normalizeToleranceMm } from '../tolerance.js';

export const TOLERANCE_FILTER_MARGIN_MM = 0.1;

export function shouldFilterOverlappingByTolerance(clashType, boxSizeMm, toleranceMm = {}) {
  if (clashType !== 'Overlapping') {
    return false;
  }

  const tolerance = normalizeToleranceMm(toleranceMm);
  const horizontalLimitMm = tolerance.horizontal + TOLERANCE_FILTER_MARGIN_MM;
  const verticalLimitMm = tolerance.vertical + TOLERANCE_FILTER_MARGIN_MM;
  return (
    (tolerance.horizontal > 0 && boxSizeMm.y <= horizontalLimitMm)
    || (tolerance.vertical > 0 && boxSizeMm.z <= verticalLimitMm)
  );
}

// Suppress thin, low-volume overlaps: the intersection material is a sliver (low
// fill ratio) AND tiny in absolute terms (vol cap). Large-but-thin overlaps (e.g.
// a window frame seated deep in its host wall, ~871 cm3) are NOT caught here on
// purpose — the volume cap protects them; the host-opening-fill semantic rule
// handles that family instead. Cross-project validation: FP -33.5%, TP -0.23%.
//
//   fillRatio = volumeMm3 / (boxX * boxY * boxZ)   (world-frame OMBR box)
//   suppress  = Overlapping && volumeMm3 < CAP && fillRatio < THRESHOLD
//
// KNOWN LIMITATION (v2): the box is the UNION box of all overlap components for the
// pair (same box the tolerance filter uses). A pair with multiple spatially-separated
// real intersections gets an inflated box and a deflated fill ratio. The 50 cm3 cap
// bounds this to tiny-total-volume pairs, and the cross-project eval gate measured the
// net cost (TP -0.23%) WITH this behavior in effect. v2 refinement: per-overlap-
// component fill ratio instead of the union box.
export const FILL_RATIO_THRESHOLD = 0.003;
export const FILL_RATIO_VOLUME_CAP_MM3 = 50000; // 50 cm3

export function shouldFilterByFillRatio(clashType, volumeMm3, boxSizeMm) {
  if (clashType !== 'Overlapping') {
    return false;
  }
  // Reject malformed metrics explicitly: only a finite, positive, sub-cap volume
  // is eligible (a collision always has volumeMm3 > VOLUME_TOLERANCE_MM3 in
  // practice, but guard anyway so a bad upstream metric is never "filtered").
  if (!(Number.isFinite(volumeMm3) && volumeMm3 > 0 && volumeMm3 < FILL_RATIO_VOLUME_CAP_MM3)) {
    return false;
  }

  const { x, y, z } = boxSizeMm;
  // Degenerate / non-finite box -> no meaningful fill ratio; never filter.
  if (!(Number.isFinite(x) && Number.isFinite(y) && Number.isFinite(z) && x > 0 && y > 0 && z > 0)) {
    return false;
  }

  return volumeMm3 < FILL_RATIO_THRESHOLD * (x * y * z);
}
