const TOTAL_FIELDS = [
  'durationMs',
  'normalizePairsMs',
  'pairLoopMs',
  'rowTotalMs',
  'loadBrushesMs',
  'csgEvaluateMs',
  'intersectionVolumeMs',
  'metricsMs',
  'overlapBoxMs',
  'formatResultMs',
  'disposeMs',
  'prepMs',
  'pairCount',
  'csgOperationCount',
  'csgAabbRejectedCount',
  'duplicateFastPathCount',
  'errorCount',
  'fillRatioFilteredCount',
];

const MEMORY_FIELDS = ['heapUsed', 'external', 'arrayBuffers', 'rss'];

const CACHE_FIELDS = [
  'recordHits',
  'recordMisses',
  'brushHits',
  'brushMisses',
  'metricHits',
  'metricMisses',
  'skippedObjects',
];

const GEOMETRY_STORE_COUNT_FIELDS = ['acquireHits', 'acquireMisses', 'evictions'];

function zeroFields(fields) {
  return Object.fromEntries(fields.map(field => [field, 0]));
}

function roundMetricValue(value) {
  return Number(value.toFixed(3));
}

function createEmptyCacheStats() {
  return {
    ...zeroFields(CACHE_FIELDS),
    sharedGeometryStore: {
      ...zeroFields(GEOMETRY_STORE_COUNT_FIELDS),
      maxWorkerPeakBytes: 0,
      sumWorkerPeakBytes: 0,
    },
  };
}

function normalizeCacheSnapshot(cacheStats) {
  const snapshot = {
    ...zeroFields(CACHE_FIELDS),
    sharedGeometryStore: {
      ...zeroFields(GEOMETRY_STORE_COUNT_FIELDS),
      peakBytes: 0,
    },
  };
  for (const field of CACHE_FIELDS) {
    if (Number.isFinite(cacheStats?.[field])) {
      snapshot[field] = cacheStats[field];
    }
  }
  for (const field of GEOMETRY_STORE_COUNT_FIELDS) {
    if (Number.isFinite(cacheStats?.sharedGeometryStore?.[field])) {
      snapshot.sharedGeometryStore[field] = cacheStats.sharedGeometryStore[field];
    }
  }
  if (Number.isFinite(cacheStats?.sharedGeometryStore?.peakBytes)) {
    snapshot.sharedGeometryStore.peakBytes = cacheStats.sharedGeometryStore.peakBytes;
  }
  return snapshot;
}

function addCacheSnapshot(combined, snapshot) {
  for (const field of CACHE_FIELDS) {
    combined[field] += snapshot[field];
  }
  for (const field of GEOMETRY_STORE_COUNT_FIELDS) {
    combined.sharedGeometryStore[field] += snapshot.sharedGeometryStore[field];
  }
  const peakBytes = snapshot.sharedGeometryStore.peakBytes;
  combined.sharedGeometryStore.maxWorkerPeakBytes = Math.max(
    combined.sharedGeometryStore.maxWorkerPeakBytes,
    peakBytes,
  );
  combined.sharedGeometryStore.sumWorkerPeakBytes += peakBytes;
}

function combineCacheSnapshots(snapshots) {
  const combined = createEmptyCacheStats();
  for (const snapshot of snapshots) {
    addCacheSnapshot(combined, snapshot);
  }
  return combined;
}

export function createNarrowPhaseTimingAccumulator({ persistentWorkers = true } = {}) {
  const totals = zeroFields(TOTAL_FIELDS);
  const peakMemMb = zeroFields(MEMORY_FIELDS);
  const cacheSnapshotsByWorker = new Map();
  const nonPersistentCacheStats = createEmptyCacheStats();

  return {
    add(workerTiming, { workerId = null } = {}) {
      if (!workerTiming || typeof workerTiming !== 'object' || Array.isArray(workerTiming)) {
        throw new Error('Narrow phase workerTiming payload is required.');
      }
      if (persistentWorkers && (!Number.isInteger(workerId) || workerId < 1)) {
        throw new Error('Persistent narrow phase workerId must be a positive integer.');
      }
      for (const field of TOTAL_FIELDS) {
        const value = workerTiming?.[field];
        if (Number.isFinite(value)) {
          totals[field] += value;
        }
      }
      for (const field of MEMORY_FIELDS) {
        const value = workerTiming?.memMb?.[field];
        if (Number.isFinite(value)) {
          peakMemMb[field] = Math.max(peakMemMb[field], value);
        }
      }
      if (persistentWorkers) {
        cacheSnapshotsByWorker.set(workerId, normalizeCacheSnapshot(workerTiming?.cacheStats));
      } else {
        addCacheSnapshot(nonPersistentCacheStats, normalizeCacheSnapshot(workerTiming?.cacheStats));
      }
    },

    snapshot() {
      return {
        totals: Object.fromEntries(
          Object.entries(totals).map(([field, value]) => [field, roundMetricValue(value)]),
        ),
        peakMemMb: { ...peakMemMb },
        cacheStats: persistentWorkers
          ? combineCacheSnapshots(cacheSnapshotsByWorker.values())
          : {
            ...nonPersistentCacheStats,
            sharedGeometryStore: { ...nonPersistentCacheStats.sharedGeometryStore },
          },
      };
    },
  };
}
