import crypto from 'node:crypto';
import { forbidden, unauthorized } from './httpErrors.js';

function firstHeader(request, names) {
  for (const name of names) {
    const value = request.headers[name];
    if (value) {
      return Array.isArray(value) ? value[0] : value;
    }
  }

  return '';
}

function decodeJsonSegment(segment) {
  try {
    const value = JSON.parse(Buffer.from(segment, 'base64url').toString('utf8'));
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
  } catch {
    return null;
  }
}

function invalidCallerToken() {
  return unauthorized('CALLER_TOKEN_INVALID', 'The caller identity token is invalid.');
}

function verifyCallerToken(token, config) {
  if (
    !config.callerTokenSecret
    || !config.callerTokenIssuer
    || !config.callerTokenAudience
  ) {
    throw unauthorized(
      'CALLER_AUTH_NOT_CONFIGURED',
      'Caller identity authentication is not configured.',
    );
  }

  const segments = String(token).split('.');
  if (segments.length !== 3 || segments.some(segment => !segment)) {
    throw invalidCallerToken();
  }

  const [encodedHeader, encodedPayload, encodedSignature] = segments;
  const header = decodeJsonSegment(encodedHeader);
  const payload = decodeJsonSegment(encodedPayload);
  if (!header || !payload || header.alg !== 'HS256' || header.typ !== 'JWT') {
    throw invalidCallerToken();
  }

  let suppliedSignature;
  try {
    suppliedSignature = Buffer.from(encodedSignature, 'base64url');
  } catch {
    throw invalidCallerToken();
  }
  const expectedSignature = crypto
    .createHmac('sha256', config.callerTokenSecret)
    .update(`${encodedHeader}.${encodedPayload}`)
    .digest();
  if (
    suppliedSignature.length !== expectedSignature.length
    || !crypto.timingSafeEqual(suppliedSignature, expectedSignature)
  ) {
    throw invalidCallerToken();
  }

  const now = Math.floor(Date.now() / 1000);
  const clockSkew = config.callerTokenClockSkewSeconds;
  const maxTtl = config.callerTokenMaxTtlSeconds;
  if (
    payload.iss !== config.callerTokenIssuer
    || payload.aud !== config.callerTokenAudience
    || typeof payload.sub !== 'string'
    || !payload.sub
    || typeof payload.tenant !== 'string'
    || !payload.tenant
    || !Number.isInteger(payload.iat)
    || !Number.isInteger(payload.exp)
    || payload.exp <= payload.iat
    || payload.iat > now + clockSkew
    || payload.exp <= now - clockSkew
    || payload.exp - payload.iat > maxTtl
  ) {
    throw invalidCallerToken();
  }

  return {
    ownerId: payload.sub,
    tenantId: payload.tenant,
    authType: 'signed-caller-token',
  };
}

export function authenticatePublicRequest(request, config) {
  const token = firstHeader(request, ['x-clash-caller-token']);
  if (token) {
    return verifyCallerToken(token, config);
  }

  if (config.allowDevAuth && !config.requireAuth) {
    return {
      ownerId: 'local-dev-user',
      tenantId: 'local-dev-tenant',
      authType: 'dev',
    };
  }

  throw unauthorized('CALLER_TOKEN_REQUIRED', 'A signed caller identity token is required.');
}

export function authenticateInternalRequest(request, config) {
  const token = firstHeader(request, ['x-clash-internal-token'])
    || String(firstHeader(request, ['authorization'])).replace(/^Bearer\s+/i, '');

  if (config.internalToken && token === config.internalToken) {
    return {
      ownerId: 'internal-scheduler',
      tenantId: 'internal',
      authType: 'internal-token',
    };
  }

  if (!config.internalToken && config.allowDevAuth && !config.requireAuth) {
    return {
      ownerId: 'local-internal',
      tenantId: 'local-dev-tenant',
      authType: 'dev-internal',
    };
  }

  throw unauthorized('INTERNAL_AUTH_REQUIRED', 'Internal endpoint authentication is required.');
}

export function assertJobAccess(caller, job) {
  if (!job) {
    return;
  }

  if (job.ownerId === caller.ownerId && job.tenantId === caller.tenantId) {
    return;
  }

  throw forbidden('PROJECT_ACCESS_DENIED', 'The caller cannot access this clash report.');
}
