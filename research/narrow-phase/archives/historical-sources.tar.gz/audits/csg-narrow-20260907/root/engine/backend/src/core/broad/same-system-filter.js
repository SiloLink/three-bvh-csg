function sameNonEmptySystemSet(sourceSystemIds = [], targetSystemIds = []) {
  if (sourceSystemIds.length === 0 || targetSystemIds.length === 0) {
    return false;
  }
  if (sourceSystemIds.length !== targetSystemIds.length) {
    return false;
  }

  return sourceSystemIds.every((systemId, index) => systemId === targetSystemIds[index]);
}

export function createSameSystemFilterCounts() {
  return {
    LEVEL0_SAFE_IGNORE: 0,
    LEVEL1_REASONABLE_IGNORE: 0,
  };
}

export function decideSameSystemIgnore(sourceObject, targetObject) {
  const directA = sourceObject.directSystemIds || [];
  const directB = targetObject.directSystemIds || [];

  if (sameNonEmptySystemSet(directA, directB)) {
    return {
      ignore: true,
      level: 'LEVEL0_SAFE_IGNORE',
      reason: 'Both objects have the exact same direct IFC system set from IfcRelAssignsToGroup.',
    };
  }

  const effectiveA = sourceObject.effectiveSystemIds || [];
  const effectiveB = targetObject.effectiveSystemIds || [];
  const hasCoveringDerivedSystem = (
    (sourceObject.derivedSystemIds || []).length > 0
    || (targetObject.derivedSystemIds || []).length > 0
  );

  if (
    hasCoveringDerivedSystem
    && sameNonEmptySystemSet(effectiveA, effectiveB)
  ) {
    return {
      ignore: true,
      level: 'LEVEL1_REASONABLE_IGNORE',
      reason: 'The exact same effective IFC system set is derived through explicit IfcRelCoversBldgElements.',
    };
  }

  return {
    ignore: false,
    level: 'KEEP',
    reason: 'No exact direct or explicit covering-derived same-system condition was found.',
  };
}
