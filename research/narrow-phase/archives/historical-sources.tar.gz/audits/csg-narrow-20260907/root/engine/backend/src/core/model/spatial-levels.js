import { getModelFile } from '../project-descriptor.js';
import { readParquetObjects } from '../parquet.js';

const SPATIAL_CONTAINMENT_RELATIONSHIP = 'IfcRelContainedInSpatialStructure';
const AGGREGATE_RELATIONSHIP = 'IfcRelAggregates';
const BUILDING_STOREY_TYPE = 'IfcBuildingStorey';

function cleanText(value) {
  return String(value ?? '').trim().replace(/\s+/g, ' ');
}

export function normalizeSpatialLevelName(value) {
  return cleanText(value).toLowerCase();
}

function createStoreyInfo(row) {
  const storeyGlobalId = cleanText(row?.GlobalId);
  if (!storeyGlobalId) {
    return null;
  }

  const name = cleanText(row?.Name) || storeyGlobalId;
  const normalizedName = normalizeSpatialLevelName(name);
  if (!normalizedName) {
    return null;
  }

  return {
    name,
    normalizedName,
    storeyGlobalId,
  };
}

function getOrCreateLevelEntry(entries, storeyInfo) {
  if (!entries.has(storeyInfo.normalizedName)) {
    entries.set(storeyInfo.normalizedName, {
      name: storeyInfo.name,
      normalizedName: storeyInfo.normalizedName,
      storeyGlobalIds: new Set(),
      objectGlobalIds: new Set(),
    });
  }

  const entry = entries.get(storeyInfo.normalizedName);
  entry.storeyGlobalIds.add(storeyInfo.storeyGlobalId);
  return entry;
}

function toSortedSpatialLevels(entries) {
  return [...entries.values()]
    .map(entry => ({
      name: entry.name,
      normalizedName: entry.normalizedName,
      storeyGlobalIds: [...entry.storeyGlobalIds].sort((a, b) => a.localeCompare(b)),
      objectCount: entry.objectGlobalIds.size,
    }))
    .sort((a, b) => a.name.localeCompare(b.name, undefined, {
      numeric: true,
      sensitivity: 'base',
    }));
}

function createStoreyInfoLookup(modelRows) {
  const storeysByGlobalId = new Map();
  for (const row of modelRows || []) {
    if (cleanText(row?.type) !== BUILDING_STOREY_TYPE) {
      continue;
    }

    const storeyInfo = createStoreyInfo(row);
    if (storeyInfo) {
      storeysByGlobalId.set(storeyInfo.storeyGlobalId, storeyInfo);
    }
  }

  return storeysByGlobalId;
}

function createDirectObjectStoreyLookup(relationshipRows, storeysByGlobalId) {
  const directObjectStorey = new Map();

  for (const row of relationshipRows || []) {
    if (cleanText(row?.Relationship_Type) !== SPATIAL_CONTAINMENT_RELATIONSHIP) {
      continue;
    }

    const storeyGlobalId = cleanText(row?.Relating_Object_GUID);
    const objectGlobalId = cleanText(row?.Related_Object_GUID);
    const storeyInfo = storeysByGlobalId.get(storeyGlobalId);
    if (!storeyInfo || !objectGlobalId) {
      continue;
    }

    directObjectStorey.set(objectGlobalId, storeyInfo);
  }

  return directObjectStorey;
}

function createAggregateParentLookup(relationshipRows) {
  const parentByChild = new Map();

  for (const row of relationshipRows || []) {
    if (cleanText(row?.Relationship_Type) !== AGGREGATE_RELATIONSHIP) {
      continue;
    }

    const parentGlobalId = cleanText(row?.Relating_Object_GUID);
    const childGlobalId = cleanText(row?.Related_Object_GUID);
    if (parentGlobalId && childGlobalId) {
      parentByChild.set(childGlobalId, parentGlobalId);
    }
  }

  return parentByChild;
}

export function createSpatialLevelCatalogFromRows(modelRows, relationshipRows) {
  const storeysByGlobalId = createStoreyInfoLookup(modelRows);
  const directObjectStorey = createDirectObjectStoreyLookup(relationshipRows, storeysByGlobalId);
  const entries = new Map();

  for (const storeyInfo of storeysByGlobalId.values()) {
    getOrCreateLevelEntry(entries, storeyInfo);
  }

  for (const [objectGlobalId, storeyInfo] of directObjectStorey) {
    getOrCreateLevelEntry(entries, storeyInfo).objectGlobalIds.add(objectGlobalId);
  }

  return toSortedSpatialLevels(entries);
}

export function createObjectSpatialLevelLookup(modelRows, relationshipRows) {
  const storeysByGlobalId = createStoreyInfoLookup(modelRows);
  const directObjectStorey = createDirectObjectStoreyLookup(relationshipRows, storeysByGlobalId);
  const parentByChild = createAggregateParentLookup(relationshipRows);
  const resolved = new Map();

  function resolve(globalId, visited = new Set()) {
    const objectGlobalId = cleanText(globalId);
    if (!objectGlobalId) {
      return null;
    }
    if (resolved.has(objectGlobalId)) {
      return resolved.get(objectGlobalId);
    }
    if (directObjectStorey.has(objectGlobalId)) {
      const direct = directObjectStorey.get(objectGlobalId);
      resolved.set(objectGlobalId, direct);
      return direct;
    }
    if (visited.has(objectGlobalId)) {
      resolved.set(objectGlobalId, null);
      return null;
    }
    visited.add(objectGlobalId);

    const parentGlobalId = parentByChild.get(objectGlobalId);
    const inherited = parentGlobalId ? resolve(parentGlobalId, visited) : null;
    resolved.set(objectGlobalId, inherited);
    return inherited;
  }

  return {
    get(globalId) {
      return resolve(globalId);
    },
  };
}

export function mergeSpatialLevelCatalogs(disciplines) {
  const entries = new Map();

  for (const discipline of disciplines || []) {
    const disciplineName = cleanText(discipline?.discipline);
    for (const level of discipline?.spatialLevels || []) {
      const normalizedName = normalizeSpatialLevelName(level.normalizedName || level.name);
      if (!normalizedName) {
        continue;
      }
      if (!entries.has(normalizedName)) {
        entries.set(normalizedName, {
          name: cleanText(level.name) || normalizedName,
          normalizedName,
          storeyGlobalIds: new Set(),
          disciplines: new Set(),
          objectCount: 0,
        });
      }

      const entry = entries.get(normalizedName);
      for (const storeyGlobalId of level.storeyGlobalIds || []) {
        const cleanGlobalId = cleanText(storeyGlobalId);
        if (cleanGlobalId) {
          entry.storeyGlobalIds.add(cleanGlobalId);
        }
      }
      if (disciplineName) {
        entry.disciplines.add(disciplineName);
      }
      entry.objectCount += Number(level.objectCount || 0);
    }
  }

  return [...entries.values()]
    .map(entry => ({
      name: entry.name,
      normalizedName: entry.normalizedName,
      storeyGlobalIds: [...entry.storeyGlobalIds].sort((a, b) => a.localeCompare(b)),
      objectCount: entry.objectCount,
      disciplines: [...entry.disciplines].sort((a, b) => a.localeCompare(b)),
    }))
    .sort((a, b) => a.name.localeCompare(b.name, undefined, {
      numeric: true,
      sensitivity: 'base',
    }));
}

function resolveModelPath(model) {
  if (typeof model === 'string') {
    return model;
  }

  return getModelFile(model, 'model');
}

function resolveRelationshipsPath(model) {
  return getModelFile(model, 'relationships');
}

export async function readSpatialLevelsFromModel(model) {
  const modelPath = resolveModelPath(model);
  const relationshipsPath = resolveRelationshipsPath(model);
  const [modelRows, relationshipRows] = await Promise.all([
    readParquetObjects(modelPath, ['type', 'GlobalId', 'Name']),
    readParquetObjects(relationshipsPath, [
      'Relationship_Type',
      'Relating_Object_GUID',
      'Related_Object_GUID',
    ]),
  ]);

  return createSpatialLevelCatalogFromRows(modelRows, relationshipRows);
}
