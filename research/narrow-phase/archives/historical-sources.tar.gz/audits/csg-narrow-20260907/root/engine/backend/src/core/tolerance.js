function normalizeToleranceValue(value, axis) {
  const numericValue = Number(value ?? 0);
  if (!Number.isFinite(numericValue) || numericValue < 0) {
    throw new RangeError(`${axis} tolerance must be a finite non-negative number.`);
  }
  return numericValue;
}

export function normalizeToleranceMm(toleranceMm = {}) {
  return {
    horizontal: normalizeToleranceValue(
      toleranceMm.horizontal ?? toleranceMm.horizontalToleranceMm,
      'Horizontal',
    ),
    vertical: normalizeToleranceValue(
      toleranceMm.vertical ?? toleranceMm.verticalToleranceMm,
      'Vertical',
    ),
  };
}
