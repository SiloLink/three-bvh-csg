import path from 'node:path';
import { readModelCatalog } from '../core/model/model-catalog.js';
import { createLocalProjectDescriptor } from './projectDescriptor.js';

// Input: parquet model + discipline
// return: matrix-ready data based on discipline + IFC entity type catalog
export async function loadMatrix(basePath) {
  const projectDescriptor = await createLocalProjectDescriptor(basePath);

  return Promise.all(projectDescriptor.models.map(async modelDescriptor => {
    const { folderName } = modelDescriptor;
    const folderPath = path.dirname(modelDescriptor.files.model);
    const { discipline } = modelDescriptor;
    try {
      const catalog = await readModelCatalog(modelDescriptor);

      return {
        folderName,
        discipline,
        folderPath,
        modelPath: catalog.modelPath,
        types: catalog.types,
        typedObjectCount: catalog.typedObjectCount,
        relationCount: catalog.relationCount,
        spatialLevels: catalog.spatialLevels,
        error: null,
      };
    } catch (error) {
      return {
        folderName,
        discipline,
        folderPath,
        modelPath: null,
        types: [],
        typedObjectCount: 0,
        relationCount: 0,
        spatialLevels: [],
        error: error.message,
      };
    }
  }));
}
