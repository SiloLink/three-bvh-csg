import { loadMatrix } from './loadMatrix.js';
import { createLocalProjectDescriptor } from './projectDescriptor.js';
import { mergeSpatialLevelCatalogs } from '../core/model/spatial-levels.js';
import { createReportWriter } from '../io/reportWriters.js';
import { runBroadNarrowReport } from '../runtime/clash-detection-runner.js';

// load the matrix-ready data for front-end
export async function prepareLocalClashDetection(body = {}) {
  const disciplines = await loadMatrix(body.basePath);

  return {
    disciplines,
    spatialLevels: mergeSpatialLevelCatalogs(disciplines),
  };
}

export async function runLocalClashDetection(body = {}, hooks = {}) {
  const matrix = body.matrix || body;
  const basePath = body.basePath || matrix.basePath;
  const projectDescriptor = body.projectDescriptor
    || await createLocalProjectDescriptor(basePath);
  const writer = body.writer || createReportWriter({
    basePath,
    outputPath: body.outputPath || matrix.outputPath,
    outputUri: body.outputUri || matrix.outputUri,
    outputPrefix: body.outputPrefix || matrix.outputPrefix,
    tempOutputPrefix: body.tempOutputPrefix,
    jobId: body.jobId,
    projectGuid: body.projectGuid,
    overwrite: body.overwrite ?? false,
  });
  const result = await runBroadNarrowReport({
    ...body,
    projectDescriptor,
    writer,
  }, hooks);

  return { result };
}
