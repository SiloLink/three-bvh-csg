import fs from 'node:fs/promises';
import { getClashConfig } from '../cloud/config.js';
import { createJobStore, isTerminalStatus } from '../cloud/jobStore.js';
import { stageGcsModelInputs } from '../cloud/gcsStage.js';
import { createProgressReporter } from '../cloud/progressReporter.js';
import { createProgressPublisher } from '../cloud/progressPublisher.js';
import { isCancellationError } from '../cancellation.js';
import { createReportWriter } from '../io/reportWriters.js';
import { runBroadNarrowReport } from '../runtime/clash-detection-runner.js';

function log(level, message, fields = {}) {
  const payload = {
    severity: level,
    message,
    jobId: process.env.CLASH_JOB_ID || null,
    executionName: process.env.CLOUD_RUN_EXECUTION || null,
    ...fields,
  };
  console.log(JSON.stringify(payload));
}

function requireEnv(name) {
  const value = process.env[name];
  if (!value) {
    throw new Error(`${name} is required.`);
  }

  return value;
}

function serializeError(error, phase = 'compute') {
  return {
    code: error?.code || 'CLASH_REPORT_FAILED',
    message: error?.message || String(error),
    stack: error?.stack || null,
    phase: error?.phase || phase,
    retryable: error?.retryable ?? false,
  };
}

function createCancellationChecker({ store, jobId }) {
  let lastCheckAt = 0;
  let cached = false;

  return async () => {
    const now = Date.now();
    if (now - lastCheckAt < 1000) {
      return cached;
    }

    lastCheckAt = now;
    const job = await store.getJob(jobId);
    cached = Boolean(
      !job
      || job.cancelRequested
      || job.status === 'canceling'
      || job.status === 'canceled',
    );
    return cached;
  };
}

function shouldFlushProgressNow(progressPatch = {}) {
  if (progressPatch.stage !== 'narrow-phase') {
    return true;
  }

  const message = String(progressPatch.message || '');
  return message.startsWith('Finished narrow phase batch');
}

export async function runClashReportJob({
  config = getClashConfig(),
  store = createJobStore(config),
  jobId = requireEnv('CLASH_JOB_ID'),
  startToken = requireEnv('CLASH_START_TOKEN'),
  executionName = process.env.CLOUD_RUN_EXECUTION || null,
  taskIndex = process.env.CLOUD_RUN_TASK_INDEX || null,
  taskAttempt = process.env.CLOUD_RUN_TASK_ATTEMPT || null,
  stageInputs = stageGcsModelInputs,
  createWriter = createReportWriter,
  runReport = runBroadNarrowReport,
} = {}) {
  const job = await store.getJob(jobId);

  if (!job) {
    throw new Error(`Clash job ${jobId} was not found.`);
  }
  if (job.startToken !== startToken || isTerminalStatus(job.status)) {
    log('INFO', 'Worker found stale or terminal job and will exit.', {
      status: job.status,
      projectGuid: job.projectGuid,
    });
    return;
  }
  if (job.cancelRequested || job.status === 'canceling') {
    await store.markTerminal({
      jobId,
      startToken,
      status: 'canceled',
      updatedBy: 'worker',
    });
    log('INFO', 'Worker canceled before compute started.', {
      status: 'canceled',
      projectGuid: job.projectGuid,
    });
    return;
  }

  const running = await store.markRunning({
    jobId,
    startToken,
    executionName,
    taskIndex,
    taskAttempt,
  });
  if (running.type !== 'updated') {
    log('INFO', 'Worker could not claim running state and will exit.', {
      status: running.job?.status || null,
      projectGuid: job.projectGuid,
    });
    return;
  }

  const shouldCancel = createCancellationChecker({ store, jobId });
  let progressReporter = null;
  let staged = null;
  try {
    if (!Number.isInteger(job.batchSizeLimit) || job.batchSizeLimit < 1) {
      throw new Error('Persisted clash job batchSizeLimit is required.');
    }
    const progressPublisher = createProgressPublisher({ config, job });
    progressReporter = createProgressReporter({
      flushIntervalMs: config.progressFlushIntervalMs,
      shouldFlushNow: shouldFlushProgressNow,
      onFlush: async progressPatch => {
        await store.patchProgress({
          jobId,
          startToken,
          progressPatch,
        });
        await progressPublisher.publish(progressPatch);
      },
      onError: error => {
        log('WARNING', 'Clash progress update failed.', {
          projectGuid: job.projectGuid,
          error: serializeError(error, 'progress'),
        });
      },
    });
    await progressReporter.report({
      stage: 'staging-inputs',
      message: 'Staging GCS model inputs.',
      progress: { percent: null },
      heartbeatAt: new Date().toISOString(),
    });
    await progressReporter.flush();
    staged = await stageInputs({
      jobId,
      projectGuid: job.projectGuid,
      models: job.models,
      shouldCancel,
    });
    const writer = createWriter({
      outputUri: job.outputUri,
      outputPrefix: job.outputPrefix,
      tempOutputPrefix: config.tempOutputPrefix,
      jobId,
      projectGuid: job.projectGuid,
    });

    const matrix = await store.getJobMatrix(job);
    if (!matrix) {
      throw new Error(`Clash job ${jobId} matrix was not found.`);
    }

    const result = await runReport({
      jobId,
      projectGuid: job.projectGuid,
      detectionIdentity: job.detectionIdentity || null,
      models: job.models,
      projectDescriptor: staged.projectDescriptor,
      matrix,
      spatialLevelFilter: job.spatialLevelFilter || job.request?.spatialLevelFilter || null,
      batchSize: job.batchSize,
      batchSizeLimit: job.batchSizeLimit,
      writer,
    }, {
      shouldCancel,
      onProgress: progressPatch => progressReporter.report(progressPatch),
    });

    await progressReporter.close();
    await store.markTerminal({
      jobId,
      startToken,
      status: 'succeeded',
      result,
      updatedBy: 'worker',
    });
    log('INFO', 'Clash report succeeded.', {
      status: 'succeeded',
      projectGuid: job.projectGuid,
      resultUri: result.resultUri,
    });
  } catch (error) {
    if (progressReporter) {
      await progressReporter.close();
    }
    if (isCancellationError(error)) {
      await store.markTerminal({
        jobId,
        startToken,
        status: 'canceled',
        updatedBy: 'worker',
      });
      log('INFO', 'Clash report canceled.', {
        status: 'canceled',
        projectGuid: job.projectGuid,
      });
      return;
    }

    await store.markTerminal({
      jobId,
      startToken,
      status: 'failed',
      error: serializeError(error),
      updatedBy: 'worker',
    });
    log('ERROR', 'Clash report failed.', {
      status: 'failed',
      projectGuid: job.projectGuid,
      error: serializeError(error),
    });
    process.exitCode = 1;
  } finally {
    if (staged?.rootPath) {
      await fs.rm(staged.rootPath, { recursive: true, force: true }).catch(error => {
        log('WARNING', 'Staged clash inputs cleanup failed.', {
          projectGuid: job.projectGuid,
          rootPath: staged.rootPath,
          error: serializeError(error, 'cleanup'),
        });
      });
    }
  }
}

async function main() {
  await runClashReportJob();
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch(error => {
    log('ERROR', 'Unhandled clash job failure.', {
      error: serializeError(error, 'start'),
    });
    process.exitCode = 1;
  });
}
