import { getModelFile } from '../project-descriptor.js';
import { readParquetObjects } from '../parquet.js';
import { NON_CLASHABLE_ENTITY_TYPES } from './ignored-entity-types.js';
import { hasDirectGeometryId } from './geometry-eligibility.js';

/**
 * Get deduplicated IFC entity type catalog with alphabetical order.
 */
export function createIfcEntityTypeCatalogFromRows(modelRows) {
  const typeCounts = new Map();

  for (const row of modelRows) {
    const type = String(row.type ?? '').trim();
    if (
      !type
      || NON_CLASHABLE_ENTITY_TYPES.has(type)
      || !hasDirectGeometryId(row.geometry_id)
    ) {
      continue;
    }
    typeCounts.set(type, (typeCounts.get(type) || 0) + 1);
  }

  return {
    types: [...typeCounts.keys()].sort((a, b) => a.localeCompare(b)),
    typedObjectCount: [...typeCounts.values()].reduce((sum, count) => sum + count, 0),
    relationCount: 0,
  };
}

function resolveModelPath(model) {
  if (typeof model === 'string') {
    return model;
  }

  return getModelFile(model, 'model');
}

/**
 * Reads one model.parquet and returns its IFC entity type catalog.
 *
 * @param {import('../project-descriptor.js').ModelDescriptor | string} model
 */
export async function readIfcEntityTypeFromModel(model) {
  const modelPath = resolveModelPath(model);
  const modelRows = await readParquetObjects(modelPath, ['type', 'geometry_id']);

  return {
    modelId: typeof model === 'string' ? null : model.modelId,
    discipline: typeof model === 'string' ? null : model.discipline,
    modelPath,
    ...createIfcEntityTypeCatalogFromRows(modelRows),
  };
}
