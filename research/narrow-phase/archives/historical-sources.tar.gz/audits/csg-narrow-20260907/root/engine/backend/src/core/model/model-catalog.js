import { getModelFile } from '../project-descriptor.js';
import { readParquetObjects } from '../parquet.js';
import { createIfcEntityTypeCatalogFromRows } from './ifc-entity-types.js';
import { createSpatialLevelCatalogFromRows } from './spatial-levels.js';

export async function readModelCatalog(model) {
  const modelPath = getModelFile(model, 'model');
  const relationshipsPath = getModelFile(model, 'relationships');
  const [modelRows, relationshipRows] = await Promise.all([
    readParquetObjects(modelPath, ['type', 'geometry_id', 'GlobalId', 'Name']),
    readParquetObjects(relationshipsPath, [
      'Relationship_Type',
      'Relating_Object_GUID',
      'Related_Object_GUID',
    ]),
  ]);

  return {
    modelId: model.modelId,
    discipline: model.discipline,
    modelPath,
    ...createIfcEntityTypeCatalogFromRows(modelRows),
    spatialLevels: createSpatialLevelCatalogFromRows(modelRows, relationshipRows),
  };
}
