import { serviceUnavailable } from './httpErrors.js';

const CLOUD_PLATFORM_SCOPE = 'https://www.googleapis.com/auth/cloud-platform';

function requireCloudRunJobName(config) {
  if (config.cloudRunJobName) {
    return config.cloudRunJobName;
  }
  if (config.allowNoopCloudRunStart) {
    return '';
  }

  throw serviceUnavailable(
    'CLOUD_RUN_JOB_NOT_CONFIGURED',
    'CLASH_CLOUD_RUN_JOB_NAME is required to start asynchronous clash reports.',
  );
}

async function createAuth() {
  const { GoogleAuth } = await import('google-auth-library');
  return new GoogleAuth({ scopes: [CLOUD_PLATFORM_SCOPE] });
}

function extractExecutionName(responseData) {
  const candidates = [
    responseData?.metadata?.target,
    responseData?.metadata?.name,
    responseData?.response?.name,
    responseData?.name,
  ].filter(Boolean);

  return candidates.find(value => String(value).includes('/executions/')) || null;
}

export function resolveExecutionName(config, executionName) {
  if (!executionName) {
    return null;
  }
  const value = String(executionName);
  if (value.includes('/executions/')) {
    return value;
  }
  const jobName = requireCloudRunJobName(config);
  if (!jobName || !jobName.startsWith('projects/')) {
    return value;
  }
  return `${jobName}/executions/${value}`;
}

export function isLocalInlineExecution(executionName) {
  return String(executionName || '').startsWith('local-inline:');
}

function toEnvList(values) {
  return Object.entries(values)
    .filter(([, value]) => value !== undefined && value !== null && value !== '')
    .map(([name, value]) => ({
      name,
      value: String(value),
    }));
}

export function createCloudRunClient(config) {
  let authPromise = null;

  async function request({ url, method = 'GET', data }) {
    if (!authPromise) {
      authPromise = createAuth();
    }
    const auth = await authPromise;
    const response = await auth.request({ url, method, data });
    return response.data;
  }

  return {
    async runReportJob({ jobId, startToken }) {
      const jobName = requireCloudRunJobName(config);
      if (!jobName && config.allowNoopCloudRunStart) {
        return {
          jobName: null,
          executionName: null,
          noop: true,
        };
      }

      const data = await request({
        url: `https://run.googleapis.com/v2/${jobName}:run`,
        method: 'POST',
        data: {
          overrides: {
            containerOverrides: [{
              env: toEnvList({
                CLASH_JOB_ID: jobId,
                CLASH_START_TOKEN: startToken,
              }),
            }],
          },
        },
      });

      return {
        jobName,
        executionName: extractExecutionName(data),
        operationName: data?.name || null,
        raw: data,
      };
    },

    async cancelExecution(executionName) {
      const executionResourceName = resolveExecutionName(config, executionName);
      if (!executionResourceName) {
        return null;
      }

      return request({
        url: `https://run.googleapis.com/v2/${executionResourceName}:cancel`,
        method: 'POST',
        data: {},
      });
    },

    async getExecution(executionName) {
      const executionResourceName = resolveExecutionName(config, executionName);
      if (!executionResourceName) {
        return null;
      }

      return request({
        url: `https://run.googleapis.com/v2/${executionResourceName}`,
        method: 'GET',
      });
    },
  };
}

export function isCloudRunExecutionTerminal(execution) {
  if (!execution) {
    return false;
  }
  if (execution.completionTime) {
    return true;
  }

  const completedCondition = (execution.conditions || []).find(condition => condition.type === 'Completed');
  return [
    'True',
    'False',
    'CONDITION_SUCCEEDED',
    'CONDITION_FAILED',
  ].includes(completedCondition?.state);
}

export function didCloudRunExecutionSucceed(execution) {
  const completedCondition = (execution?.conditions || []).find(condition => condition.type === 'Completed');
  return ['True', 'CONDITION_SUCCEEDED'].includes(completedCondition?.state);
}
