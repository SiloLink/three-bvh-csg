// IFC entity types that are never meaningful clash participants: non-geometric
// reference and spatial entities (reference grids, spatial containers), MEP
// connection ports, and abstract spatial features. They carry no clashable solid
// geometry, so they are excluded BOTH from the clash-matrix entity-type catalog
// offered to API clients AND from broad-phase object building — the two must stay
// in sync, which is why this single set is the shared source of truth.
//
// Types that DO have geometry and could produce a meaningful clash (e.g.
// IfcCovering, IfcFurnishingElement, IfcOpeningElement, IfcSpace, IfcVirtualElement)
// are intentionally NOT listed here: whether to clash them is a per-pair user choice in the matrix,
// and intended contacts are removed precisely by the relationship-based semantic
// filters, never by a blanket entity-type exclusion.

// API clients decide whether IfcCovering, IfcFurnishingElement, IfcOpeningElement,
// IfcSpace, and IfcVirtualElement are added.
export const NON_CLASHABLE_ENTITY_TYPES = new Set([
  'IfcBuilding',
  'IfcBuildingStorey',
  'IfcDistributionPort',
  'IfcEarthworksCut',
  'IfcExternalSpatialElement',
  'IfcGrid',
  'IfcPort',
  'IfcProject',
  'IfcSite',
  'IfcSpatialZone',
  'IfcVoidingFeature',
]);
