export function parseGcsUri(uri, fieldName = 'GCS URI') {
  const value = String(uri || '').trim();
  const match = /^gs:\/\/([^/\s]+)(?:\/(.*))?$/.exec(value);
  if (!match) {
    throw new Error(`${fieldName} must be a gs://bucket/path URI.`);
  }

  const bucket = match[1];
  const object = (match[2] || '').replace(/^\/+/, '');
  const unsafeSegment = object
    .split('/')
    .some(segment => segment === '.' || segment === '..');
  if (unsafeSegment) {
    throw new Error(`${fieldName} must not contain . or .. path segments.`);
  }

  return { bucket, object };
}

export function formatGcsUri({ bucket, object = '' }) {
  const normalizedObject = String(object || '').replace(/^\/+/, '');
  return normalizedObject ? `gs://${bucket}/${normalizedObject}` : `gs://${bucket}`;
}

export function ensureTrailingSlash(value) {
  const text = String(value || '');
  if (!text) {
    return '';
  }
  return text.endsWith('/') ? text : `${text}/`;
}

export function joinGcsObject(prefix, name) {
  const normalizedPrefix = ensureTrailingSlash(String(prefix || '').replace(/^\/+/, ''));
  return `${normalizedPrefix}${String(name || '').replace(/^\/+/, '')}`;
}
