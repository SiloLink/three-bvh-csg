import { createNarrowPhaseRuntime } from '../core/narrow/narrow-phase.js';

let cancelRequested = false;

function send(message) {
  if (process.send) {
    process.send(message);
  }
}

function serializeError(error) {
  return {
    name: error?.name || null,
    code: error?.code || null,
    message: error?.message || String(error),
    phase: error?.phase || null,
    retryable: error?.retryable ?? null,
    stack: error?.stack || null,
  };
}

let runtime = null;
let runtimeKey = null;

async function disposeRuntime() {
  runtime?.dispose?.();
  runtime = null;
  runtimeKey = null;
}

async function getRuntime(message) {
  const nextRuntimeKey = JSON.stringify({
    projectDescriptor: message.projectDescriptor || null,
    cacheObjects: message.cacheObjects !== false,
    cacheObjectKeySignature: message.cacheObjectKeySignature || null,
    narrowPhaseSharedPrep: message.narrowPhaseSharedPrep !== false,
    narrowPhaseShareUncached: message.narrowPhaseShareUncached !== false,
    narrowPhaseGeometryBudgetBytes: message.narrowPhaseGeometryBudgetBytes || 0,
  });

  if (runtime && runtimeKey === nextRuntimeKey) {
    return runtime;
  }

  await disposeRuntime();
  runtime = await createNarrowPhaseRuntime({
    projectDescriptor: message.projectDescriptor,
    cacheObjects: message.cacheObjects !== false,
    cacheObjectKeys: message.cacheObjectKeys || null,
    narrowPhaseSharedPrep: message.narrowPhaseSharedPrep !== false,
    narrowPhaseShareUncached: message.narrowPhaseShareUncached !== false,
    narrowPhaseGeometryBudgetBytes: message.narrowPhaseGeometryBudgetBytes || 0,
  });
  runtimeKey = nextRuntimeKey;
  return runtime;
}

process.on('message', async message => {
  try {
    let result;

    if (message?.type === 'cancel') {
      cancelRequested = true;
      return;
    }

    if (message?.type === 'narrow-phase-pairs') {
      cancelRequested = false;
      const narrowPhaseRuntime = await getRuntime(message);
      result = await narrowPhaseRuntime.runPairs({
        pairs: message.pairs,
        cacheObjects: message.cacheObjects !== false,
        onProgress: progress => send({ type: 'progress', requestId: message.requestId, progress }),
        shouldCancel: () => cancelRequested,
      });
    } else if (message?.type === 'shutdown') {
      await disposeRuntime();
      send({ type: 'shutdown-completed', requestId: message.requestId });
      process.exit(0);
    } else {
      return;
    }

    send({ type: 'completed', requestId: message.requestId, result });
  } catch (error) {
    send({ type: 'failed', requestId: message?.requestId, error: serializeError(error) });
  }
});

process.on('uncaughtException', error => {
  send({ type: 'failed', error: serializeError(error) });
  process.exit(1);
});

process.on('unhandledRejection', error => {
  send({ type: 'failed', error: serializeError(error) });
  process.exit(1);
});
