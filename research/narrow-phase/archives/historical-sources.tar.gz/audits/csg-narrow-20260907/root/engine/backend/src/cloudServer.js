import Fastify from 'fastify';
import cors from '@fastify/cors';
import { resolveApiBodyLimitBytes } from './apiServerOptions.js';
import { registerCloudClashRoutes } from './cloud/routes.js';

const app = Fastify({
  logger: true,
  bodyLimit: resolveApiBodyLimitBytes(),
});

const corsOrigin = process.env.CORS_ORIGIN;
if (!corsOrigin) {
  throw new Error('CORS_ORIGIN must be set for the Cloud API server.');
}

await app.register(cors, {
  origin: corsOrigin,
});

app.get('/api/health', async () => ({ ok: true }));

await registerCloudClashRoutes(app);

await app.listen({
  host: process.env.HOST || '0.0.0.0',
  port: Number(process.env.PORT || 8080),
});
