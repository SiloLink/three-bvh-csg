import crypto from 'node:crypto';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, URL } from 'node:url';
import { REPORT_COLUMNS, columnsToCsvHeader, rowsToCsv } from './reportCsv.js';
import { ensureTrailingSlash, formatGcsUri, joinGcsObject, parseGcsUri } from './gcsUri.js';

const DEFAULT_GCS_OPERATION_TIMEOUT_MS = 120_000;
const PAIR_EVIDENCE_KINDS = new Set([
  'intentional-exclusions',
  'evaluation-failures',
]);

function safeReportName(value) {
  return String(value || 'broad-phase')
    .replace(/[^a-z0-9_-]+/gi, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80) || 'broad-phase';
}

function resolveFolderPath(folderPath) {
  const trimmedPath = String(folderPath || '').trim().replace(/^["']|["']$/g, '');
  if (!trimmedPath) {
    throw new Error('Folder path is required.');
  }

  return path.resolve(trimmedPath);
}

export function createReportFileName(basePathOrName, suffix = 'broad-narrow') {
  const rawName = path.basename(path.dirname(resolveFolderPath(basePathOrName)));
  const projectName = safeReportName(rawName);
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  return `${projectName}-${suffix}-${timestamp}.csv`;
}

export function createReportOutputPath(basePath) {
  const reportDir = fileURLToPath(new URL('../../reports', import.meta.url));
  return path.join(reportDir, createReportFileName(basePath));
}

export function resolveReportOutputPath(basePath, outputPath) {
  const trimmedPath = String(outputPath || '').trim().replace(/^["']|["']$/g, '');
  if (!trimmedPath) {
    return createReportOutputPath(basePath);
  }

  const resolvedPath = path.resolve(trimmedPath);
  if (path.extname(resolvedPath)) {
    return resolvedPath;
  }

  return path.join(resolvedPath, createReportFileName(basePath));
}

function writeToStream(stream, chunk) {
  return new Promise((resolve, reject) => {
    let settled = false;

    function settle(callback, value) {
      if (settled) {
        return;
      }
      settled = true;
      cleanup();
      callback(value);
    }

    function handleError(error) {
      settle(reject, error);
    }

    function cleanup() {
      stream.off('error', handleError);
    }

    stream.once('error', handleError);
    try {
      stream.write(chunk, error => {
        if (error) {
          settle(reject, error);
        } else {
          settle(resolve);
        }
      });
    } catch (error) {
      settle(reject, error);
    }
  });
}

function endStream(stream) {
  return new Promise((resolve, reject) => {
    function cleanup() {
      stream.off('close', handleClose);
      stream.off('error', handleError);
    }

    function handleClose() {
      cleanup();
      resolve();
    }

    function handleError(error) {
      cleanup();
      reject(error);
    }

    stream.once('close', handleClose);
    stream.once('error', handleError);
    stream.end();
  });
}

function replaceOrAppendSuffix(value, pattern, suffix) {
  return pattern.test(value) ? value.replace(pattern, suffix) : `${value}${suffix}`;
}

function localCoveragePath(reportPath) {
  const extension = path.extname(reportPath);
  return extension
    ? `${reportPath.slice(0, -extension.length)}.coverage.json`
    : `${reportPath}.coverage.json`;
}

function normalizePairEvidenceChunk(kind, chunk) {
  if (!PAIR_EVIDENCE_KINDS.has(kind)) {
    throw new Error(`Unsupported pair evidence kind: ${kind}`);
  }
  if (!Number.isInteger(chunk?.index) || chunk.index < 0) {
    throw new Error('Pair evidence chunk index must be a non-negative integer.');
  }
  if (!Buffer.isBuffer(chunk?.bytes)) {
    throw new Error('Pair evidence chunk bytes are required.');
  }
  return {
    kind,
    index: chunk.index,
    bytes: chunk.bytes,
    suffix: `${kind}.${String(chunk.index).padStart(6, '0')}.sha256`,
  };
}

export function createLocalReportWriter({
  basePath,
  outputPath,
  overwrite = false,
}) {
  if (typeof overwrite !== 'boolean') {
    throw new Error('Local report overwrite must be a boolean.');
  }
  const finalPath = resolveReportOutputPath(basePath, outputPath);
  const coveragePath = localCoveragePath(finalPath);
  let stagingPath = null;
  let stagingOwned = false;
  let stream = null;
  let streamInitializationPromise = null;
  let rowCount = 0;
  let sizeBytes = 0;
  let closed = false;
  let evaluatedCoverage = null;
  let coveragePublished = false;
  let coverageError = null;
  let coverageStagingDirPromise = null;
  const pairEvidenceChunks = [];
  const publishedPairEvidencePaths = [];

  async function getCoverageStagingDir() {
    if (!coverageStagingDirPromise) {
      coverageStagingDirPromise = fsp.mkdtemp(
        path.join(os.tmpdir(), 'clash-coverage-'),
      );
    }
    return coverageStagingDirPromise;
  }

  async function cleanupCoverageStagingBestEffort() {
    if (!coverageStagingDirPromise) return;
    const directory = await coverageStagingDirPromise.catch(() => null);
    if (directory) {
      await fsp.rm(directory, { recursive: true, force: true }).catch(() => {});
    }
  }

  async function cleanupPublishedPairEvidenceBestEffort() {
    await Promise.all(
      publishedPairEvidencePaths.map(chunkPath =>
        fsp.unlink(chunkPath).catch(() => {}),
      ),
    );
  }

  async function publishCoverageArtifacts() {
    for (const chunk of pairEvidenceChunks) {
      await fsp.copyFile(chunk.stagedPath, chunk.finalPath);
      publishedPairEvidencePaths.push(chunk.finalPath);
    }
    await fsp.writeFile(coveragePath, evaluatedCoverage.bytes);
    coveragePublished = true;
  }

  async function cleanupReportStagingBestEffort() {
    const ownedPath = stagingOwned ? stagingPath : null;
    stagingPath = null;
    stagingOwned = false;
    if (ownedPath) await fsp.unlink(ownedPath).catch(() => {});
  }

  async function syncReportStaging() {
    if (!stagingPath) return;
    const handle = await fsp.open(stagingPath, 'r+');
    try {
      await handle.sync();
    } finally {
      await handle.close();
    }
  }

  async function publishReportStaging() {
    if (!stagingPath) return;
    if (overwrite) {
      await fsp.rename(stagingPath, finalPath);
      stagingPath = null;
      stagingOwned = false;
      return;
    }

    try {
      // rename() has no no-replace mode in Node. A same-directory hard link is
      // the atomic no-clobber publication primitive; unlink then removes the
      // private staging name while the complete inode remains at finalPath.
      await fsp.link(stagingPath, finalPath);
    } catch (error) {
      if (error?.code === 'EEXIST') {
        throw new Error(`Local report already exists: ${finalPath}`, {
          cause: error,
        });
      }
      throw error;
    }
    await fsp.unlink(stagingPath);
    stagingPath = null;
    stagingOwned = false;
  }

  async function initializeStream() {
    await fsp.mkdir(path.dirname(finalPath), { recursive: true });
    if (closed) {
      throw new Error('Local report writer is closed.');
    }
    const nextStagingPath = path.join(
      path.dirname(finalPath),
      `.${path.basename(finalPath)}.${crypto.randomUUID()}.tmp`,
    );
    const writable = fs.createWriteStream(nextStagingPath, {
      encoding: 'utf8',
      flags: 'wx',
    });
    await new Promise((resolve, reject) => {
      function cleanup() {
        writable.off('error', handleError);
        writable.off('open', handleOpen);
      }

      function handleError(error) {
        cleanup();
        reject(error);
      }

      function handleOpen() {
        cleanup();
        resolve();
      }

      writable.once('error', handleError);
      writable.once('open', handleOpen);
    });
    stagingPath = nextStagingPath;
    stagingOwned = true;
    stream = writable;
    if (closed) {
      writable.destroy();
      await cleanupReportStagingBestEffort();
      throw new Error('Local report writer is closed.');
    }
    return writable;
  }

  async function ensureStream() {
    if (closed) {
      throw new Error('Local report writer is closed.');
    }
    if (!streamInitializationPromise) {
      streamInitializationPromise = initializeStream();
    }
    return streamInitializationPromise;
  }

  async function writeCsv(csv, rowsWritten = 0) {
    const writable = await ensureStream();
    await writeToStream(writable, csv);
    rowCount += rowsWritten;
    sizeBytes += Buffer.byteLength(csv, 'utf8');
  }

  return {
    kind: 'local',
    outputPath: finalPath,
    getResult() {
      return {
        outputPath: finalPath,
        resultUri: null,
        resultSizeBytes: sizeBytes,
        resultRowCount: rowCount,
        evaluatedCoverageUri: coveragePublished ? coveragePath : null,
        evaluatedCoverageDigest: coveragePublished ? evaluatedCoverage?.digest : null,
        evaluatedCoverageSchemaVersion: coveragePublished
          ? evaluatedCoverage?.schemaVersion
          : null,
        evaluatedCoverageSizeBytes: coveragePublished
          ? evaluatedCoverage?.bytes.length
          : null,
        evaluatedCoverageError: coverageError,
      };
    },
    async writeHeader(columns = REPORT_COLUMNS) {
      await writeCsv(columnsToCsvHeader(columns), 0);
    },
    async writeRows(rows) {
      if (!Array.isArray(rows) || rows.length === 0) {
        return;
      }
      await writeCsv(rowsToCsv(rows, { includeHeader: false }), rows.length);
    },
    async writeEvaluatedCoverage(coverage) {
      if (!Buffer.isBuffer(coverage?.bytes)) {
        throw new Error('Evaluated coverage bytes are required.');
      }
      evaluatedCoverage = coverage;
    },
    async writePairEvidenceChunk(kind, chunk) {
      const normalized = normalizePairEvidenceChunk(kind, chunk);
      const coverageStem = coveragePath.replace(/\.json$/u, '');
      const finalChunkPath = `${coverageStem}.${normalized.suffix}`;
      const stagedPath = path.join(
        await getCoverageStagingDir(),
        path.basename(finalChunkPath),
      );
      await fsp.writeFile(stagedPath, normalized.bytes);
      pairEvidenceChunks.push({
        stagedPath,
        finalPath: finalChunkPath,
      });
      return { uri: finalChunkPath };
    },
    async close({ success = true } = {}) {
      if (closed) {
        return this.getResult();
      }
      closed = true;
      try {
        if (streamInitializationPromise) {
          await streamInitializationPromise;
        }
        if (stream) {
          await endStream(stream);
          stream = null;
        }
        if (!success) {
          await cleanupReportStagingBestEffort();
          return this.getResult();
        }
        if (stagingPath) {
          await syncReportStaging();
          await publishReportStaging();
        }
        if (evaluatedCoverage) {
          try {
            await publishCoverageArtifacts();
          } catch (error) {
            coverageError = error instanceof Error ? error.message : String(error);
            await cleanupPublishedPairEvidenceBestEffort();
          }
        }
        return this.getResult();
      } catch (error) {
        await cleanupReportStagingBestEffort();
        throw error;
      } finally {
        await cleanupCoverageStagingBestEffort();
      }
    },
    async abort() {
      const writable = stream;
      if (writable && !closed) {
        writable.destroy();
      }
      closed = true;
      await streamInitializationPromise?.catch(() => {});
      stream = null;
      await cleanupReportStagingBestEffort();
      await cleanupPublishedPairEvidenceBestEffort();
      await cleanupCoverageStagingBestEffort();
    },
  };
}

function safeObjectNamePart(value) {
  return safeReportName(value).toLowerCase();
}

export function resolveCloudReportTarget({
  outputUri,
  outputPrefix,
  jobId = crypto.randomUUID(),
  projectGuid = 'project',
  tempOutputPrefix,
}) {
  const fileName = `${safeObjectNamePart(projectGuid)}-clash-report-${jobId}.csv`;
  let final;

  if (outputUri) {
    const parsed = parseGcsUri(outputUri, 'outputUri');
    const object = parsed.object.endsWith('/') || parsed.object === ''
      ? joinGcsObject(parsed.object, fileName)
      : parsed.object;
    final = { bucket: parsed.bucket, object };
  } else if (outputPrefix) {
    const parsed = parseGcsUri(outputPrefix, 'outputPrefix');
    final = {
      bucket: parsed.bucket,
      object: joinGcsObject(ensureTrailingSlash(parsed.object), fileName),
    };
  } else {
    throw new Error('Either outputUri or outputPrefix is required.');
  }

  let temp;
  if (tempOutputPrefix) {
    const parsedTemp = parseGcsUri(tempOutputPrefix, 'tempOutputPrefix');
    temp = {
      bucket: parsedTemp.bucket,
      object: joinGcsObject(parsedTemp.object, `${jobId}-${path.basename(final.object)}.tmp`),
    };
  } else {
    const finalDir = path.dirname(final.object);
    const prefix = finalDir === '.' ? `.tmp/clash-reports/${jobId}` : `${finalDir}/.tmp/${jobId}`;
    temp = {
      bucket: final.bucket,
      object: joinGcsObject(prefix, `${path.basename(final.object)}.tmp`),
    };
  }

  return {
    resultUri: formatGcsUri(final),
    tempResultUri: formatGcsUri(temp),
    final,
    temp,
    coverage: {
      final: {
        bucket: final.bucket,
        object: replaceOrAppendSuffix(
          final.object,
          /\.csv$/i,
          '.coverage.json',
        ),
      },
      temp: {
        bucket: temp.bucket,
        object: replaceOrAppendSuffix(
          temp.object,
          /\.csv\.tmp$/i,
          '.coverage.json.tmp',
        ),
      },
    },
  };
}

async function createStorageClient() {
  const { Storage } = await import('@google-cloud/storage');
  return new Storage({ timeout: DEFAULT_GCS_OPERATION_TIMEOUT_MS });
}

export function createCloudReportWriter({
  outputUri,
  outputPrefix,
  tempOutputPrefix,
  jobId,
  projectGuid,
  storageClientFactory = createStorageClient,
  gcsOperationTimeoutMs = DEFAULT_GCS_OPERATION_TIMEOUT_MS,
}) {
  const target = resolveCloudReportTarget({
    outputUri,
    outputPrefix,
    tempOutputPrefix,
    jobId,
    projectGuid,
  });
  let storagePromise = null;
  let localDirPromise = null;
  let stream = null;
  let rowCount = 0;
  let sizeBytes = 0;
  let closed = false;
  let promoted = false;
  let uploadedReportTemp = false;
  let uploadedCoverageTemp = false;
  const uploadedPairEvidenceTemps = [];
  const publishedPairEvidenceFinals = [];
  let evaluatedCoverage = null;
  let coveragePublished = false;
  let coverageError = null;
  const localReportName = path.basename(target.temp.object);
  const pairEvidenceChunks = [];

  async function getStorage() {
    if (!storagePromise) {
      storagePromise = storageClientFactory();
    }
    return storagePromise;
  }

  async function getLocalDir() {
    if (!localDirPromise) {
      const prefix = path.join(os.tmpdir(), `clash-report-${safeReportName(jobId)}-`);
      localDirPromise = fsp.mkdtemp(prefix);
    }
    return localDirPromise;
  }

  async function getLocalReportPath() {
    return path.join(await getLocalDir(), localReportName);
  }

  async function ensureStream() {
    if (stream) {
      return stream;
    }

    stream = fs.createWriteStream(await getLocalReportPath(), { encoding: 'utf8' });

    return stream;
  }

  async function writeCsv(csv, rowsWritten = 0) {
    const writable = await ensureStream();
    await writeToStream(writable, csv);
    rowCount += rowsWritten;
    sizeBytes += Buffer.byteLength(csv, 'utf8');
  }

  async function deleteTempBestEffort() {
    if (!uploadedReportTemp) {
      return;
    }
    const storage = await getStorage();
    await storage.bucket(target.temp.bucket).file(target.temp.object).delete({ ignoreNotFound: true }).catch(() => {});
  }

  async function deleteCoverageTempBestEffort() {
    const storage = await getStorage();
    if (uploadedCoverageTemp) {
      await storage
        .bucket(target.coverage.temp.bucket)
        .file(target.coverage.temp.object)
        .delete({ ignoreNotFound: true })
        .catch(() => {});
    }
    await Promise.all(
      uploadedPairEvidenceTemps.map(chunk =>
        storage
          .bucket(chunk.bucket)
          .file(chunk.object)
          .delete({ ignoreNotFound: true })
          .catch(() => {}),
      ),
    );
  }

  async function deletePublishedPairEvidenceBestEffort() {
    if (publishedPairEvidenceFinals.length === 0) return;
    const storage = await getStorage();
    await Promise.all(
      publishedPairEvidenceFinals.map(chunk =>
        storage
          .bucket(chunk.bucket)
          .file(chunk.object)
          .delete({ ignoreNotFound: true })
          .catch(() => {}),
      ),
    );
  }

  async function cleanupLocalBestEffort() {
    if (!localDirPromise) {
      return;
    }
    const localDir = await localDirPromise.catch(() => null);
    if (localDir) {
      await fsp.rm(localDir, { recursive: true, force: true }).catch(() => {});
    }
  }

  async function uploadLocalReport(storage) {
    await storage.bucket(target.temp.bucket).upload(await getLocalReportPath(), {
      destination: target.temp.object,
      resumable: false,
      timeout: gcsOperationTimeoutMs,
      contentType: 'text/csv; charset=utf-8',
      metadata: {
        cacheControl: 'no-store',
      },
    });
    uploadedReportTemp = true;
  }

  async function saveArtifactBytes(storage, targetObject, bytes, contentType) {
    await storage
      .bucket(targetObject.bucket)
      .file(targetObject.object)
      .save(bytes, {
        resumable: false,
        timeout: gcsOperationTimeoutMs,
        contentType,
        metadata: { cacheControl: 'no-store' },
      });
  }

  async function uploadEvaluatedCoverage(storage) {
    if (!evaluatedCoverage) return;
    for (const chunk of pairEvidenceChunks) {
      await saveArtifactBytes(
        storage,
        chunk.temp,
        chunk.bytes,
        'text/plain; charset=utf-8',
      );
      uploadedPairEvidenceTemps.push(chunk.temp);
      await storage
        .bucket(chunk.temp.bucket)
        .file(chunk.temp.object)
        .copy(storage.bucket(chunk.final.bucket).file(chunk.final.object));
      publishedPairEvidenceFinals.push(chunk.final);
    }
    await saveArtifactBytes(
      storage,
      target.coverage.temp,
      evaluatedCoverage.bytes,
      'application/json',
    );
    uploadedCoverageTemp = true;
    await storage
      .bucket(target.coverage.temp.bucket)
      .file(target.coverage.temp.object)
      .copy(
        storage
          .bucket(target.coverage.final.bucket)
          .file(target.coverage.final.object),
      );
    coveragePublished = true;
    await deleteCoverageTempBestEffort();
  }

  return {
    kind: 'gcs',
    resultUri: target.resultUri,
    tempResultUri: target.tempResultUri,
    getResult() {
      return {
        outputPath: null,
        resultUri: promoted ? target.resultUri : null,
        tempResultUri: target.tempResultUri,
        resultSizeBytes: sizeBytes,
        resultRowCount: rowCount,
        evaluatedCoverageUri: coveragePublished
          ? formatGcsUri(target.coverage.final)
          : null,
        evaluatedCoverageDigest: coveragePublished ? evaluatedCoverage?.digest : null,
        evaluatedCoverageSchemaVersion: coveragePublished
          ? evaluatedCoverage?.schemaVersion
          : null,
        evaluatedCoverageSizeBytes: coveragePublished
          ? evaluatedCoverage?.bytes.length
          : null,
        evaluatedCoverageError: coverageError,
      };
    },
    async writeHeader(columns = REPORT_COLUMNS) {
      await writeCsv(columnsToCsvHeader(columns), 0);
    },
    async writeRows(rows) {
      if (!Array.isArray(rows) || rows.length === 0) {
        return;
      }
      await writeCsv(rowsToCsv(rows, { includeHeader: false }), rows.length);
    },
    async writeEvaluatedCoverage(coverage) {
      if (!Buffer.isBuffer(coverage?.bytes)) {
        throw new Error('Evaluated coverage bytes are required.');
      }
      evaluatedCoverage = coverage;
    },
    async writePairEvidenceChunk(kind, chunk) {
      const normalized = normalizePairEvidenceChunk(kind, chunk);
      const finalStem = target.coverage.final.object.replace(/\.json$/i, '');
      const tempStem = target.coverage.temp.object.replace(/\.json\.tmp$/i, '');
      const final = {
        bucket: target.coverage.final.bucket,
        object: `${finalStem}.${normalized.suffix}`,
      };
      const temp = {
        bucket: target.coverage.temp.bucket,
        object: `${tempStem}.${normalized.suffix}.tmp`,
      };
      pairEvidenceChunks.push({ final, temp, bytes: normalized.bytes });
      return { uri: formatGcsUri(final) };
    },
    async close({ success = true } = {}) {
      if (closed) {
        return this.getResult();
      }
      closed = true;
      if (stream) {
        await endStream(stream);
      }

      if (!success) {
        await deleteTempBestEffort();
        await cleanupLocalBestEffort();
        return this.getResult();
      }

      try {
        const storage = await getStorage();
        await uploadLocalReport(storage);
        await storage
          .bucket(target.temp.bucket)
          .file(target.temp.object)
          .copy(storage.bucket(target.final.bucket).file(target.final.object));
        promoted = true;
        await deleteTempBestEffort();
        try {
          await uploadEvaluatedCoverage(storage);
        } catch (error) {
          coverageError = error instanceof Error ? error.message : String(error);
          await deleteCoverageTempBestEffort();
          await deletePublishedPairEvidenceBestEffort();
        }

        return this.getResult();
      } catch (error) {
        await deleteTempBestEffort();
        throw error;
      } finally {
        await cleanupLocalBestEffort();
      }
    },
    async abort() {
      if (stream && !closed) {
        stream.destroy();
      }
      closed = true;
      await deleteTempBestEffort();
      await deleteCoverageTempBestEffort();
      await deletePublishedPairEvidenceBestEffort();
      await cleanupLocalBestEffort();
    },
  };
}

export function createReportWriter(options) {
  if (options.outputUri || options.outputPrefix) {
    return createCloudReportWriter(options);
  }

  return createLocalReportWriter(options);
}
