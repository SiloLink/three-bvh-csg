export const REPORT_COLUMNS = [
  'Clash GUID',
  'Object 1 GlobalID',
  'Object 1 Model ID',
  'Object 1 Discipline',
  'Object 1 Type',
  'Object 2 GlobalID',
  'Object 2 Model ID',
  'Object 2 Discipline',
  'Object 2 Type',
  'Collision',
  'Clash Type',
  'Volume (mm3)',
  'Box X (mm)',
  'Box Y (mm)',
  'Box Z (mm)',
  'Error',
];

export function escapeCsvValue(value) {
  const text = String(value ?? '');
  if (/[",\r\n]/.test(text)) {
    return `"${text.replaceAll('"', '""')}"`;
  }

  return text;
}

export function rowsToCsv(rows, { includeHeader = true } = {}) {
  const lines = includeHeader ? [REPORT_COLUMNS.map(escapeCsvValue).join(',')] : [];
  for (const row of rows) {
    lines.push(REPORT_COLUMNS.map(column => escapeCsvValue(row[column])).join(','));
  }

  return `${lines.join('\r\n')}\r\n`;
}

export function columnsToCsvHeader(columns = REPORT_COLUMNS) {
  return `${columns.map(escapeCsvValue).join(',')}\r\n`;
}

export function broadPhaseExceptionToReportRow(exception, index) {
  return {
    'Clash GUID': `broad-phase-exception-${index + 1}`,
    'Object 1 GlobalID': exception.globalId,
    'Object 1 Model ID': exception.modelId,
    'Object 1 Discipline': exception.discipline,
    'Object 1 Type': exception.entityType || exception.ifcType,
    'Object 2 GlobalID': '',
    'Object 2 Model ID': '',
    'Object 2 Discipline': '',
    'Object 2 Type': '',
    Collision: 'ERROR',
    'Clash Type': 'NA',
    'Volume (mm3)': 'NA',
    'Box X (mm)': 'NA',
    'Box Y (mm)': 'NA',
    'Box Z (mm)': 'NA',
    Error: `${exception.reason}: ${exception.message}`,
  };
}

export function shouldWriteReportRow(row) {
  return row.Collision !== 'FALSE' || (row.Error && row.Error !== 'NA');
}
