import { boxesNearlyMutuallyContain } from './geometry-metrics.js';

export function classifyClash({
  collision,
  volumeA,
  volumeB,
  intersectionVolume,
  boxA,
  boxB,
  boxContainmentTolerance,
  duplicateVolumeDiffRatio,
  intersectionVolumeMatchRatio,
}) {
  if (!collision) {
    return 'NA';
  }

  const minVolume = Math.min(volumeA, volumeB);
  const maxVolume = Math.max(volumeA, volumeB);
  if (minVolume <= 0 || maxVolume <= 0) {
    return 'Overlapping';
  }

  const volumeDiffRatio = Math.abs(volumeA - volumeB) / maxVolume;
  const intersectionMatchesMinVolume = intersectionVolume >= intersectionVolumeMatchRatio * minVolume;

  if (
    boxesNearlyMutuallyContain(boxA, boxB, boxContainmentTolerance)
    && volumeDiffRatio <= duplicateVolumeDiffRatio
    && intersectionMatchesMinVolume
  ) {
    return 'Duplicate';
  }

  return 'Overlapping';
}
