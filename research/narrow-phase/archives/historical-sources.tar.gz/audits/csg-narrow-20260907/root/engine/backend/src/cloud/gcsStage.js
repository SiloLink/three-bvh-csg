import fs from 'node:fs/promises';
import path from 'node:path';
import { throwIfCanceled } from '../cancellation.js';
import { MODEL_FILE_SPECS } from '../core/model/model-files.js';
import { createCloudProjectDescriptor } from './projectDescriptor.js';
import { requireFolderName } from './validation.js';

let storagePromise = null;

async function getStorage() {
  if (!storagePromise) {
    const { Storage } = await import('@google-cloud/storage');
    storagePromise = Promise.resolve(new Storage());
  }

  return storagePromise;
}

function getPinnedModelObjects(model) {
  if (!model.sourceObjects) {
    throw new Error(`Pinned model source objects are required for ${model.modelGuid}.`);
  }

  return MODEL_FILE_SPECS.map(({ key, fileName }) => {
    const sourceObject = model.sourceObjects[key];
    const bucket = String(sourceObject?.bucket || '').trim();
    const object = String(sourceObject?.object || '').trim();
    const generation = String(sourceObject?.generation || '').trim();
    if (!bucket || !object || !generation || path.basename(object) !== fileName) {
      throw new Error(`Pinned model source object is invalid: ${key}.`);
    }
    return { bucket, object, generation, fileName };
  });
}

async function downloadPinnedModelObjects({ sourceObjects, targetPath, storage }) {
  const resolvedStorage = storage || await getStorage();
  await fs.mkdir(targetPath, { recursive: true });
  await Promise.all(sourceObjects.map(async sourceObject => {
    const destination = path.join(targetPath, sourceObject.fileName);
    await resolvedStorage
      .bucket(sourceObject.bucket)
      .file(sourceObject.object, { generation: sourceObject.generation })
      .download({ destination });
  }));
}

async function stageOneModel({ model, basePath, shouldCancel, storage }) {
  const folderName = requireFolderName(model);
  await throwIfCanceled(shouldCancel, `staging ${folderName}`);
  const targetPath = path.join(basePath, folderName);
  const pinnedSourceObjects = getPinnedModelObjects(model);

  await downloadPinnedModelObjects({
    sourceObjects: pinnedSourceObjects,
    targetPath,
    storage,
  });
  return folderName;
}

export async function stageGcsModelInputs({
  jobId,
  projectGuid = null,
  models,
  shouldCancel,
  storage = null,
}) {
  const rootPath = path.join('/tmp/clash', jobId);
  const basePath = path.join(rootPath, 'base');

  await throwIfCanceled(shouldCancel, 'input staging');
  await fs.rm(rootPath, { recursive: true, force: true });
  await fs.mkdir(basePath, { recursive: true });

  try {
    for (const model of models) {
      const folderName = await stageOneModel({
        model,
        basePath,
        shouldCancel,
        storage,
      });
      await throwIfCanceled(shouldCancel, `staging ${folderName}`);
    }
  } catch (error) {
    await fs.rm(rootPath, { recursive: true, force: true }).catch(() => {});
    throw error;
  }

  return {
    rootPath,
    basePath,
    projectDescriptor: createCloudProjectDescriptor({
      projectGuid,
      basePath,
      models,
    }),
  };
}
