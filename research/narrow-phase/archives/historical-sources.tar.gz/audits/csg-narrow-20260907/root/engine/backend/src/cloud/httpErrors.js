export class HttpError extends Error {
  constructor(statusCode, code, message, details = {}) {
    super(message);
    this.name = 'HttpError';
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
  }
}

export function badRequest(code, message, details = {}) {
  return new HttpError(400, code, message, details);
}

export function unauthorized(code = 'UNAUTHENTICATED', message = 'Authentication is required.') {
  return new HttpError(401, code, message);
}

export function forbidden(code = 'FORBIDDEN', message = 'Access is denied.') {
  return new HttpError(403, code, message);
}

export function conflict(code, message, details = {}) {
  return new HttpError(409, code, message, details);
}

export function tooManyRequests(code, message, details = {}) {
  return new HttpError(429, code, message, details);
}

export function serviceUnavailable(code, message, details = {}) {
  return new HttpError(503, code, message, details);
}

export function serializeHttpError(error) {
  if (error instanceof HttpError) {
    return {
      statusCode: error.statusCode,
      payload: {
        error: error.code,
        message: error.message,
        ...error.details,
      },
    };
  }

  return {
    statusCode: 500,
    payload: {
      error: 'INTERNAL_ERROR',
      message: error?.message || String(error),
    },
  };
}
