import { fork } from 'node:child_process';
import os from 'node:os';
import { performance } from 'node:perf_hooks';
import { fileURLToPath, URL } from 'node:url';
import {
  buildBroadPhaseDataset,
  runBroadPhaseCandidateBatches,
} from '../core/broad/broad-phase.js';
import { CancellationError, CANCELLATION_CODE, throwIfCanceled } from '../cancellation.js';
import { getCandidateEndpointKey } from '../core/candidate-pair.js';
import { createProjectDescriptor } from '../core/project-descriptor.js';
import {
  MAX_CLASH_BATCH_SIZE,
  normalizeClashBatchSize,
} from '../core/runtime-limits.js';
import {
  REPORT_COLUMNS,
  broadPhaseExceptionToReportRow,
  shouldWriteReportRow,
} from '../io/reportCsv.js';
import { createNarrowPhaseTimingAccumulator } from './narrow-phase-timing.js';
import {
  buildEvaluatedCoverageArtifact,
  serializeEvaluatedCoverageArtifact,
} from './evaluated-coverage.js';
import { createPairHashEvidenceAccumulator } from './pair-hash-evidence.js';

const CANCEL_POLL_MS = 1000;
const CHILD_CANCEL_GRACE_MS = 5000;
const HOT_OBJECT_CACHE_MIN_FREQUENCY = 5;
const MAX_DEFAULT_NARROW_PHASE_WORKERS = 4;
const NARROW_PHASE_OUTSTANDING_BATCH_MULTIPLIER = 2;
const DEFAULT_NARROW_PHASE_WORKER_IDLE_TIMEOUT_MS = 10 * 60 * 1000;
const WORKER_WATCHDOG_POLL_MS = 5000;

function elapsedMs(startedAtMs) {
  return Number((performance.now() - startedAtMs).toFixed(3));
}

async function timePhase(phaseTimings, name, callback) {
  const startedAtMs = performance.now();
  try {
    return await callback();
  } finally {
    phaseTimings[name] = elapsedMs(startedAtMs);
  }
}

export async function initializeReportFile(writer, exceptions) {
  await writer.writeHeader(REPORT_COLUMNS);
  if (exceptions.length > 0) {
    await writer.writeRows(exceptions.map(broadPhaseExceptionToReportRow));
  }
}

function getDefaultNarrowPhaseWorkerCount() {
  const envValue = Number(process.env.NARROW_PHASE_WORKERS);
  if (Number.isFinite(envValue) && envValue >= 1) {
    return Math.floor(envValue);
  }

  const availableParallelism = typeof os.availableParallelism === 'function'
    ? os.availableParallelism()
    : os.cpus().length;
  return Math.max(1, Math.min(MAX_DEFAULT_NARROW_PHASE_WORKERS, availableParallelism - 1));
}

function normalizeNarrowPhaseWorkerCount(value) {
  const numericValue = Number(value ?? getDefaultNarrowPhaseWorkerCount());
  if (!Number.isFinite(numericValue) || numericValue < 1) {
    return getDefaultNarrowPhaseWorkerCount();
  }

  return Math.floor(numericValue);
}

function normalizePositiveInteger(value, defaultValue) {
  const numericValue = Number(value);
  if (!Number.isFinite(numericValue) || numericValue < 0) {
    return defaultValue;
  }

  return Math.floor(numericValue);
}

function getNarrowPhaseWorkerIdleTimeoutMs(value) {
  return normalizePositiveInteger(
    value ?? process.env.NARROW_PHASE_WORKER_IDLE_TIMEOUT_MS,
    DEFAULT_NARROW_PHASE_WORKER_IDLE_TIMEOUT_MS,
  );
}

function getPairGlobalId(pair, side) {
  return pair?.[side]?.globalId
    ?? pair?.[side]?.GlobalId
    ?? pair?.[side]?.global_id
    ?? pair?.[`${side}GlobalId`]
    ?? pair?.[`${side}Guid`]
    ?? null;
}

function summarizeCandidatePair(pair) {
  return {
    sourceGlobalId: getPairGlobalId(pair, 'source'),
    targetGlobalId: getPairGlobalId(pair, 'target'),
    sourceType: pair?.source?.type ?? pair?.source?.entityType ?? pair?.sourceType ?? null,
    targetType: pair?.target?.type ?? pair?.target?.entityType ?? pair?.targetType ?? null,
  };
}

function createBatchDebugContext(batchInfo, candidates) {
  return {
    batchNumber: batchInfo.batchNumber,
    candidateCount: candidates.length,
    totalCandidateCount: batchInfo.totalCandidateCount,
    firstCandidate: summarizeCandidatePair(candidates[0]),
    lastCandidate: summarizeCandidatePair(candidates[candidates.length - 1]),
  };
}

function summarizeActiveBatch(entry) {
  const nowMs = performance.now();
  return {
    ...entry.debugContext,
    ageMs: Number((nowMs - entry.startedAtMs).toFixed(3)),
    lastProgressAgeMs: entry.lastProgressAtMs
      ? Number((nowMs - entry.lastProgressAtMs).toFixed(3))
      : null,
    lastProgress: entry.lastProgress || null,
  };
}

function serializeWorkerError(errorPayload) {
  if (errorPayload?.code === CANCELLATION_CODE || errorPayload?.name === 'CancellationError') {
    return new CancellationError(errorPayload.message);
  }

  const error = new Error(errorPayload?.message || 'Narrow phase worker failed.');
  if (errorPayload?.stack) {
    error.stack = errorPayload.stack;
  }
  if (errorPayload?.code) {
    error.code = errorPayload.code;
  }
  return error;
}

export function runNarrowPhaseWorker(body, hooks = {}) {
  const batchWorkerPath = fileURLToPath(new URL('../workers/batchWorker.js', import.meta.url));
  const backendRoot = fileURLToPath(new URL('../..', import.meta.url));
  const onProgress = typeof hooks.onProgress === 'function' ? hooks.onProgress : async () => {};
  const shouldCancel = typeof hooks.shouldCancel === 'function' ? hooks.shouldCancel : async () => false;

  return new Promise((resolve, reject) => {
    const worker = fork(batchWorkerPath, [], {
      cwd: backendRoot,
      execArgv: ['--preserve-symlinks'],
      silent: true,
    });
    let settled = false;
    let cancelRequested = false;
    let cancelKillTimer = null;
    let workerErrorLog = '';
    let progressChain = Promise.resolve();

    function cleanup() {
      clearInterval(cancelInterval);
      if (cancelKillTimer) {
        clearTimeout(cancelKillTimer);
      }
    }

    function requestChildCancel() {
      if (cancelRequested || settled) {
        return;
      }

      cancelRequested = true;
      worker.send?.({ type: 'cancel' });
      cancelKillTimer = setTimeout(() => {
        if (!settled) {
          worker.kill('SIGTERM');
        }
      }, CHILD_CANCEL_GRACE_MS);
    }

    async function checkCancellation() {
      if (settled) {
        return;
      }

      try {
        if (await shouldCancel()) {
          requestChildCancel();
        }
      } catch (error) {
        finish(error);
      }
    }

    function finish(error, result) {
      if (settled) {
        return;
      }

      settled = true;
      cleanup();
      worker.kill();
      if (error) {
        reject(error);
      } else {
        resolve(result);
      }
    }

    const cancelInterval = setInterval(checkCancellation, CANCEL_POLL_MS);

    worker.stderr?.on('data', chunk => {
      workerErrorLog += String(chunk);
    });

    worker.on('message', message => {
      if (message?.type === 'progress') {
        progressChain = progressChain
          .then(() => onProgress(message.progress || {}))
          .then(checkCancellation)
          .catch(error => finish(error));
        return;
      }

      if (message?.type === 'completed') {
        progressChain
          .then(() => {
            if (cancelRequested) {
              finish(new CancellationError('Narrow phase worker was canceled.'));
            } else {
              finish(null, message.result);
            }
          })
          .catch(error => finish(error));
        return;
      }

      if (message?.type === 'failed') {
        finish(serializeWorkerError(message.error));
      }
    });

    worker.on('error', error => {
      finish(error);
    });

    worker.on('exit', (code, signal) => {
      if (settled) {
        return;
      }

      if (cancelRequested) {
        finish(new CancellationError('Narrow phase worker was canceled.'));
        return;
      }

      const detail = workerErrorLog ? ` ${workerErrorLog}` : '';
      if (code === 0) {
        finish(new Error(`Narrow phase worker exited without sending a completion message. code=0 signal=${signal ?? 'NA'}.${detail}`));
        return;
      }

      finish(new Error(`Narrow phase worker exited before completion. code=${code ?? 'NA'} signal=${signal ?? 'NA'}.${detail}`));
    });

    checkCancellation().then(() => {
      if (!settled) {
        worker.send({
          type: 'narrow-phase-pairs',
          projectDescriptor: body.projectDescriptor,
          pairs: body.pairs || body.candidates,
          cacheObjects: body.cacheObjects !== false,
          cacheObjectKeys: body.cacheObjectKeys || null,
          cacheObjectKeySignature: body.cacheObjectKeySignature || null,
          narrowPhaseSharedPrep: body.narrowPhaseSharedPrep !== false,
          narrowPhaseShareUncached: body.narrowPhaseShareUncached !== false,
          narrowPhaseGeometryBudgetBytes: body.narrowPhaseGeometryBudgetBytes || 0,
        });
      }
    }).catch(error => finish(error));
  });
}

function createNarrowPhaseWorkerClient(hooks = {}) {
  const batchWorkerPath = fileURLToPath(new URL('../workers/batchWorker.js', import.meta.url));
  const backendRoot = fileURLToPath(new URL('../..', import.meta.url));
  const shouldCancel = typeof hooks.shouldCancel === 'function' ? hooks.shouldCancel : async () => false;
  const workerId = hooks.workerId || null;
  const idleTimeoutMs = getNarrowPhaseWorkerIdleTimeoutMs(hooks.idleTimeoutMs);
  const worker = fork(batchWorkerPath, [], {
    cwd: backendRoot,
    execArgv: ['--preserve-symlinks'],
    silent: true,
  });
  const pending = new Map();
  let nextRequestId = 1;
  let workerErrorLog = '';
  let closed = false;
  let cancelRequested = false;
  let cancelKillTimer = null;
  let activeCacheObjectKeySignature = null;

  function cleanup() {
    clearInterval(cancelInterval);
    clearInterval(watchdogInterval);
    if (cancelKillTimer) {
      clearTimeout(cancelKillTimer);
    }
  }

  function settle(requestId, error, result) {
    const request = pending.get(requestId);
    if (!request) {
      return;
    }

    pending.delete(requestId);
    if (error) {
      request.reject(error);
    } else {
      request.resolve(result);
    }
  }

  function rejectAll(error) {
    for (const requestId of pending.keys()) {
      settle(requestId, error);
    }
  }

  function requestChildCancel() {
    if (cancelRequested || closed) {
      return;
    }

    cancelRequested = true;
    worker.send?.({ type: 'cancel' });
    cancelKillTimer = setTimeout(() => {
      if (!closed) {
        worker.kill('SIGTERM');
      }
    }, CHILD_CANCEL_GRACE_MS);
  }

  async function checkCancellation() {
    if (closed || pending.size === 0) {
      return;
    }

    try {
      if (await shouldCancel()) {
        requestChildCancel();
      }
    } catch (error) {
      rejectAll(error);
    }
  }

  const cancelInterval = setInterval(checkCancellation, CANCEL_POLL_MS);
  const watchdogInterval = setInterval(() => {
    if (closed || idleTimeoutMs <= 0) {
      return;
    }

    const nowMs = performance.now();
    for (const [requestId, request] of pending.entries()) {
      const idleMs = nowMs - request.lastMessageAtMs;
      if (idleMs < idleTimeoutMs) {
        continue;
      }

      const debugContext = request.debugContext || {};
      const error = new Error(`Narrow phase worker request timed out after ${Math.round(idleMs)}ms without IPC progress.`);
      error.code = 'NARROW_PHASE_WORKER_IDLE_TIMEOUT';
      error.workerId = workerId;
      error.requestId = requestId;
      error.batchNumber = debugContext.batchNumber;
      error.candidateCount = debugContext.candidateCount;
      error.debugContext = debugContext;
      error.lastProgress = request.lastProgress || null;
      settle(requestId, error);
      closed = true;
      worker.kill('SIGTERM');
    }
  }, Math.min(WORKER_WATCHDOG_POLL_MS, Math.max(1000, idleTimeoutMs || WORKER_WATCHDOG_POLL_MS)));

  worker.stderr?.on('data', chunk => {
    workerErrorLog += String(chunk);
  });

  worker.on('message', message => {
    const requestId = message?.requestId;
    const request = pending.get(requestId);
    if (request) {
      request.lastMessageAtMs = performance.now();
    }

    if (message?.type === 'progress') {
      if (!request) {
        return;
      }

      request.lastProgressAtMs = performance.now();
      request.lastProgress = message.progress || {};
      request.progressChain = request.progressChain
        .then(() => request.onProgress(message.progress || {}))
        .then(checkCancellation)
        .catch(error => settle(requestId, error));
      return;
    }

    if (message?.type === 'completed') {
      request?.progressChain
        .then(() => {
          if (cancelRequested) {
            settle(requestId, new CancellationError('Narrow phase worker was canceled.'));
          } else {
            settle(requestId, null, message.result);
          }
        })
        .catch(error => settle(requestId, error));
      return;
    }

    if (message?.type === 'failed') {
      settle(requestId, serializeWorkerError(message.error));
      return;
    }

    if (message?.type === 'shutdown-completed') {
      settle(requestId, null, true);
    }
  });

  worker.on('error', error => {
    rejectAll(error);
  });

  worker.on('exit', (code, signal) => {
    closed = true;
    cleanup();
    if (pending.size === 0) {
      return;
    }

    if (cancelRequested) {
      rejectAll(new CancellationError('Narrow phase worker was canceled.'));
      return;
    }

    const detail = workerErrorLog ? ` ${workerErrorLog}` : '';
    rejectAll(new Error(`Narrow phase worker exited before completion. code=${code ?? 'NA'} signal=${signal ?? 'NA'}.${detail}`));
  });

  function sendRequest(message, requestHooks = {}) {
    if (closed) {
      return Promise.reject(new Error('Narrow phase worker is already closed.'));
    }
    if (pending.size > 0) {
      return Promise.reject(new Error('Narrow phase worker is already busy.'));
    }

    const requestId = nextRequestId;
    nextRequestId += 1;
    cancelRequested = false;

    return new Promise((resolve, reject) => {
      pending.set(requestId, {
        resolve,
        reject,
        onProgress: typeof requestHooks.onProgress === 'function' ? requestHooks.onProgress : async () => {},
        progressChain: Promise.resolve(),
        debugContext: requestHooks.debugContext || null,
        startedAtMs: performance.now(),
        lastMessageAtMs: performance.now(),
        lastProgressAtMs: null,
        lastProgress: null,
      });
      worker.send({
        ...message,
        requestId,
      });
    });
  }

  return {
    run(body, runHooks = {}) {
      const cacheObjectKeySignature = body.cacheObjectKeySignature || null;
      const shouldSendCacheObjectKeys = cacheObjectKeySignature !== activeCacheObjectKeySignature;
      activeCacheObjectKeySignature = cacheObjectKeySignature;

      return sendRequest({
        type: 'narrow-phase-pairs',
        projectDescriptor: body.projectDescriptor,
        pairs: body.pairs || body.candidates,
        cacheObjects: body.cacheObjects !== false,
        cacheObjectKeys: shouldSendCacheObjectKeys ? body.cacheObjectKeys || [] : null,
        cacheObjectKeySignature,
        narrowPhaseSharedPrep: body.narrowPhaseSharedPrep !== false,
        narrowPhaseShareUncached: body.narrowPhaseShareUncached !== false,
        narrowPhaseGeometryBudgetBytes: body.narrowPhaseGeometryBudgetBytes || 0,
      }, runHooks).then(result => ({ ...result, workerId }));
    },

    async close() {
      if (closed) {
        return;
      }

      try {
        await sendRequest({ type: 'shutdown' });
      } catch {
        worker.kill();
      } finally {
        cleanup();
      }
    },
  };
}

export function createQueuedWorkerPool(workers) {
  const workerSlots = workers.map(worker => ({
    worker,
    busy: false,
  }));
  const queue = [];
  let closing = false;

  function dispatchQueuedWork() {
    if (closing) {
      return;
    }

    for (const slot of workerSlots) {
      if (queue.length === 0) {
        return;
      }
      if (slot.busy) {
        continue;
      }

      const queued = queue.shift();
      slot.busy = true;
      let runPromise;
      try {
        runPromise = Promise.resolve(slot.worker.run(queued.body, queued.runHooks));
      } catch (error) {
        runPromise = Promise.reject(error);
      }

      runPromise
        .then(queued.resolve, queued.reject)
        .finally(() => {
          slot.busy = false;
          dispatchQueuedWork();
        });
    }
  }

  return {
    run(body, runHooks = {}) {
      if (closing) {
        return Promise.reject(new Error('Narrow phase worker pool is closing.'));
      }

      return new Promise((resolve, reject) => {
        queue.push({
          body,
          runHooks,
          resolve,
          reject,
        });
        dispatchQueuedWork();
      });
    },

    async close() {
      closing = true;
      while (queue.length > 0) {
        const queued = queue.shift();
        queued.reject(new Error('Narrow phase worker pool closed before work started.'));
      }

      const results = await Promise.allSettled(workerSlots.map(slot => slot.worker.close()));
      const rejected = results.find(result => result.status === 'rejected');
      if (rejected) {
        throw rejected.reason;
      }
    },
  };
}

export async function waitForNarrowPhaseBatchCapacity({
  inFlightBatches,
  completedBatches,
  workerCount,
  finalizeCompletedBatches,
}) {
  const maxOutstandingBatchCount = workerCount * NARROW_PHASE_OUTSTANDING_BATCH_MULTIPLIER;
  while (true) {
    await finalizeCompletedBatches();

    const outstandingBatchCount = inFlightBatches.size + completedBatches.size;
    if (
      inFlightBatches.size < workerCount
      && outstandingBatchCount < maxOutstandingBatchCount
    ) {
      return;
    }

    if (inFlightBatches.size === 0) {
      throw new Error(
        'Narrow phase batch capacity is blocked because no in-flight batch can make progress.',
      );
    }

    await Promise.race(inFlightBatches);
  }
}

export function createNarrowPhaseBatchFinalizer(finalizeCompletedBatches) {
  let finalizationChain = Promise.resolve();

  return function requestFinalization() {
    const request = finalizationChain.then(finalizeCompletedBatches);
    finalizationChain = request.catch(() => {});
    return request;
  };
}

export function createNarrowPhaseBatchTracker({
  workerCount,
  finalizeCompletedBatches,
}) {
  const inFlightBatches = new Set();
  const inFlightBatchEntries = new Map();
  const completedBatches = new Map();
  let batchError = null;
  const requestFinalization = createNarrowPhaseBatchFinalizer(async () => {
    await finalizeCompletedBatches(completedBatches);
    if (batchError) {
      throw batchError;
    }
  });

  function recordError(error) {
    if (!batchError) {
      batchError = error;
    }
  }

  function track(promise, entry) {
    let trackedPromise;
    trackedPromise = Promise.resolve(promise)
      .then(async completed => {
        completedBatches.set(completed.batchInfo.batchNumber, completed);
        await requestFinalization();
      })
      .catch(recordError)
      .finally(() => {
        inFlightBatches.delete(trackedPromise);
        inFlightBatchEntries.delete(trackedPromise);
      });
    inFlightBatches.add(trackedPromise);
    inFlightBatchEntries.set(trackedPromise, entry);
    return trackedPromise;
  }

  async function waitForCapacity() {
    await waitForNarrowPhaseBatchCapacity({
      inFlightBatches,
      completedBatches,
      workerCount,
      finalizeCompletedBatches: requestFinalization,
    });
  }

  async function waitForAll() {
    while (inFlightBatches.size > 0) {
      await Promise.race(inFlightBatches);
      await requestFinalization();
    }
    await requestFinalization();
  }

  return {
    get activeEntries() {
      return [...inFlightBatchEntries.values()];
    },

    get inFlightCount() {
      return inFlightBatches.size;
    },

    track,
    waitForAll,
    waitForCapacity,
  };
}

function createNarrowPhaseWorkerPool(workerCount, hooks = {}) {
  const workers = Array.from({ length: workerCount }, (_, index) => createNarrowPhaseWorkerClient({
    ...hooks,
    workerId: index + 1,
  }));
  return createQueuedWorkerPool(workers);
}

function normalizeCacheFrequencyThreshold(value) {
  const parsedValue = Number(value ?? HOT_OBJECT_CACHE_MIN_FREQUENCY);
  if (!Number.isFinite(parsedValue) || parsedValue <= 0) {
    return HOT_OBJECT_CACHE_MIN_FREQUENCY;
  }

  return Math.ceil(parsedValue);
}

export function addCandidateObjectFrequency(frequencies, candidate, endpointIndex) {
  const endpoint = endpointIndex === 1 ? candidate.source : candidate.target;
  const key = getCandidateEndpointKey(endpoint);
  frequencies.set(key, (frequencies.get(key) || 0) + 1);
}

async function collectCandidateObjectFrequencies(dataset, matrix, options = {}) {
  const frequencies = new Map();
  const progressIntervalMs = Number(options.progressIntervalMs ?? 5000);
  let lastProgressAtMs = Number.NEGATIVE_INFINITY;

  const broadPhase = await runBroadPhaseCandidateBatches(dataset, matrix, {
    batchSize: options.batchSize,
    batchSizeLimit: options.batchSizeLimit,
    shouldCancel: options.shouldCancel,
    onCandidate: candidate => {
      addCandidateObjectFrequency(frequencies, candidate, 1);
      addCandidateObjectFrequency(frequencies, candidate, 2);
    },
    onBatch: async (_candidates, batchInfo) => {
      await throwIfCanceled(options.shouldCancel, 'cache-frequency broad-phase batch');
      const nowMs = performance.now();
      if (nowMs - lastProgressAtMs < progressIntervalMs) {
        return;
      }
      lastProgressAtMs = nowMs;
      await options.onProgress?.({
        stage: 'cache-frequency',
        message: `Collected cache frequency batch ${batchInfo.batchNumber}.`,
        broadPhase: {
          candidateCount: batchInfo.totalCandidateCount,
          batchCount: batchInfo.batchNumber,
        },
        progress: { percent: null },
      });
    },
  });

  return {
    broadPhase,
    frequencies,
  };
}

function getHotObjectCacheKeys(frequencies, threshold) {
  return [...frequencies.entries()]
    .filter(([, count]) => count >= threshold)
    .map(([key]) => key)
    .sort((a, b) => a.localeCompare(b));
}

function createCacheObjectKeySignature(cacheObjectKeys, threshold) {
  let hash = 2166136261;
  for (const key of cacheObjectKeys) {
    for (let index = 0; index < key.length; index += 1) {
      hash ^= key.charCodeAt(index);
      hash = Math.imul(hash, 16777619) >>> 0;
    }
  }

  return `${threshold}:${cacheObjectKeys.length}:${hash.toString(16)}`;
}

async function emitProgress(hooks, progressPatch) {
  if (typeof hooks.onProgress !== 'function') {
    return;
  }

  await hooks.onProgress({
    ...progressPatch,
    heartbeatAt: new Date().toISOString(),
  });
}

function createNarrowPhaseProgress({
  narrowPhase,
  batchProgresses,
  knownCandidateCount,
  knownBatchCount,
  inFlightBatchCount,
  activeBatches = [],
}) {
  const inFlightProcessedCount = [...batchProgresses.values()]
    .reduce((sum, progress) => sum + Math.max(0, Number(progress.processed) || 0), 0);
  const processedCandidateCount = narrowPhase.processed + inFlightProcessedCount;
  const totalCandidateCount = Math.max(
    knownCandidateCount,
    narrowPhase.total,
    processedCandidateCount,
  );
  const percent = totalCandidateCount > 0
    ? Math.min(100, Number(((processedCandidateCount / totalCandidateCount) * 100).toFixed(1)))
    : 100;

  return {
    percent,
    processedCandidateCount,
    totalCandidateCount,
    completedBatchCount: narrowPhase.batchTimings.length,
    knownBatchCount,
    inFlightBatchCount,
    activeBatches,
    oldestActiveBatch: activeBatches[0] || null,
  };
}

export function createInputDiagnostics(disciplineStats = []) {
  const skipped = {};
  const models = disciplineStats.map(stats => {
    const modelSkipped = { ...(stats.skipped || {}) };
    for (const [reason, count] of Object.entries(modelSkipped)) {
      skipped[reason] = (skipped[reason] || 0) + count;
    }

    return {
      modelId: stats.modelId,
      folderName: stats.folderName,
      discipline: stats.discipline,
      modelRowCount: stats.modelRowCount,
      geometryCount: stats.geometryCount,
      relationshipCount: stats.relationshipCount,
      exceptionCount: stats.exceptionCount,
      clashableObjectCount: stats.objectCount,
      aggregateForest: stats.aggregateForest ? { ...stats.aggregateForest } : null,
      skipped: modelSkipped,
    };
  });

  return {
    modelCount: models.length,
    modelRowCount: models.reduce((sum, model) => sum + model.modelRowCount, 0),
    clashableObjectCount: models.reduce((sum, model) => sum + model.clashableObjectCount, 0),
    exceptionCount: models.reduce((sum, model) => sum + model.exceptionCount, 0),
    skipped,
    models,
  };
}

function createBroadPhaseSummary(broadPhase, disciplineStats) {
  return {
    objectCount: broadPhase.objectCount,
    exceptionCount: broadPhase.exceptionCount,
    ruleCount: broadPhase.ruleCount,
    spatialCandidateCount: broadPhase.spatialCandidateCount,
    aggregateTreeFilteredCount: broadPhase.aggregateTreeFilteredCount,
    selfPairFilteredCount: broadPhase.selfPairFilteredCount,
    useObbRefinement: broadPhase.useObbRefinement,
    obbFilteredCount: broadPhase.obbFilteredCount,
    sameSystemFilteredCount: broadPhase.sameSystemFilteredCount,
    sameSystemFilteredByLevel: broadPhase.sameSystemFilteredByLevel,
    semanticFilteredCount: broadPhase.semanticFilteredCount,
    semanticFilteredByLevel: broadPhase.semanticFilteredByLevel,
    spatialLevelFilter: broadPhase.spatialLevelFilter,
    spatialLevelFilteredCount: broadPhase.spatialLevelFilteredCount,
    spatialLevelUnknownKeptCount: broadPhase.spatialLevelUnknownKeptCount,
    ignoreSameSystem: broadPhase.ignoreSameSystem,
    ignoreCoversBldgElements: broadPhase.ignoreCoversBldgElements,
    ignoreConnectsPathElements: broadPhase.ignoreConnectsPathElements,
    ignoreSpacesAndOpenings: broadPhase.ignoreSpacesAndOpenings,
    ignoreHostOpeningFill: broadPhase.ignoreHostOpeningFill,
    ignorePortConnected: broadPhase.ignorePortConnected,
    candidateCount: broadPhase.candidateCount,
    batchCount: broadPhase.batchCount,
    ruleSummaries: broadPhase.ruleSummaries,
    timing: broadPhase.timing || null,
    inputDiagnostics: createInputDiagnostics(disciplineStats),
  };
}

export async function runBroadNarrowReport(body, hooks = {}) {
  const startedAtMs = Date.now();
  const startedAtPerformanceMs = performance.now();
  const startedAt = new Date(startedAtMs).toISOString();
  const phaseTimings = {};
  const matrix = body.matrix || body;
  const runtimeMatrix = {
    ...matrix,
    spatialLevelFilter: body.spatialLevelFilter ?? matrix.spatialLevelFilter ?? null,
  };
  const batchSizeLimit = body.batchSizeLimit ?? MAX_CLASH_BATCH_SIZE;
  const batchSize = normalizeClashBatchSize(body.batchSize ?? matrix.batchSize, {
    maxBatchSize: batchSizeLimit,
  });
  const projectDescriptor = createProjectDescriptor(body.projectDescriptor || matrix.projectDescriptor);
  const basePath = body.basePath || matrix.basePath || projectDescriptor.projectId;
  const usePersistentWorker = body.usePersistentWorker !== false;
  const narrowPhaseWorkerCount = usePersistentWorker
    ? normalizeNarrowPhaseWorkerCount(body.narrowPhaseWorkerCount ?? matrix.narrowPhaseWorkerCount)
    : 1;
  const cacheNarrowPhaseObjects = body.cacheNarrowPhaseObjects !== false;
  // Geometry-store budget is a TOTAL across workers; each worker gets an
  // equal share. 0 disables eviction (unbounded store).
  const geometryBudgetMbTotal = Number(body.narrowPhaseGeometryBudgetMbTotal ?? 1536);
  const narrowPhaseGeometryBudgetBytes = Number.isFinite(geometryBudgetMbTotal) && geometryBudgetMbTotal > 0
    ? Math.floor((geometryBudgetMbTotal * 1048576) / narrowPhaseWorkerCount)
    : 0;
  const cacheFrequencyThreshold = normalizeCacheFrequencyThreshold(body.cacheFrequencyThreshold);
  const writer = body.writer;
  if (!writer) {
    throw new Error('Report writer is required.');
  }
  const workerTimingAccumulator = createNarrowPhaseTimingAccumulator({
    persistentWorkers: usePersistentWorker,
  });
  const narrowPhase = {
    total: 0,
    processed: 0,
    succeeded: 0,
    failed: 0,
    workerDurationMs: 0,
    reportWriteDurationMs: 0,
    batchTimings: [],
  };
  let persistentWorkerPool = null;
  const batchProgresses = new Map();
  let knownCandidateCount = 0;
  let knownBatchCount = 0;
  let nextBatchToFinalize = 1;
  let cacheObjectKeys = [];
  let cacheObjectKeySignature = null;
  const intentionalExclusions = createPairHashEvidenceAccumulator();
  const evaluationFailures = createPairHashEvidenceAccumulator();
  const detectedPairs = createPairHashEvidenceAccumulator();
  let batchTracker;

  // Mirrors the grouped pipeline's clash-row predicate exactly: a row becomes
  // a persistable clash only when Collision is TRUE and both GlobalIDs are
  // present. Anything else (misses, error rows) is not a detected pair.
  function recordDetectedPair(row) {
    if (row.Collision !== 'TRUE') return;
    if (!row['Object 1 GlobalID'] || !row['Object 2 GlobalID']) return;
    detectedPairs.addPair({
      sourceModelId: row['Object 1 Model ID'],
      sourceGlobalId: row['Object 1 GlobalID'],
      targetModelId: row['Object 2 Model ID'],
      targetGlobalId: row['Object 2 GlobalID'],
    });
  }

  function recordEvaluationFailure(row) {
    evaluationFailures.addPair({
      sourceModelId: row['Object 1 Model ID'],
      sourceGlobalId: row['Object 1 GlobalID'],
      targetModelId: row['Object 2 Model ID'],
      targetGlobalId: row['Object 2 GlobalID'],
    });
  }

  async function disposePairEvidence() {
    await Promise.all([
      intentionalExclusions.dispose(),
      evaluationFailures.dispose(),
      detectedPairs.dispose(),
    ]);
  }

  function getNarrowPhaseTiming() {
    return {
      workerDurationMs: Number(narrowPhase.workerDurationMs.toFixed(3)),
      reportWriteDurationMs: Number(narrowPhase.reportWriteDurationMs.toFixed(3)),
      workerTiming: workerTimingAccumulator.snapshot(),
    };
  }

  function getActiveBatchSummaries() {
    return batchTracker.activeEntries
      .map(summarizeActiveBatch)
      .sort((a, b) => b.ageMs - a.ageMs);
  }

  async function finalizeCompletedBatches(completedBatches) {
    while (completedBatches.has(nextBatchToFinalize)) {
      const completed = completedBatches.get(nextBatchToFinalize);
      completedBatches.delete(nextBatchToFinalize);
      nextBatchToFinalize += 1;

      const {
        candidates,
        batchInfo,
        batchResult,
        batchStartedAtMs,
        workerDurationMs,
      } = completed;

      narrowPhase.workerDurationMs += workerDurationMs;
      narrowPhase.total += batchResult.total;
      narrowPhase.processed += batchResult.processed;
      narrowPhase.succeeded += batchResult.succeeded;
      narrowPhase.failed += batchResult.failed;
      workerTimingAccumulator.add(batchResult.timing, {
        workerId: batchResult.workerId,
      });
      const reportRows = [];
      for (const row of batchResult.results) {
        if (row.Error && row.Error !== 'NA') {
          recordEvaluationFailure(row);
        }
        recordDetectedPair(row);
        if (shouldWriteReportRow(row)) reportRows.push(row);
      }
      const writeStartedAtMs = performance.now();
      if (reportRows.length > 0) {
        await writer.writeRows(reportRows);
      }
      const reportWriteDurationMs = elapsedMs(writeStartedAtMs);
      narrowPhase.reportWriteDurationMs += reportWriteDurationMs;
      narrowPhase.batchTimings.push({
        batchNumber: batchInfo.batchNumber,
        workerId: usePersistentWorker ? batchResult.workerId : null,
        candidateCount: candidates.length,
        resultCount: batchResult.results.length,
        reportRowCount: reportRows.length,
        workerDurationMs,
        reportWriteDurationMs,
        durationMs: elapsedMs(batchStartedAtMs),
        workerTiming: batchResult.timing,
      });
      batchProgresses.delete(batchInfo.batchNumber);
      const progress = createNarrowPhaseProgress({
        narrowPhase,
        batchProgresses,
        knownCandidateCount,
        knownBatchCount,
        inFlightBatchCount: batchTracker.inFlightCount,
        activeBatches: getActiveBatchSummaries(),
      });

      await hooks.onBatchEnd?.({
        batchNumber: batchInfo.batchNumber,
        candidateCount: candidates.length,
        totalCandidateCount: batchInfo.totalCandidateCount,
        progress,
        narrowPhase: {
          total: narrowPhase.total,
          processed: narrowPhase.processed,
          succeeded: narrowPhase.succeeded,
          failed: narrowPhase.failed,
        },
      });
      await emitProgress(hooks, {
        stage: 'narrow-phase',
        message: `Finished narrow phase batch ${batchInfo.batchNumber}.`,
        progress: { percent: progress.percent },
        narrowPhase: {
          ...narrowPhase,
          timing: getNarrowPhaseTiming(),
          progress,
        },
      });
    }
  }

  batchTracker = createNarrowPhaseBatchTracker({
    workerCount: narrowPhaseWorkerCount,
    finalizeCompletedBatches,
  });

  function createBatchProgressHandler({ batchEntry, batchInfo, candidates }) {
    return batchProgress => {
      batchEntry.lastProgressAtMs = performance.now();
      batchEntry.lastProgress = batchProgress;
      batchProgresses.set(batchInfo.batchNumber, {
        total: candidates.length,
        ...batchProgress,
      });
      const currentProgress = createNarrowPhaseProgress({
        narrowPhase,
        batchProgresses,
        knownCandidateCount,
        knownBatchCount,
        inFlightBatchCount: batchTracker.inFlightCount,
        activeBatches: getActiveBatchSummaries(),
      });
      return emitProgress(hooks, {
        stage: 'narrow-phase',
        message: `Running narrow phase batch ${batchInfo.batchNumber}.`,
        progress: { percent: currentProgress.percent },
        narrowPhase: {
          ...narrowPhase,
          timing: getNarrowPhaseTiming(),
          progress: currentProgress,
          currentBatch: {
            batchNumber: batchInfo.batchNumber,
            ...batchProgress,
          },
        },
      });
    };
  }

  async function scheduleNarrowPhaseBatch(candidates, batchInfo) {
    await batchTracker.waitForCapacity();
    const batchStartedAtMs = performance.now();
    const normalizedBatchInfo = {
      ...batchInfo,
      totalCandidateCount: knownCandidateCount,
    };
    const batchDebugContext = createBatchDebugContext(normalizedBatchInfo, candidates);
    const batchEntry = {
      debugContext: batchDebugContext,
      startedAtMs: batchStartedAtMs,
      lastProgressAtMs: null,
      lastProgress: null,
    };
    batchProgresses.set(normalizedBatchInfo.batchNumber, {
      total: candidates.length,
      processed: 0,
      succeeded: 0,
      failed: 0,
    });
    await throwIfCanceled(hooks.shouldCancel, 'narrow-phase batch dispatch');
    await hooks.onBatchStart?.({
      batchNumber: normalizedBatchInfo.batchNumber,
      candidateCount: candidates.length,
      totalCandidateCount: normalizedBatchInfo.totalCandidateCount,
    });
    const progress = createNarrowPhaseProgress({
      narrowPhase,
      batchProgresses,
      knownCandidateCount,
      knownBatchCount,
      inFlightBatchCount: batchTracker.inFlightCount,
      activeBatches: getActiveBatchSummaries(),
    });
    await emitProgress(hooks, {
      stage: 'narrow-phase',
      message: `Running narrow phase batch ${normalizedBatchInfo.batchNumber}.`,
      progress: { percent: progress.percent },
      broadPhase: {
        candidateCount: normalizedBatchInfo.totalCandidateCount,
        batchCount: knownBatchCount,
      },
      narrowPhase: {
        ...narrowPhase,
        timing: getNarrowPhaseTiming(),
        progress,
      },
    });

    const workerBody = {
      projectDescriptor,
      pairs: candidates,
      cacheObjects: cacheNarrowPhaseObjects,
      cacheObjectKeys,
      cacheObjectKeySignature,
      narrowPhaseSharedPrep: body.narrowPhaseSharedPrep !== false,
      narrowPhaseShareUncached: body.narrowPhaseShareUncached !== false,
      narrowPhaseGeometryBudgetBytes,
    };
    const runBatch = async () => {
      const workerStartedAtMs = performance.now();
      const onProgress = createBatchProgressHandler({
        batchEntry,
        batchInfo: normalizedBatchInfo,
        candidates,
      });
      const batchResult = persistentWorkerPool
        ? await persistentWorkerPool.run(workerBody, {
          debugContext: batchDebugContext,
          onProgress,
        })
        : await runNarrowPhaseWorker(workerBody, {
          shouldCancel: hooks.shouldCancel,
          onProgress,
        });

      return {
        candidates,
        batchInfo: normalizedBatchInfo,
        batchResult,
        batchStartedAtMs,
        workerDurationMs: elapsedMs(workerStartedAtMs),
      };
    };

    batchTracker.track(runBatch(), batchEntry);
  }

  try {
    await emitProgress(hooks, {
      stage: 'loading',
      message: 'Loading discipline datasets.',
      progress: { percent: null },
    });
    await throwIfCanceled(hooks.shouldCancel, 'dataset loading');

    const dataset = await timePhase(
      phaseTimings,
      'buildBroadPhaseDataset',
      () => buildBroadPhaseDataset(projectDescriptor, {
        shouldCancel: hooks.shouldCancel,
        onDisciplineStart: discipline => emitProgress(hooks, {
          stage: 'loading',
          message: `Loading ${discipline}.`,
        }),
      }),
    );

    const frequencyResult = cacheNarrowPhaseObjects
      ? await timePhase(
        phaseTimings,
        'cacheFrequencyBroadPhase',
        () => collectCandidateObjectFrequencies(dataset, runtimeMatrix, {
          batchSize,
          batchSizeLimit,
          shouldCancel: hooks.shouldCancel,
          onProgress: progressPatch => emitProgress(hooks, progressPatch),
        }),
      )
      : null;
    if (!cacheNarrowPhaseObjects) {
      phaseTimings.cacheFrequencyBroadPhase = 0;
    }
    knownCandidateCount = frequencyResult?.broadPhase?.candidateCount ?? 0;
    knownBatchCount = frequencyResult?.broadPhase?.batchCount ?? 0;

    const cachePolicyStartedAtMs = performance.now();
    cacheObjectKeys = frequencyResult
      ? getHotObjectCacheKeys(frequencyResult.frequencies, cacheFrequencyThreshold)
      : [];
    cacheObjectKeySignature = cacheNarrowPhaseObjects
      ? createCacheObjectKeySignature(cacheObjectKeys, cacheFrequencyThreshold)
      : null;
    const cachePolicy = {
      enabled: cacheNarrowPhaseObjects,
      minFrequency: cacheFrequencyThreshold,
      candidateObjectCount: frequencyResult?.frequencies.size ?? 0,
      cachedObjectCount: cacheObjectKeys.length,
      cacheObjectKeySignature,
    };
    phaseTimings.buildCachePolicy = elapsedMs(cachePolicyStartedAtMs);
    persistentWorkerPool = usePersistentWorker
      ? createNarrowPhaseWorkerPool(narrowPhaseWorkerCount, { shouldCancel: hooks.shouldCancel })
      : null;

    await timePhase(
      phaseTimings,
      'initializeReportFile',
      () => initializeReportFile(writer, dataset.exceptions),
    );

    await emitProgress(hooks, {
      stage: 'broad-phase',
      message: 'Running broad phase.',
      broadPhase: {
        objectCount: dataset.objects.length,
        exceptionCount: dataset.exceptions.length,
      },
      progress: { percent: null },
    });

    const broadPhase = await timePhase(
      phaseTimings,
      'broadPhaseAndNarrowPhase',
      async () => {
        const broadPhaseResult = await runBroadPhaseCandidateBatches(dataset, runtimeMatrix, {
          batchSize,
          batchSizeLimit,
          recordCoverageExclusions: true,
          collectCoverageExclusions: false,
          onCoverageExclusion: (_reason, sourceObject, targetObject) => {
            intentionalExclusions.addPair({
              sourceModelId: sourceObject.modelId,
              sourceGlobalId: sourceObject.globalId,
              targetModelId: targetObject.modelId,
              targetGlobalId: targetObject.globalId,
            });
          },
          shouldCancel: hooks.shouldCancel,
          onBatch: async (candidates, batchInfo) => {
            knownCandidateCount = Math.max(knownCandidateCount, batchInfo.totalCandidateCount);
            knownBatchCount = Math.max(knownBatchCount, batchInfo.batchNumber);
            await throwIfCanceled(hooks.shouldCancel, 'broad-phase batch flush');
            await scheduleNarrowPhaseBatch(candidates, batchInfo);
          },
        });
        await batchTracker.waitForAll();
        return broadPhaseResult;
      },
    );

    await throwIfCanceled(hooks.shouldCancel, 'report finalization');
    let evaluatedCoverageGenerationError = null;
    let detectedPairsEvidence = null;
    try {
      if (
        typeof writer.writeEvaluatedCoverage !== 'function'
        || typeof writer.writePairEvidenceChunk !== 'function'
      ) {
        throw new Error('Report writer does not support evaluated coverage.');
      }
      const intentionalExclusionsManifest = await intentionalExclusions.finalizeManifest({
        writeChunk: chunk => writer.writePairEvidenceChunk(
          'intentional-exclusions',
          chunk,
        ),
      });
      const evaluationFailuresManifest = await evaluationFailures.finalizeManifest({
        writeChunk: chunk => writer.writePairEvidenceChunk(
          'evaluation-failures',
          chunk,
        ),
      });
      detectedPairsEvidence = await detectedPairs.finalizeDigest();
      const evaluatedCoverage = buildEvaluatedCoverageArtifact({
        jobId: body.jobId,
        projectId: body.projectGuid,
        detectionIdentity: body.detectionIdentity,
        models: body.models,
        dataset,
        broadPhase,
        intentionalExclusions: intentionalExclusionsManifest,
        evaluationFailures: evaluationFailuresManifest,
        detectedPairs: detectedPairsEvidence,
      });
      await writer.writeEvaluatedCoverage(
        serializeEvaluatedCoverageArtifact(evaluatedCoverage),
      );
    } catch (error) {
      evaluatedCoverageGenerationError = error instanceof Error
        ? error.message
        : String(error);
    }
    const writerResult = await timePhase(
      phaseTimings,
      'closeReportWriter',
      () => writer.close({ success: true }),
    );
    await timePhase(
      phaseTimings,
      'closePersistentWorker',
      async () => {
        await persistentWorkerPool?.close();
      },
    );
    const completedAtMs = Date.now();
    const durationMs = completedAtMs - startedAtMs;
    phaseTimings.totalMeasured = elapsedMs(startedAtPerformanceMs);
    const finalNarrowPhaseProgress = createNarrowPhaseProgress({
      narrowPhase,
      batchProgresses,
      knownCandidateCount,
      knownBatchCount,
      inFlightBatchCount: 0,
    });
    const result = {
      ...writerResult,
      detectedPairs: detectedPairsEvidence,
      evaluatedCoverageError: writerResult.evaluatedCoverageError
        || evaluatedCoverageGenerationError,
      basePath: dataset.basePath,
      batchSize,
      batchSizeLimit,
      usePersistentWorker,
      narrowPhaseWorkerCount,
      cacheNarrowPhaseObjects,
      cachePolicy,
      timing: {
        startedAt,
        completedAt: new Date(completedAtMs).toISOString(),
        durationMs,
        durationSeconds: Number((durationMs / 1000).toFixed(3)),
        phases: phaseTimings,
        broadPhaseFrequency: frequencyResult?.broadPhase?.timing || null,
        broadPhaseFormal: broadPhase?.timing || null,
      },
      broadPhase: {
        ...createBroadPhaseSummary(broadPhase, dataset.disciplineStats),
      },
      narrowPhase: {
        total: narrowPhase.total,
        processed: narrowPhase.processed,
        succeeded: narrowPhase.succeeded,
        failed: narrowPhase.failed,
        progress: finalNarrowPhaseProgress,
        timing: {
          ...getNarrowPhaseTiming(),
          batchTimings: narrowPhase.batchTimings,
        },
      },
    };

    await emitProgress(hooks, {
      stage: 'completed',
      message: 'Report completed.',
      broadPhase: result.broadPhase,
      narrowPhase: result.narrowPhase,
      progress: { percent: 100 },
    });

    await disposePairEvidence();
    return result;
  } catch (error) {
    await persistentWorkerPool?.close().catch(() => {});
    await writer.abort(error).catch(() => {});
    await disposePairEvidence();
    throw error;
  }
}
