export const DEFAULT_CLASH_BATCH_SIZE = 100;
export const MAX_CLASH_BATCH_SIZE = 1000;

export function normalizeClashBatchSize(value, {
  maxBatchSize = MAX_CLASH_BATCH_SIZE,
} = {}) {
  if (value === undefined || value === null) {
    return DEFAULT_CLASH_BATCH_SIZE;
  }

  const numericValue = Number(value);
  const numericMaxBatchSize = Number(maxBatchSize);
  if (
    !Number.isFinite(numericMaxBatchSize)
    || !Number.isInteger(numericMaxBatchSize)
    || numericMaxBatchSize < 1
  ) {
    throw new RangeError('maxBatchSize must be a positive integer.');
  }
  if (
    !Number.isFinite(numericValue)
    || !Number.isInteger(numericValue)
    || numericValue < 1
    || numericValue > numericMaxBatchSize
  ) {
    throw new RangeError(
      `batchSize must be an integer between 1 and ${numericMaxBatchSize}.`,
    );
  }

  return numericValue;
}
