import fs from 'node:fs/promises';
import { asyncBufferFromFile, parquetReadObjects } from 'hyparquet';

export async function readParquetObjects(filePath, columns) {
  await fs.access(filePath);
  const file = await asyncBufferFromFile(filePath);
  return parquetReadObjects({ file, columns });
}

function normalizeNumericValue(value, fieldName) {
  if (typeof value === 'bigint') {
    const numberValue = Number(value);
    if (!Number.isSafeInteger(numberValue)) {
      throw new Error(`Field "${fieldName}" contains BigInt value outside Number safe integer range.`);
    }

    return numberValue;
  }
  if (Array.isArray(value)) {
    return value.map(item => normalizeNumericValue(item, fieldName));
  }

  return value;
}

export function normalizeNestedArray(value, fieldName) {
  let parsedValue;
  if (typeof value === 'string') {
    parsedValue = JSON.parse(value);
  } else if (Array.isArray(value)) {
    parsedValue = value;
  } else {
    throw new Error(`Field "${fieldName}" must be an array or JSON array string.`);
  }

  return normalizeNumericValue(parsedValue, fieldName);
}
