const DEFAULT_FLUSH_INTERVAL_MS = 2000;

function normalizeIntervalMs(value) {
  const numericValue = Number(value ?? DEFAULT_FLUSH_INTERVAL_MS);
  if (!Number.isFinite(numericValue) || numericValue < 0) {
    return DEFAULT_FLUSH_INTERVAL_MS;
  }

  return Math.floor(numericValue);
}

function mergeProgressPatch(currentPatch, nextPatch = {}) {
  if (!currentPatch) {
    return nextPatch;
  }

  const mergedPatch = {
    ...currentPatch,
    ...nextPatch,
  };
  if (currentPatch.progress || nextPatch.progress) {
    mergedPatch.progress = {
      ...(currentPatch.progress || {}),
      ...(nextPatch.progress || {}),
    };
  }
  if (currentPatch.broadPhase || nextPatch.broadPhase) {
    mergedPatch.broadPhase = {
      ...(currentPatch.broadPhase || {}),
      ...(nextPatch.broadPhase || {}),
    };
  }
  if (currentPatch.narrowPhase || nextPatch.narrowPhase) {
    mergedPatch.narrowPhase = {
      ...(currentPatch.narrowPhase || {}),
      ...(nextPatch.narrowPhase || {}),
    };
  }

  return mergedPatch;
}

export function createProgressReporter({
  flushIntervalMs = DEFAULT_FLUSH_INTERVAL_MS,
  shouldFlushNow = () => false,
  onFlush,
  onError = () => {},
} = {}) {
  if (typeof onFlush !== 'function') {
    throw new Error('Progress reporter requires an onFlush callback.');
  }

  const intervalMs = normalizeIntervalMs(flushIntervalMs);
  let latestPatch = null;
  let flushTimer = null;
  let flushChain = Promise.resolve();
  let lastFlushAt = 0;
  let closed = false;

  function clearFlushTimer() {
    if (flushTimer) {
      clearTimeout(flushTimer);
      flushTimer = null;
    }
  }

  async function flushPatch(progressPatch) {
    try {
      await onFlush(progressPatch);
    } catch (error) {
      try {
        await onError(error, progressPatch);
      } catch {
        // Progress persistence is lossy; even error reporting must not block the job.
      }
    }
  }

  function flush() {
    clearFlushTimer();
    if (!latestPatch) {
      return flushChain;
    }

    const patchToFlush = latestPatch;
    latestPatch = null;
    lastFlushAt = Date.now();
    flushChain = flushChain.then(() => flushPatch(patchToFlush));
    return flushChain;
  }

  function scheduleFlush() {
    if (flushTimer || !latestPatch) {
      return;
    }

    const elapsedMs = lastFlushAt ? Date.now() - lastFlushAt : 0;
    const delayMs = Math.max(0, intervalMs - elapsedMs);
    flushTimer = setTimeout(() => {
      flushTimer = null;
      void flush();
    }, delayMs);
    flushTimer.unref?.();
  }

  return {
    report(progressPatch = {}) {
      if (closed) {
        return Promise.resolve();
      }

      latestPatch = mergeProgressPatch(latestPatch, progressPatch);
      if (intervalMs === 0 || shouldFlushNow(progressPatch)) {
        void flush();
      } else {
        scheduleFlush();
      }
      return Promise.resolve();
    },

    flush,

    async close() {
      closed = true;
      await flush();
      await flushChain;
    },
  };
}
